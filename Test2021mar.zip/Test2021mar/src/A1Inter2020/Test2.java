package A1Inter2020;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Test2 {

	public static void main(String[] args) {
		Connection conn = null;
		java.sql.Statement stmt = null;
		try {
			// STEP 2: Register JDBC driver
			Class.forName("org.postgresql.Driver");
			//alpha
			conn = DriverManager.getConnection("jdbc:postgresql://alpha-client.ql2.com:5432/caesius", "caesius", "dank!f0r3st");
			//nutmeg //jdbc:postgresql://testdb.ql2.com:5432/caesius
			//conn = DriverManager.getConnection("jdbc:postgresql://testdb.ql2.com:5432/caesius", "caesius", "dank!f0r3st");
			//prod//jdbc:postgresql://db.ql2.com:5432/caesius
			//conn = DriverManager.getConnection("jdbc:postgresql://db.ql2.com:5432/caesius", "caesius", "dank!f0r3st");
			
			// STEP 3: Open a connection
			System.out.println("Connecting to a selected database...");
			// conn = DriverManager.getConnection(DB_URL, USER, PASS);
			System.out.println("Connected database successfully...");

			// STEP 4: Execute a query
			System.out.println("Creating statement...");
			stmt =  conn.createStatement();
			long startTime = System.currentTimeMillis();
	        long TimeforRuns = 0;
	        long startTimefortable = 0;
			//String sql = "SELECT * FROM result limit 5";
			//old //TimeforRuns: 601 prod :TimeforRuns: 2697 //alpha 21115775 :TimeforRuns: 3146
	        String sql1 = "\r\n" + 
					" select DISTINCT (kk.id_run)run_id, kk.job_name, to_char(kk.complete_time, 'yyyy-mm-dd hh24 : mi') as complete_time,kk.job_id,kb.error_code, kb.count_input, kb.total_aborted_inputs, kb.errored_input, kb.total_input\r\n" + 
					" from ( SELECT tmp.job_name, tmp.id_run, tmp.complete_time, tmp.id_res, tmp.job_id FROM \r\n" + 
					" (SELECT DISTINCT run.id AS id_run, run.job_name, run.start_time, run.complete_time, run.user_settings, run.account_id, result.id AS id_res, run.job_id, run.application_id\r\n" + 
					" FROM run, result WHERE  run.id IN (1635706977) \r\n" + 
					" AND (result.run_id=run.id)\r\n" + 
					" AND (result.name NOT LIKE 'x_%' ESCAPE 'x')) AS tmp, result, account\r\n" + 
					" WHERE tmp.id_run = result.run_id AND account_id = account.id AND result.id=tmp.id_res order by  complete_time desc) as kk left join ( select r.id,e.code as error_code, count(distinct(e.line_id))as count_input,to_char(r.complete_time,'yyyy-mm-dd hh24:mi')as complete_time,r.size as total_input, (select sum(wu.lineitems) from work_unit wu where wu.run_id=r.id and wu.status=6 group by r.id)as total_aborted_inputs, count(distinct e.line_id) filter(where run_id=r.id and code=e.code) as errored_input  from run r left join error e on e.run_id=r.id where r.id in (  select distinct id from run where account_id in  (10140688 ) ) \r\n" + 
					"and e.code is not null and e.code in( 200) group by r.id ,e.code )as kb on kb.id=kk.id_run order by complete_time desc \r\n" + 
					"";
			//Ramesh
	      //old //1635706977 prod :TimeforRuns: 941 //alpha 21115775 :TimeforRuns: 1183
	        String sql = "select \r\n" + 
	        		"DISTINCT (kk.id_run)run_id, kk.job_name, to_char(kk.complete_time, 'yyyy-mm-dd hh24 : mi') as complete_time,kk.job_id,kb.error_code, kb.count_input, kb.total_aborted_inputs, kb.errored_input, kb.total_input\r\n" + 
	        		"from ( SELECT tmp.job_name, tmp.id_run, tmp.complete_time, tmp.id_res, tmp.job_id FROM\r\n" + 
	        		"(SELECT DISTINCT run.id AS id_run, run.job_name, run.start_time, run.complete_time, run.user_settings, run.account_id, result.id AS id_res, run.job_id, run.application_id\r\n" + 
	        		"FROM run, result WHERE run.id IN (1635706977)\r\n" + 
	        		"AND (result.run_id=run.id)\r\n" + 
	        		"AND (result.name NOT LIKE 'x_%' ESCAPE 'x')) AS tmp, result, account\r\n" + 
	        		"WHERE tmp.id_run = result.run_id AND account_id = account.id AND result.id=tmp.id_res order by complete_time desc) as kk left join ( select r.id,e.code as error_code, count(distinct(e.line_id))as count_input,to_char(r.complete_time,'yyyy-mm-dd hh24:mi')as complete_time,r.size as total_input, (select sum(wu.lineitems) from work_unit wu where wu.run_id=r.id and wu.status=6 group by r.id)as total_aborted_inputs, count(distinct e.line_id) filter(where run_id=r.id and code=e.code) as errored_input from run r \r\n" + 
	        		"left join error e on e.run_id=r.id where e.code is not null and e.code in( 200) AND r.account_id in(10140688) group by r.id ,e.code )as kb on kb.id=kk.id_run order by complete_time desc";
			
			ResultSet rs = ((java.sql.Statement) stmt).executeQuery(sql);
			// STEP 5: Extract data from result set
			System.out.println("sql: "+ sql);
			TimeforRuns = System.currentTimeMillis() - startTime;
            startTime = System.currentTimeMillis();
            System.out.println("TimeforRuns: "+ TimeforRuns);
            while (rs.next()) {
				
				/*// Retrieve by column name
				int id = rs.getInt("id");
				int age = rs.getInt("age");
				String first = rs.getString("first");
				String last = rs.getString("last");

				// Display values
				System.out.print("ID: " + id);
				System.out.print(", Age: " + age);
				System.out.print(", First: " + first);
				System.out.println(", Last: " + last);
*/		
				System.out.println("ID: " + rs.getInt(1));
				
			}
			rs.close();
		} catch (SQLException se) {
			// Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			// Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			// finally block used to close resources
			try {
				if (stmt != null)
					conn.close();
			} catch (SQLException se) {
			} // do nothing
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				se.printStackTrace();
			} // end finally try
		} // end try
		System.out.println("Goodbye!");
	}// end main
}// end JDBCExample
