package B3features7;
//catch multiple exceptions in single catch block. Before Java 7, you was restricted to catch only one exception per catch block.

public class L1Multicatch7 {

	public static void main(String args[]){    
        try{    
            int array[] = new  int[10];    
            array[10] = 30/0;    
        }    
        catch(ArithmeticException | ArrayIndexOutOfBoundsException e){  
            System.out.println(e.getMessage());  
        }    
     }    
}
