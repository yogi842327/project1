package B3features7;

public class L3SwitchString {
	public static void main(String[] args)
    {
		//Underscore in Numeric literals to improve readability
		int billion = 1_000_000_000; // 10^9 long creditCardNumber = 1234_4567_8901_2345L; //16 digit number

		
        System.out.println(getExpendedMessage("one"));
        System.out.println(getExpendedMessage("three"));
        System.out.println(getExpendedMessage("five"));
    }
 
    static String getExpendedMessage(final String token) 
    {
        String value = null;
         
        switch (token) 
        {
            case ("one"):
                value = "Token one identified";
                break;
     
            case ("two"):
                value = "Token two identified";
                break;
     
            case ("three"):
                value = "Token three identified";
                break;
     
            case ("four"):
                value = "Token four identified";
                break;
     
            default:
                value = "No token was identified";
       }
         
        return value;
    }
}
