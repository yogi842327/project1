package B2Exception1;
//Chained Exceptions allows to relate one exception with another exception, i.e one exception describes cause of another exception. 
//https://www.geeksforgeeks.org/chained-exceptions-java/

public class E5chainedException {
	public static void main(String[] args) {
		try {
			// creating an exception

			NumberFormatException ex = new NumberFormatException("Exception");

			// setting a cause of the exception

			ex.initCause(new NullPointerException("This is actual cause of the exception"));

			throw ex;
		} catch (NumberFormatException ex) {
			System.out.println(ex); // displaying the exception

			System.out.println(ex.getCause()); // getting the actual cause of the exception
		}
	}
}
