package B2Exception1;

public class F5CustomException1 {

	static void validateage(int age) throws InvalidageException {
		if (age < 18) {
			throw new InvalidageException("Not valid");
		} else {
			System.out.println("Valid data");
		}
	}
// negative no Exceptions : if (input < 0) {
	// System.out.println("Only Positive Numbers & no Letters Please!");

	public static void main(String args[]) throws Exception {
		try {
			validateage(19);
			validateage(13);
		} catch (Exception e) {
			System.out.println("hi" + e);
		}
		System.out.println("Rest of the code");
	}

}

class InvalidageException extends Exception {
	InvalidageException(String s) {
		super(s);
	}
}
