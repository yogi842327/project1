package B2Exception1;

public class E4Rethrow {
	public static void main(String[] args)
    {
	
	try
	{
	    String s = null;
	    System.out.println(s.length());   //This statement throws NullPointerException
	}
	catch(NullPointerException ex)
	{
	    System.out.println("NullPointerException is caught here");
	  
	    throw ex;     //Re-throwing NullPointerException
	    //Exceptions raised in the try block are handled in the catch block. If it is unable to handle that exception, it can re-throw that exception using throw keyword. It is called re-throwing an exception.
	}
}

}
