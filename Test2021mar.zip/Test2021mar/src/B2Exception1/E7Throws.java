package B2Exception1;
//https://beginnersbook.com/2013/04/difference-between-throw-and-throws-in-java/


public class E7Throws {

	int division(int a, int b) throws ArithmeticException{  
		int t = a/b;
		return t;
	   }  
	   public static void main(String args[]){  
		   E7Throws obj = new E7Throws();
		try{
		   System.out.println(obj.division(15,0));  
		}
		catch(ArithmeticException e){
		   System.out.println("You shouldn't divide number by zero");
		}
	   }  
	}

/*
Throw vs Throws in java
1. Throws clause is used to declare an exception, which means it works similar to the try-catch block. On the other hand throw keyword is used to throw an exception explicitly.

2. If we see syntax wise than throw is followed by an instance of Exception class and throws is followed by exception class names.
For example:

throw new ArithmeticException("Arithmetic Exception");
and

throws ArithmeticException;*/