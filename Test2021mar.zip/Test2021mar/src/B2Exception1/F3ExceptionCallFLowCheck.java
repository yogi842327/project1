package B2Exception1;

public class F3ExceptionCallFLowCheck {

	public static void main(String[] args) {
		int[] arr = new int[4];
		try {
			int i = arr[3];
			// this statement will never execute
			// as exception is raised by above statement
			System.out.println("Inside try block");
			System.out.println(i);
		} catch (ArithmeticException ex) {
			System.out.println("Exception caught in Catch block");
		} finally {
			System.out.println("Inside finally");
		}
		// rest program will be execute normally
		System.out.println("Outside try-catch clause");
	}
}
