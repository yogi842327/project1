package B2Exception1;
//https://javaconceptoftheday.com/java-exception-handling-interview-questions-and-answers/
public class E1statement {
	public static void main(String[] args) {

//No. We shouldn�t write any other statements in between try, catch and finally blocks. They form a one unit.
		try {
			// Statements to be monitored for exceptions
		}

		// You can't keep statements here

		catch (Exception ex) {
			// Cathcing the exceptions here
		}

		// You can't keep statements here

		finally {
			// This block is always executed
		}
	}
}