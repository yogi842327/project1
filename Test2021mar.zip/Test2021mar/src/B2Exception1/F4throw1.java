package B2Exception1;

public class F4throw1 {
	void checkAge(int age) {
		if (age < 18)
			throw new ArithmeticException("Not Eligible for voting");
		else
			System.out.println("Eligible for voting");
	}

	// throws
	int division(int a, int b) throws ArithmeticException {

		int t = a / b;
		return t;
	}

	public static void main(String args[]) {
		F4throw1 obj = new F4throw1();

		// System.out.println("Throws Ex: "+obj.division(15,0));
		obj.checkAge(21);
	//	System.out.println("Throws Ex: "+obj.division(15,0));
		obj.checkAge(13);
		 System.out.println("Throws Ex: "+obj.division(15,0));
		obj.checkAge(19);
		System.out.println("End Of Program");

	}
}
