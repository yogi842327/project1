package A8Inter2020Java;



//Java program to illustrate  
//how hashCode() and equals() methods work 
import java.io.*; 

class CHashcodes2  
{ 
   
 public String name; 
 public int id; 
       
 CHashcodes2(String name, int id)  
 { 
           
     this.name = name; 
     this.id = id; 
 } 
   
 @Override
 public boolean equals(Object obj) 
 { 
       
 // checking if both the object references are  
 // referring to the same object. 
 if(this == obj) 
         return true; 
       
     // it checks if the argument is of the  
     // type Geek by comparing the classes  
     // of the passed argument and this object. 
     // if(!(obj instanceof Geek)) return false; ---> avoid. 
     if(obj == null || obj.getClass()!= this.getClass()) 
         return false; 
       
     // type casting of the argument.  
     CHashcodes2 geek = (CHashcodes2) obj; 
       
     // comparing the state of argument with  
     // the state of 'this' Object. 
     return (geek.name == this.name && geek.id == this.id); 
 } 
   
 /**
  * Applies a supplemental hash function to a given hashCode, which
  * defends against poor quality hash functions.  This is critical
  * because HashMap uses power-of-two length hash tables, that
  * otherwise encounter collisions for hashCodes that do not differ
  * in lower bits. Note: Null keys always map to hash 0, thus index 0.
  */
 static int hash(int h) {
     // This function ensures that hashCodes that differ only by
     // constant multiples at each bit position have a bounded
     // number of collisions (approximately 8 at default load factor).
     h ^= (h >>> 20) ^ (h >>> 12);
     return h ^ (h >>> 7) ^ (h >>> 4);
 }
  
 /**
  * Returns index for hash code h.
  */
 static int indexFor(int h, int length) {
     return h & (length-1);
 }
  
 @Override
 public int hashCode() 
 { 
       
     // We are returning the Geek_id  
     // as a hashcode value. 
     // we can also return some  
     // other calculated value or may 
     // be memory address of the  
     // Object on which it is invoked.  
     // it depends on how you implement  
     // hashCode() method. 
     return this.id; 
 } 
   
} 

//Driver code 
class GFG 
{ 
   
 public static void main (String[] args) 
 { 
   
     // creating the Objects of Geek class. 
	 CHashcodes2 g1 = new CHashcodes2("aa", 1); 
     CHashcodes2 g2 = new CHashcodes2("aa", 1); 
       
     // comparing above created Objects. 
     if(g1.hashCode() == g2.hashCode()) 
     { 

         if(g1.equals(g2)) 
             System.out.println("Both Objects are equal. "); 
         else
             System.out.println("Both Objects are not equal. "); 
   
     } 
     else
     System.out.println("Both Objects are not equal. ");  
 }  
}
