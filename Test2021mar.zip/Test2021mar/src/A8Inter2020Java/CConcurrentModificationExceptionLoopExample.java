package A8Inter2020Java;

import java.nio.file.Paths;

/*Vector/legacy is synchronized means : java.util.Vector is synchronized 
(because 2 threads on same Vector object cannot  access it at same time)
INITIAL_CAPACITY = 10 :  implements a growable/dynamic array similer to ArrayList 
Vector/collection can work with each,iterator,listiterato,enumuration,for,while
	Enumuration/failsafe allow only for get/fetch/read data so never  give ConcurrentModificationException
	Enumurations support for legacy only: ht,vector,property,dictionar: except vector all put key value pair....
	Iterator,listitearator,each support for write/add operation so give ConcurrentModificationException*/

import java.util.*;
public class CConcurrentModificationExceptionLoopExample {
   public static void main(String[] args) {

	//   Paths
      Vector<Integer> arrlist = new Vector<Integer>();
   //   ArrayList<Integer> arrlist = new ArrayList<Integer>();
      ArrayList<Integer> aarrlist = new ArrayList<Integer>();
      arrlist.add(14);
      arrlist.add(7);
      arrlist.add(39);
      arrlist.add(40);

 //     Collections.sort(list);
      /* For Loop for iterating ArrayList */
      System.out.println("For Loop");
      for (int counter = 0; counter < arrlist.size(); counter++) {          
          System.out.println(arrlist.get(counter));   
     //     arrlist.add(41);    //no exceptions
      }       
      
       /* While Loop for iterating ArrayList*/     
      System.out.println("While Loop");     
      int count = 0;    
      while (arrlist.size() > count) {
   System.out.println(arrlist.get(count));
         count++;
      //   arrlist.add(42);    //no exceptions
      }

      /* Advanced For Loop*/    
      System.out.println("Advanced For Loop");    
      for (Integer num : arrlist) {           
           System.out.println(num);  
        //   arrlist.add(55);        //java.util.ConcurrentModificationException 
      }

     

      /*Looping Array List using Iterator*/
      System.out.println("Iterator");
      Iterator iter = arrlist.iterator();
      while (iter.hasNext()) {
         System.out.println(iter.next());
      //    arrlist.add(66);           //java.util.ConcurrentModificationException 
      }
      
      // Getting ListIterator
      System.out.println(" List Iterator");
  ListIterator<Integer> ListIterator = arrlist.listIterator();
  
  // Traversing elements
  while(ListIterator.hasNext()){
     System.out.println(ListIterator.next());   
    // arrlist.add(77);   //java.util.ConcurrentModificationException    fail fast
  }
       // /*Looping Array List using Enumurations*/
       // Get Enumeration of Vector elements work fine        compile time error with arraylist 
       System.out.println("Enumurations");
      Enumeration en = arrlist.elements();
      while(en.hasMoreElements())  {             
      System.out.println(en.nextElement());
     // arrlist.add(88);               //fail safe but work only for legacy else give compile time error
  }   
   }
}
