package A8Inter2020Java;

public class CTestHashCode {

	public static void main(String[] args) {
		Object key = "Tcs";
		int h = 0;
		h = key.hashCode() ^ (h >>> 16);
		System.out.println(h);
	}

}
