package A8Inter2020Java;

class OZ1instanceofOperator {
    public static void main(String[] args) {
      
      String test = "asdf";
      boolean result;
      
      result = test instanceof String;
      System.out.println(result);
    }
}