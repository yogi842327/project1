package Inter2020Java;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;
//preparedstatement sqlinjection: uname='virat'--' and upwd='anushka'  ,uid=101 OR 1=1;
public class A103Jdbcpreparestmt {
	public static void main(String[] args) throws Exception {

		// prepared statement
		String driver = "oracle.jdbc.OracleDriver";
		String jdbc_url = "jdbc:oracle:thin:@localhost:1521:XE";
		String user = "scott";
		String pwd = "tiger";
		Class.forName(driver);
		Connection con = DriverManager.getConnection(jdbc_url, user, pwd);
		String sqlQuery = "insert into employees values(?,?,?,?)";
		PreparedStatement pst = con.prepareStatement(sqlQuery);

		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("Employee Number:");
			int eno = sc.nextInt();
			System.out.println("Employee Name:");
			String ename = sc.next();
			System.out.println("Employee Sal:");
			double esal = sc.nextDouble();
			System.out.println("Employee Address:");
			String eaddr = sc.next();
			pst.setInt(1, eno);
			pst.setString(2, ename);
			pst.setDouble(3, esal);
			pst.setString(4, eaddr);
			pst.executeUpdate();
			System.out.println("Record Inserted Successfully");
			System.out.println("Do U want to Insert one more record[Yes/No]:");
			String option = sc.next();

			if (option.equalsIgnoreCase("No")) {
				break;
			}
		}
		con.close();

	}
}

/*
 * //preparedstatement The main advantage of PreparedStatement is the query will
 * be compiled only once even though we are executing multiple times, so that
 * overall performance of the application will be improved. select * from trains
 * where source='XXX' and destination='YYY' //lakh of time execute query sourc e
 * destination only changed //PreparedStatment
 * pst=con.prepareStatement(sqlQuery); //insert into employees
 * values(100,'durga',1000,'hyd'); insert into employees values(?, ?, ?, ?);
 * Positional Parameter OR Place Holder OR IN Parameter The sql query with
 * positional parameter(?) is called dynamic query. Eg: select * from employees
 * where esal>?
 *  It prevents SQL Injection Attack.
 *  Sql injection:
 *  Every time the query will be compiled and executed. Some times end user may provide special
characters as the part user input,which may change behaviour of sql query.This is nothing but SQL
Injection Attack,which causes security problems.
select * from users where uid=101 OR 1=1;
select count(*) from users where uname='durga'--' and upwd='anushka'
 */