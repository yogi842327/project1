package Inter2020Java;

import java.sql.*;

public class A101JdbcDrivers {
	public static void main(String[] args) throws Exception {
		String driver = "oracle.jdbc.OracleDriver";
		String jdbc_url = "jdbc:oracle:thin:@localhost:1521:XE";
		String user = "scott";
		String pwd = "tiger";
		// create table 
		String sql_query = "create table employees(eno number,ename varchar2(10),esal numb	er,eaddr varchar2(10))";
		 // Load driver class
		Class.forName(driver);
		// Obtain a connection
		Connection con = DriverManager.getConnection(jdbc_url, user, pwd);
		// Obtain a statement
		Statement st = con.createStatement();
		st.executeUpdate(sql_query);
		System.out.println("Table Created Successfully");
		
		con.close();
	}

}



/*
 * A>
1. Load and Register Driver
2. Establish Connection between Java Application and Database
3. Create Statement Object
4. Send and Execute SQL Query
5. Process Results from ResultSet
6. Close Connection
Drivemanager:It is responsible to manage all Database Drivers available in our System.
DriverManager is responsible to establish Connection to the Database with the help of Driver
Software
Without Driver Software we cannot touch Database. ex: ojdbc14.jar, ojdbc6.jar, ojdbc7.jar, mysql-connector.jar
Connection con = DriverManager.getConnection (jdbcurl, username, pwd);

DatabaseDriver/software :It is responsible to convert Java Calls into Database specific Calls and Database specific Calls
Without Driver Software we cannot touch Database. 
into Java Calls.
	Driver Manager:
	Type1:	Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
	 Connection con=DriverManager.getConnection("jdbc:odbc:demodsn7","scott","tiger"		
Type2:Class.forName("oracle.jdbc.OracleDriver");
	  Connection con= DriverManager.getConnection("jdbc:oracle:oci:@XE","scott","tiger");
Type3:Class.forName("ids.sql.IDSDriver");
	  7) Connection con= DriverManager.getConnection("jdbc:ids://localhost:12/conn?dsn=m
			  ysysdsn","scott","tiger");
Type4:Class.forName("oracle.jdbc.OracleDriver");
7) Connection con= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE
","scott","tiger");
type 5:
his Driver introduced by "Progress Data Direct" Software Company.
This Driver is the enhanced Version of Type-4 Driver.
This Driver is not Industry recognized Driver.
type
If Driver won't require any extra Component to communicate with Database, such type of Driver is
called Thin Driver.
*/	