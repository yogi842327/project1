package Inter2020Java;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Types;

//procedure callablestatement
public class A105JdbcProcedureCallable {
	public static void main(String[] args) throws Exception {
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","durga");
				CallableStatement cst=con.prepareCall("{?=call getAvg(?,?)}");
				 cst.setInt(2,100);
				 cst.setInt(3,200);
				 cst.registerOutParameter(1,Types.FLOAT);
				 cst.execute();
				 System.out.println("Salary ..."+cst.getFloat(1));
				 con.close();	
	}

}

/*i.e if we want to work with multiple queries then we should go for Statement object.
2. If we want to work with only one query,but should be executed multiple times then we should
go for PreparedStatement.
3. If we want to work with stored procedures and functions then we should go for
CallableStatement

CS cst = con.prepareCall("{? = call getAvg(?,?)}"); //getAvg is function
		Functions are exactly same as procedures except that function has return statement directly.
				Procedure can also returns values indirectly in the form of OUT parameters.
				Usually we can use procedure to define business logic and we can use functions to perform some
				calculations like getAverage() , getMax() etc..
				//create or replace procedure getAllEmpInfo2(initchars IN varchar,emps OUT SYS_REFCURSO
				R) as
				2) BEGIN
				3) open emps for
				4) select * from employees where ename like initchars;
				5) END;
				
				threded procedure is a triggers It is a special type of stored procedure that is invoked automatically in response to an event
				
						*/

