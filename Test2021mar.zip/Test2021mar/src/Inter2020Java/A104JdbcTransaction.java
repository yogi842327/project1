package Inter2020Java;

import java.sql.*;
import java.sql.ResultSet;
import java.util.Scanner;

//transaction
public class A104JdbcTransaction {
	public static void main(String[] args) throws Exception {
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","scott","tiger");
				 Statement st = con.createStatement();
				 System.out.println("Data before Transaction");
				 System.out.println("-------------------------");
				 ResultSet rs =st.executeQuery("select * from accounts");
				 while(rs.next())
				 {
				 System.out.println(rs.getString(1)+"..."+rs.getInt(2));
				 }
				 System.out.println("Transaction begins...");
				 con.setAutoCommit(false);
				 st.executeUpdate("update accounts set balance=balance-10000 where name='durga'");
				 st.executeUpdate("update accounts set balance=balance+10000 where name='sunny'");
				 System.out.println("Can you please confirm this transaction of 10000....[Yes|No]");
				 Scanner sc = new Scanner(System.in);
				 String option = sc.next();
				 if(option.equalsIgnoreCase("yes"))
				 {
				 con.commit();
				 System.out.println("Transaction Commited");
				 }
				 else
				 {
				 con.rollback();
				 System.out.println("Transaction Rolled Back");
				 }
				 System.out.println("Data After Transaction");
				 System.out.println("-------------------------");
				 ResultSet rs1 =((java.sql.Statement) st).executeQuery("select * from accounts");	
	while(rs1.next())

	{
		System.out.println(rs1.getString(1) + "..." + rs1.getInt(2));
	}con.close();
}

}

/*
Transaction
By default auto commit mode is enabled. i.e after executing every sql query, the changes will be
committed automatically in the database.
We can disable auto commit mode as follows
con.setAutoCommit(false);
2. If all operations completed then we can commit the transaction by using the following method.
con.commit();
3. If any sql query fails then we have to rollback operations which are already completed by using
rollback() method.
con.rollback();
Savepoint sp = con.setSavepoint();
con.rollback(sp);
Operation-4;
Operation-5;
if(balance<10000)
{
con.rollback(sp);
}
else
{
con.releaseSavepoint(sp);
Within a transaction if we want to rollback a particular group of operations based on some
condition then we should go for Savepoint.

1. A Atomiticity
Either all operations should be done or None.
2. C  Consistency(Reliabile Data)
It ensures bringing database from one consistent state to another consistent state.
3. I isolation (Sepatation)
Ensures that transaction is isolated from other transactions
4. D Durability
It means once transaction committed, then the results are permanent even in the case of
system restarts, errors etc.
*/