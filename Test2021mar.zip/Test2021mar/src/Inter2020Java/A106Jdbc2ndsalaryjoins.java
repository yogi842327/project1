package Inter2020Java;

//NthHighestSalaryEmpDemo
public class A106Jdbc2ndsalaryjoins {

}

/*Indexing:
data is stored in the form of records. Every record has a key field, which helps it 
to be recognized uniquely.
mysql> CREATE INDEX class ON student (class);  
fast performance dont check whole table just check fieldname can ceate drop update indexes

nth highest salary;
select * from Employee ORDER BY `salary` DESC limit 4,3 ; // 4 means 5th highest salary and 3 means 
2nd highest salary
SELECT Salary FROM (SELECT Salary FROM Employee ORDER BY salary DESC LIMIT 2) AS Emp ORDER BY salary LIMIT 1;
SELECT TOP 1 Salary FROM ( SELECT TOP 2 Salary FROM Employee ORDER BY Salary DESC) AS MyTable ORDER BY Salary ASC;
Find duplicate records: mysql> select name, count(name) from contacts group by name;
Join:
	An SQL join clause combines columns from one or more tables in a relational database. 
	Inner Join:
	SELECT StudentCourse.COURSE_ID, Student.NAME, Student.AGE FROM Student
	INNER JOIN StudentCourse
	ON Student.ROLL_NO = StudentCourse.ROLL_NO;*/

