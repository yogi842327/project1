package Inter2020Java;

public class A107JdbcOther {
	public class A105JdbcProcedureCallable {
		
	}
	
	

}

/*Cursor
//The results of SQL Queries will be stored in special memory area inside database software. This
memory area is called Context Area.
1. Implicit cursors
2. Explicit cursors
excel sheet : ResultSet rs=st.executeQuery("select * from [Sheet1$]");
Metadata 1. DatabaseMetaData 2. ResultSetMetaData 3. ParameterMetaData
Metadata provides extra information about our original
data. version,drivername,rowcount etc
Rowset: It is alternative to ResultSet.
We can use RowSet to handle a group of records in more effective way than ResultSet.
RowSet interface present in javax.sql package: cachedrowset,jdbc,webrowset
Connection Pool is a pool of already created Connection objects which are ready to use.
DataSource is responsible to manage connections in Connection Pool.
property: bdname pass username 
FileInputStream fis = new FileInputStream("db.properties");
view: Though a view doesn't store data, some refer to a views as �virtual tables,
CREATE VIEW [Products Above Average Price] AS
SELECT ProductName, Price
FROM Products
WHERE Price > (SELECT AVG(Price) FROM Products);*/
