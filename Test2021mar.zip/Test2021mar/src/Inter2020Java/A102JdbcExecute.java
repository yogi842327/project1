package Inter2020Java;

import java.sql.*;
import java.util.Scanner;

//execute and resultset
public class A102JdbcExecute {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		//1> resultset executeQuery for select, returntype ResultSet
		Class.forName("oracle.jdbc.OracleDriver");
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "scott", "tiger");
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("select * from movies");
		while (rs.next()) {

			System.out.println(rs.getInt(1) + "\t" + rs.getString(2) + "\t" + rs.getString(3) + "\t" + rs.getString(4));
		}

		//2> insert table data executeUpdate() //fornon select, returntype int
		String sql_query1 = "insert into employees values(100,'durga',1000,'hyd')";
		Statement st1 = con.createStatement();
		int updateCount = st1.executeUpdate(sql_query1);

		//3> execute for both select non select, returntype  bool
		/*
		 * isResultSet = stmt.execute("select 'Hello '||USER from dual"); if
		 * (isResultSet) { rslt = stmt.getResultSet( ); }else{ non select }
		 */
		Statement st2 = con.createStatement();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Query: ");
		String sqlQuery = sc.nextLine();
		boolean b = st.execute(sqlQuery);
		if (b == true)// select query
		{

			ResultSet rs2 = st.getResultSet();
			while (rs2.next()) {
				System.out.println(
						rs2.getInt(1) + "\t" + rs2.getString(2) + "\t" + rs2.getDouble(3) + "\t" + rs2.getString(4));
			}
		} else // non-select query
		{
			int rowCount = st.getUpdateCount();
			System.out.println("The number of records effected is:" + rowCount);
		}

		//int[] executeBatch()	//array of inte
		Statement stmt=con.createStatement();  
		stmt.addBatch("insert into user420 values(190,'abhi',40000)");  
		stmt.addBatch("insert into user420 values(191,'umesh',50000)");  
		  
		stmt.executeBatch();//executing the batch 
	   //pstmt.executeBatch();//executing the batch of prepared statements too 
		con.close();
	}

	//
}

/*
 * 1. executeQuery() //select operations //public ResultSet executeQuery(String * sql):
 *  ResultSet rs = st.executeQuery("select * from movies");
 *  2. * executeUpdate() //public int executeUpdate(String sql): //
 * (Insert|Delete|Update) Numeric Value represents the Number of Rows effected.
 * Hence Return Type of this Method is int
 *  int rowCount = st.executeUpdate(
 * "delete from employees where esal>100000"); 
 * 3. execute()//can use both select non selct , public boolean execute(String sql): boolean isResultSet = false;
 * Statement stmt = null; ResultSet rslt = null; try { stmt =
 * conn.createStatement( ); isResultSet = stmt.execute(
 * "select 'Hello '||USER from dual");
 *  if (isResultSet) { rslt = stmt.getResultSet( ); }else{ non select } . . . }
 * 4> int[] executeBatch()	It executes the batch of queries.
 * Instead of executing a single query, we can execute a batch (group) of queries. 
 * It makes the performance fast
 * void addBatch(String query)	It adds query into batch
 * 
 * 
 * //ResultSet After executing Select Query, Database Engine will send Result
 * back to Java Application. This Result is available in the form of ResultSet.
 * i.e. ResultSet holds Result of executeQuery() Method, which contains a Group
 * of Records. By using ResultSet we can get Results.
 * 
 * while(rs.next()) 2) { 3)
 * SOP(rs.getInt("ENO")+".."+rs.getString("ENAME")+".."+rs.getDouble("ESAL")+
 * ".."+rs.getS tring("EADDR")); 4) OR 5)
 * SOP(rs.getInt(1)+".."+rs.getString(1)+".."+rs.getDouble(3)+".."+rs.getString(
 * 4)); 6) } Readability wise it is recommended to use Column Names, but
 * Performance wise it is recommended to use Column Index
 * 
 * 1. ResultSet follows "Iterator" Design Pattern. 2. ResultSet Object is always
 * associated with Statement Object. 3. Per Statement only one ResultSet is
 * possible at a time. if we are trying to open another ResultSet then
 * automatically first ResultSet will be closed. Eg: 
 * Statement st = * con.createStatement(); 
 * RS rs1 = st.executeQuery("select * from movies"); 
 * RS  * rs2 = st.executeQuery("select * from employees"); 
 * In the above Example Rs1  * will be closed automatically whenever we are trying to open Rs2.
 * rs.close(),st/close,con.close() Per Statement only one ResultSet is possible
 * at a time. Per Connection multiple Statement Objects are possible. Whenever
 * we are closing Statement Object then automatically the corresponding
 * ResultSet will be closed. Similarly, whenever we are closing Connection
 * Object automatically corresponding Statement Objects will be closed. Hence we
 * required to use only con.close();
 */
