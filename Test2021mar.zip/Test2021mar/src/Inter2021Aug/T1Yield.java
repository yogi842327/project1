package Inter2021Aug;


class MyRunnable1 implements Runnable{
    public void run(){
           for(int i=0;i<5;i++){
                  Thread.yield();
                  System.out.println("i="+i+" ,ThreadName="+Thread.currentThread().getName());
           }          
    }
}
 
class MyRunnable2 implements Runnable{
    public void run(){
           for(int i=0;i<5;i++){
                  System.out.println("i="+i+" ,ThreadName="+Thread.currentThread().getName());
           }          
    }
}
 
/** Copyright (c), AnkitMittal JavaMadeSoEasy.com */
public class T1Yield {
    public static void main(String...args){
           Thread thread1=new Thread(new MyRunnable1(),"Thread-1");
           Thread thread2=new Thread(new MyRunnable2(),"Thread-2");
           thread1.start();
           thread2.start();
    }
}
 
//https://www.javamadesoeasy.com/2015/03/yield-method-in-threads-8-key-features.html

/*when yield() method is called on thread it goes from running to runnable state, not in waiting state. Thread is eligible to run 
but not running and could be picked by scheduler at the discretion of the implementation.
In java 5, yield() method internally used to call sleep()
java 6, calling yield() method gives a hint to the
java.lang package
*/