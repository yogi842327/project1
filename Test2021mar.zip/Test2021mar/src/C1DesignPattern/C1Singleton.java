package C1DesignPattern;

public class C1Singleton {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	// Static attribute.
    private static C1Singleton instance = null;
 
    // Private constructor.
    private C1Singleton() {
 
    }
 
    // Static function.
    public static C1Singleton getInstance() {
        // If there is no instance available, create new one (i.e. lazy initialization).
        if (instance == null) {
            instance = new C1Singleton();
        }
        return instance;
    }
}
	

//https://www.journaldev.com/1377/java-singleton-design-pattern-best-practices-examples
//https://www.geeksforgeeks.org/singleton-design-pattern/
//https://www.javatpoint.com/singleton-design-pattern-in-java	
/*//To create the singleton class, we need to have static member of class, private constructor and static factory method.

Static member: It gets memory only once because of static, itcontains the instance of the Singleton class.
Private constructor: It will prevent to instantiate the Singleton class from outside the class.
Static factory method: This provides the global point of access to the Singleton object and returns the instance to the caller.

To create the singleton class, we need to have static member of class, private constructor and static factory method.
�	Static member: It gets memory only once because of static, itcontains the instance of the Singleton class.
�	Private constructor: It will prevent to instantiate the Singleton class from outside the class.
�	Static factory method: This provides the global point of access to the Singleton object and returns the instance to the caller.

*/
