package B3Multithreading;



// use loop value minimum 15 20
 class MThread extends Thread {
		// TODO Auto-generated constructor stub
	public void run() {
	//	System.out.println("Child : " );
		for(int i=0;i<3;i++) {
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		//	Thread.yield(); // pause the thread and give the chance to same priority thread whose thread waiting from long time
			System.out.println(" Child 1 thread ");
			
		}	
	}
}

 class R3MyMainThread   {
		public static void main(String args[]) throws InterruptedException {
			MThread t=new MThread();
			
			MThread2 r=new MThread2();
			Thread t2=new Thread(r);
			MThread5 t3=new MThread5();
			// t2.setPriority(9);
			// t.setPriority(Thread.MAX_PRIORITY);
	//System.out.println("New thread: " + t);

	t.start();
	t2.join(); // can use   t1.join(1500); or The join() method waits for a thread to die mns until comlete thread,throws InterruptedException
    t.interrupt(); //. However, the interrupt method can be used to request termination of a thread.
	t2.start();
	t3.start();
	

	
	//	System.out.println("Main : " + t);
	for(int i=0;i<4;i++) {
		System.out.println(" Main // thread ");
		
	}	
	}
}
 
	 class MThread2 implements Runnable {
			// TODO Auto-generated constructor stub
		public void run() {
		//	System.out.println("Child : " );
			for(int i=0;i<2;i++) {
				try {
					//	Thread.yield(); // pause the thread and give the chance to same priority thread whose thread waiting from long time
					Thread.sleep(200);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			//	Thread.yield(); // pause the thread and give the chance to same priority thread whose thread waiting from long time
				System.out.println(" Child 2 thread ");
				
			}	
		
		
	}
}
	  
 
 class MThread5 extends Thread{
		// TODO Auto-generated constructor stub
	public void  run() {
	//	System.out.println("Child : " );
		for(int i=0;i<5;i++) {
		//	Thread.yield(); // pause the thread and give the chance to same priority thread whose thread waiting from long time
			System.out.println(" Child 4 thread ");
			
		}	
		
		
	}
}
 
 
