package B3Multithreading;

class Second {
	// public void print(int n) // if dont use synchronized then we get the mix
	// output
	public synchronized void print(int n) // not required to whole method syncronized
	{
		synchronized (this) {// synchronized block //non static methods inside is non static block work on
								// object level lock
			for (int i = 1; i <= 5; i++) {
				System.out.println(n * i);
				try {
					Thread.sleep(500);

				} catch (Exception e) {
					System.out.println(e);
				}

			}
		}

	}

	public static void printstaticblock(int n) {
		synchronized (Second.class) {// synchronized block //static methods inside is static block work on class
										// level lock
			for (int i = 1; i <= 5; i++) {
				System.out.println(n * i + "static");
				try {
					Thread.sleep(500);

				} catch (Exception e) {
					System.out.println(e);
				}

			}
		}

	}
	
	static class Sharedblock
	{
		synchronized  static void staticMethod1()
	    {
	        //static synchronized method
			System.out.println("Static sep block");
	    }
	 
	    synchronized void NonStaticMethod()
	    {
	        //Non-static Synchronized method
	    	System.out.println("Static sep block");
	    }
	}
}

class Third extends Thread {
	Second d;

	Third(Second d) {
		this.d = d;
	}

	public void run() {
		// d.print(5);
		d.printstaticblock(5);

	}

}

class Fourth extends Thread {
	Second d;

	Fourth(Second d) {
		this.d = d;
	}

	public void run() {
		// d.print(10);
		d.printstaticblock(10);
	}
}

public class S1Synchronized1 {
	public static void main(String args[]) {
		Second d = new Second();
		Third ob1 = new Third(d);
		Fourth ob2 = new Fourth(d);

		
		ob2.start();
		ob1.start();
	}

}