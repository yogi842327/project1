
package B3Multithreading;
//https://www.geeksforgeeks.org/callable-future-java/
public class R6callable {
	public static void main(String[] args) throws Exception 
	  {
	/*	 Object call() throws Exception 
	    { 
	        // Create random number generator 
	        Random generator = new Random(); 
	  
	        Integer randomNumber = generator.nextInt(5); 
	  
	        // To simulate a heavy computation, 
	        // we delay the thread for some random time 
	        Thread.sleep(randomNumber * 1000); 
	  
	        return randomNumber; 
	    } */
	  }

}
