package B3Multithreading;

import java.util.HashSet;
import java.util.Hashtable;

public class R2runnablethread2 implements Runnable{
	public static void main(String args[]) {
		R2runnablethread2 r=new R2runnablethread2() ;

		Thread t2=new Thread ();
		Thread t3=new Thread (r);
		R1Thread1 t4=new R1Thread1();
		System.out.println(Thread.currentThread().getName()+"Thread Name");
		Thread.currentThread().setName("Yogi");
		System.out.println(Thread.currentThread().getName()+" set Thread Name");
		t3.setPriority(8);
		t4.setPriority(9);
		
		//r.start();////if r.start excpetion:The method start() is undefined for the type runnablethread2
		// r.run(); //if r.run The method runn() is called like normal run methods
		

	//	t2.start();////if t2.start excpetion:The method start() is undefined for the type runnablethread2
	//	t2.run(); //worked :if t2.run just like normal methods call
		
		
	//	t3.run(); //call like normal method not create thread method run
		System.out.println(t2.getPriority()+"Priority");
		
	//	t3.start();// call like start method
		t4.start();
		t3.setPriority(6);
		for(int i=0;i<4;i++) {
			System.out.println(" Main thread ");
			
		}
		System.out.println(t3.getPriority()+"Priority");
		
	}
	public void run() {
		for(int i=0;i<5;i++) {
			System.out.println(" Child thread ");
			
		}
		
		

	}

}
