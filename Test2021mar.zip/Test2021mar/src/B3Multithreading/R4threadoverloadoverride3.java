package B3Multithreading;

public class R4threadoverloadoverride3 extends Thread  {
	
	public void run() {
		System.out.println(" Normal run mrthod");
		
	}
	void run(int i) {
		System.out.println(" int run mrthod");
		
	}
	void run(int i,float j) {
		System.out.println(" float run mrthod");
		
	}
	// start method work like normal methods
/*	public void start() {
		System.out.println(" start mrthod");
		
	}*/
	public static void main(String[] args) {
		R4threadoverloadoverride3 t1=new R4threadoverloadoverride3();
		t1.run(3);
		t1.start(); 
	//	t1.start(); // if start method twice :Exception in thread "main" java.lang.IllegalThreadStateException
		//start 1 thread run normal start methods not overloaded start method comment start
		////start 2 thread run normal start methods not overloaded start method comment start
		System.out.println(" Main run mrthod");
		
	}

}
