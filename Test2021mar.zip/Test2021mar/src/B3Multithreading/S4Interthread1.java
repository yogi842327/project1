package B3Multithreading;

public class S4Interthread1 {

	public static void main(String[] args) throws InterruptedException {

		Thread22 r = new Thread22();
		Thread t1=new Thread(r);
		Thread23 r1 = new Thread23();
		Thread t2=new Thread(r1);
		t2.start();
		t1.start();
		
		synchronized (t1) {
			System.out.println(" Main thread trying to get wait ");
			t1.wait();
			System.out.println(" Main thread got to notifications ");
			System.out.println(" Total "+r.total);
			t2.notifyAll();
		}
		
	}

}

class Thread22 extends S4Interthread1 implements Runnable{
	int total = 0;

	public void run() {

		synchronized (this) {
			System.out.println(" Child thread start notifications ");
			for (int i = 1; i <= 10000; i++) {
				total = total + i;
			}

			System.out.println(" Child thread trying to given notifications ");
			this.notifyAll();
		}
	}
}

class Thread23 extends S4Interthread1 implements Runnable{
	int total = 0;

	public void run() {

		synchronized (this) {
			System.out.println(" Child1 thread start notifications ");
			
			for (int i = 1; i <= 10000; i++) {
				total = total + i;
			}

			System.out.println(" Child1 thread trying to given notifications ");
		//	this.notify();
		}
	}
}