package B3Multithreading;

public class R1Thread1 extends Thread {
	
	public static void main(String args[]) {
		
		R1Thread1 t1=new R1Thread1();
	//	t1.run();// call like normal run methos first cq
		t1.run();
		//	t1.start();  
			// we can not start thread twice :java.lang.IllegalThreadStateException
			for(int i=0;i<4;i++) {
				System.out.println(" Child thread ");
				
			}	
		
	}
//	class Mythreade1 
	
	public void run()
	{
		for(int i=0;i<4;i++) {
			System.out.println(" Main thread ");
			
		}
	}
	}


