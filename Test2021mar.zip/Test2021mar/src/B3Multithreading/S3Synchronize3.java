package B3Multithreading;

	class S3Synchronize3 extends Thread {
	    Calculator c;
	    public S3Synchronize3(Calculator calc) {
	        c = calc;
	    }

	    public void run() {
	        synchronized(c) {                              //line 9
	        try {
	            System.out.println("Waiting for calculation...");
	            c.wait();
	        } catch (InterruptedException e) {}
	            System.out.println("Total is: " + c.total);
	        }
	    }

	    public static void main(String [] args) {
	        Calculator calculator = new Calculator();
	        new S3Synchronize3(calculator).start();
	        new S3Synchronize3(calculator).start();
	        new S3Synchronize3(calculator).start();
	        calculator.start();
	    }
	}

	class Calculator extends Thread {
	    int total;
	    public void run() {
	        synchronized(this) {                     //Line 31
	            for(int i=0;i<100;i++) {
	                total += i;
	            }
	             notifyAll();
	             try {
					sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }
	    } 
	}
