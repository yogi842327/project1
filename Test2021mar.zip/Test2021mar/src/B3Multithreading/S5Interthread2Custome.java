package B3Multithreading;

import java.util.concurrent.CyclicBarrier;

public class S5Interthread2Custome {

	public static void main(String[] args) {
		final Customer c = new Customer();
		new Thread() {
			public void run() {
				c.withdra(1500);
			}
		}.start();
		new Thread() {
			public void run() {
				c.deposit(1500);
			}
		}.start();
	}
}

class Customer {
	int ammount = 1000;

	synchronized void withdra(int amount) {
if(this.ammount<amount) {
	System.out.println("Withdraw STart");
try {
	wait();
} catch (InterruptedException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}	
System.out.println("Withdra finished");
}

	}

	synchronized void deposit(int amount) {

		if(this.ammount<amount) {
			System.out.println("Deposit start");
			this.notify();
		System.out.println("Deposit  finished");
		}
	//	CyclicBarrier
}
}