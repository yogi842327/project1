package B3Multithreading;

//https://examples.javacodegeeks.com/core-java/java-volatile-keyword-example/
//https://www.geeksforgeeks.org/volatile-keyword-in-java/

/**
 * Java program to demonstrate where to use Volatile keyword in Java. In this
 * example Singleton Instance is declared as volatile variable to ensure every
 * thread see updated value for _instance.
 * 
 * @author Javin Paul
 */
public class S8Volatile1 {

	private final static int TOTAL_THREADS = 2;

	public static void main(String[] args) throws InterruptedException {
		VolatileData volatileData = new VolatileData();

		Thread[] threads = new Thread[TOTAL_THREADS];
		for (int i = 0; i < TOTAL_THREADS; ++i)
			threads[i] = new VolatileThread(volatileData);

		// Start all reader threads.
		for (int i = 0; i < TOTAL_THREADS; ++i)
			threads[i].start();

		// Wait for all threads to terminate.
		for (int i = 0; i < TOTAL_THREADS; ++i)
			threads[i].join();
	}
}

class VolatileThread extends Thread {
	private final VolatileData data;

	public VolatileThread(VolatileData data) {
		this.data = data;
	}
}

class VolatileData {

	private volatile int counter = 0;

	public int getCounter() {
		return counter;
	}

	public void increaseCounter() {
		++counter;
	}
}

/*
//Synchronized Vs Atomic Vs Volatile:
1. Volatile and Atomic is apply only on variable , While Synchronized apply on method.
2. Volatile ensure about visibility not atomicity/consistency of object , While other both ensure about visibility and atomicity.
3. Volatile variable store in RAM and it�s faster in access but we can�t achive Thread safety or synchronization whitout synchronized keyword.
4. Synchronized implemented as synchronized block or synchronized method while both not. We can thread safe multiple line of code with help of synchronized keyword while with both we can�t achieve the same.
5. Synchronized can lock the same class object or different class object while both can�t.
https://stackoverflow.com/questions/9749746/what-is-the-difference-between-atomic-volatile-synchronized
*/