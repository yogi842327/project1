package B3Multithreading;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class S9SynchronizedArrayListDemo {

	public static void main(String args[]) {

		//https://www.javamadesoeasy.com/2015/04/arraylist-vs-vector-similarity-and.html
		//java.util.ArrayList is not synchronized  (because 2 threads on same ArrayList object can access it at same time). 
		//java.util.Vector is synchronized (because 2 threads on same Vector object cannot  access it at same time).
		// An ArrayList which is not synchronize
		List<String> listOfSymbols = new ArrayList<String>();

		listOfSymbols.add("RELIANCE");
		listOfSymbols.add("TATA");
		listOfSymbols.add("TECHMAH");
		listOfSymbols.add("HDFC");
		listOfSymbols.add("ICICI");

		// Synchronizing ArrayList in Java
		listOfSymbols = Collections.synchronizedList(listOfSymbols);

		// While Iterating over synchronized list, you must synchronize
		// on it to avoid non-deterministic behavior

		synchronized (listOfSymbols) {
			Iterator<String> myIterator = listOfSymbols.iterator();

			while (myIterator.hasNext()) {
				System.out.println(myIterator.next());
			}
		}

	}

}
