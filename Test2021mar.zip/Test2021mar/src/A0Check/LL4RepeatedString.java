package A0Check;

//https://github.com/RyanFehr/HackerRank/blob/master/Algorithms/Implementation/Repeated%20String/Solution.java
public class LL4RepeatedString {
	public static void main(String args[]) {
		
        //1st with time comment s and n  and paste in Solutions why line no 13 logic
		long n = 10;
        String s="aba";
        long countForSubstring = 0;
        long totalCount = 0;
        
        //Determines how many a's are in a substring
        for(int i = 0; i < s.length(); i++)
        {
            if(s.charAt(i) == 'a')
            {
                countForSubstring++;
            }
        }
        
        
        //Determines how many complete substrings we will analyze
        long divisor = n / s.length();
        
        totalCount += divisor * countForSubstring;
        
        
        //Determines how many characters in we will analyze towards the end of our n range
        long remainder = n % s.length();
        
        for(int i = 0; i < remainder; i++)
        {
            if(s.charAt(i) == 'a')
            {
                totalCount++;
            }
        }
        
        //return totalCount;
        System.out.println("1st with time "+totalCount);
    


		
		//1 time cplexity
		String s1 = "aba";
		String s2Create = "";
		long n1 = 10;
		long totalCount1=0;
		long divisor1=0;
		long count1=0;
		//Determines how many complete substrings we will analyze
        divisor = n1 / s1.length();
        
    //    totalCount += divisor * countForSubstring;
        
        //Determines how many characters in we will analyze towards the end of our n range
        long remainder1 = n1 % s1.length();
		for(int ii=1;ii<=divisor;ii++) {
			s2Create+=s1;
		}
		
		System.out.println("s2.1st...  " + s2Create);
		char[] itemsArray =s1.toCharArray();
		for(int y=0;y<=remainder1-1;y++) {
			s2Create+=itemsArray[y];
		}
		
		System.out.println("s2....  " + s2Create);
		for(int z=0;z<=s2Create.length()-1;z++) {
			if(s2Create.charAt(z)=='a') {
				count1++;	
			}
			//s2Create+=itemsArray[i];

		/*		char[] itemsArray1 =s2Create.toCharArray();
		for(int i=0;i<=s2Create.length()-1;i++) {
			if(itemsArray1[i]=='a') {
				count++;	
			}
			//s2Create+=itemsArray[i];
*/		}
		System.out.println("s2....  " + s2Create);
		System.out.println("count 3....  " + count1);
        
		
		//3
		//String s = "abcac";
		//String s = "aba";
		String s4 = "a";
		long n4 = 10;
		int strLength = s4.length();
		long q = 0, r = 0;
		q = n4 / strLength;
		r = n4 % strLength;
		long partialStrLen = (r == 0) ? 0 : r;
		long aCount = q * getLetterCount(s4, s4.length()) + getLetterCount(s4, partialStrLen);
//	    return aCount;
		System.out.println("main ....  " + aCount);
	}

	public static long getLetterCount(String s4, long strLength) {
		long count = 0;
		for (int i = 0; i < strLength; i++) {
			if (s4.charAt(i) == 'a')
				count++;
		}
		return count;
	}
}
