package A0Check;

import java.util.ArrayList;
import java.util.List;

public class L2JumpingClouds {

	public static void main(String args[]) {
	List<Integer> c = new ArrayList<Integer>();
	//0 0 0 1 0 0 >3
	//0 0 1 0 0 1 0  >4
	c.add(0);
	c.add(0);
	c.add(0);
	c.add(1);
	c.add(0);
	c.add(0);
	
	Integer[] itemsArray = new Integer[c.size()]; 
	itemsArray = c.toArray(itemsArray);
	int countJump=0;
	for(int i = 0; i < itemsArray.length-1;)
    {
		if(!itemsArray[i+2].toString().equalsIgnoreCase("1"))
				{
			countJump=++countJump;
			i=i+2;
			
		}
		/*if(!itemsArray[i].equalsIgnoreCase("1"))
		{
	    countJump=++countJump;
	   i=i++;
	
}*/
		else {
			if(itemsArray[i].toString().equalsIgnoreCase("0"))
			{
				countJump=++countJump;
				i=++i;		
			}
			
		}
    }
	
	System.out.println("main ....  "+ countJump);
	
}
}