package A0Check;

import java.util.Scanner;
//https://www.geeksforgeeks.org/maximum-sum-hour-glass-matrix/
public class L5Array2dHourGlass {
	static int R = 6;
	static int C = 6;
	public static void main(String[] args) {
       
		int val =0; 
		int[][] mat = { { 1, 1, 1, 0, 0, 0}, { 0, 1, 0, 0, 0, 0}, {1, 1, 1, 0, 0, 0},
				{ 0 ,0, 2, 4, 4, 0}, { 0, 0, 0, 2, 0, 0 }, {0, 0, 1, 2, 4, 0} };

		int[][] mat2 = { { -9, -9, -9, 1, 1, 1 }, { 0, -9, 0, 4, 3, 2 }, { -9, -9, -9, 1, 2, 3 },
				{ 0, 0, 8, 6, 6, 0 }, { 0, 0, 0, -2, 0, 0 }, { 0, 0, 1, 2, 4, 0 } };

		
		if (R < 3 || C < 3)
	        val =-1;
			//return -1;
			
	 
	    // Here loop runs (R-2)*(C-2)
	    // times considering different
	    // top left cells of hour glasses.
	    int max_sum = Integer.MIN_VALUE;
	    for (int i = 0; i < R - 2; i++)
	    {
	        for (int j = 0; j < C - 2; j++)
	        {
	            // Considering mat[i][j] as top
	            // left cell of hour glass.
	            int sum = (mat[i][j] + mat[i][j + 1] +
	                       mat[i][j + 2]) + (mat[i + 1][j + 1]) +
	                       (mat[i + 2][j] + mat[i + 2][j + 1] +
	                       mat[i + 2][j + 2]);
	 
	            // If previous sum is less then
	            // current sum then update
	            // new sum in max_sum
	            max_sum = Math.max(max_sum, sum);
	        }
	    }
	    
	    //return max_sum;
	    System.out.println("val=...."+max_sum);
	    
	    
	    //2nd
		
		
		Scanner in = new Scanner(System.in);
        
		int a[][] = new int[6][6];
        for(int i=0; i < 6; i++){
            for(int j=0; j < 6; j++){
                a[i][j] = in.nextInt();
            }
        }
        int hg = Integer.MIN_VALUE, sum;
        for(int i=0; i<4; i++){
            for(int j=0; j<4; j++){
               sum = 0;
               sum = sum + a[i][j] + a[i][j+1] + a[i][j+2];
               sum = sum + a[i+1][j+1];
               sum = sum + a[i+2][j] + a[i+2][j+1] + a[i+2][j+2];
               if(sum>hg)
                   hg = sum;
            }
        }
        System.out.println(hg);
        in.close();
    }
}