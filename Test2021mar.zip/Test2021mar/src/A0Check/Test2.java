package A0Check;

import java.util.*;

public class Test2 {
	public static void main(String args[]) {
		//String str="123:yes;;456:no";
		String str="34419:5;;20444:yogesh";
		String[] arrOfStr = str.split(";;");
		String[] arrOfStrb=null;
		//String b;
		List<String> list = new ArrayList<>();    
		for (String a : arrOfStr)
        	list.add(a);  
            System.out.println(list);
            
            //map;
            Map map=new HashMap();  
            //Adding elements to map  
            map.put(1,"Amit");  
            for (String b : arrOfStr)
            	 arrOfStrb = b.split(":");
            map.put(Integer.valueOf(arrOfStrb[0]) ,arrOfStrb[1]);	
            //list.add(a);  
                System.out.println(map);
	}
}
