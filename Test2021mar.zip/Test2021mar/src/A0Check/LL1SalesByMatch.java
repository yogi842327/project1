package A0Check;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class LL1SalesByMatch {
	public static void main(String args[]) {
		int n=5;
		List<Integer> c = new ArrayList<Integer>();
		//0 0 0 1 0 0 >3
		//0 0 1 0 0 1 0  >4
		c.add(0);
		c.add(0);
		c.add(0);
		c.add(1);
		c.add(0);
		c.add(0);
		int[] ar= {10, 20, 20, 10, 10, 30, 50, 10, 20 };// for array comment lone 24 25
		
		HashSet<Integer> set = new HashSet<Integer>();
	    int count = 0;
	    for (int i = 0; i < n; i++) {
	    	//int element = ar[i];
	    	int element = c.get(i);
	      if (set.contains(element)) {
	        set.remove(element);
	        count++;
	      } else {
	        set.add(element);
	      }
	    }
	    System.out.println("main ....  "+ count);
	}

}
