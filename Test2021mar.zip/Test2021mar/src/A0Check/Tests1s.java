package A0Check;

public class Tests1s {
	
	public static void main(String args[]) {
		
		//https://stackoverflow.com/questions/54245366/counting-valleys
		//1   DDUUDD-2U-1DUUUD
		int n1=10;
		//String path="DUDDDUUDUU";//10 >2  DDUUDDUDUUUD>12 2  UDDDUDUU 8>1 
		String path="DDUUDDUDUUUD";
		int valleyCounter1 = 0;
		int altitude1 = 0;

	     for (int i = 0; i < n1; i++) {
	         char ch1 = path.charAt(i);
	         if (ch1 == 'U') {
	             altitude1++;
	             if (altitude1 == 0) {
	                 valleyCounter1++;
	             }

	         } else {

	             altitude1--;
	         }
	     }
	     System.out.println("Main 1 for all case......  "+ valleyCounter1);
	    
	       //3    
			String s2="DDUUDDUDUUUD";   //2 answer 
	        String[] arr = new String[s2.length()];
		    for(int i = 0; i < s2.length(); i++)
		    {
		        arr[i] = String.valueOf(s2.charAt(i));
		    }
		    
			int valeys4=0;
			int valeysHeight4=0;
			
			for(int i=0;i<arr.length;i++){    
				if(arr[i].equalsIgnoreCase("U")) {
					valeys4=++valeys4;
					//if(valeys4>=1) {
					if(valeys4==0) {
						++valeysHeight4;
					}
					}
					
				else {
					valeys4=--valeys4;
				}
				
				}
				
			System.out.println("main 4....  "+ valeysHeight4);
	
		
		//UDDDUDUU  :1
		//DDUUDDUDUUUD  :2
		//String ar[]=new  String[]{"D","D","U","U","U","U","D","D"};
		
		//2
		String ar[]=new  String[]{"U","D","D","D","U","D","U","U"};
		int n=3;
		int valeys=0;
		int valeysHeight=0;
		for(int i=0;i<=ar.length-1;i++) {
			System.out.println("ar  "+ ar[i]);
			//simple valeys count but valeys count with plus
			///ek baar valeys upar ja rayi
			if(ar[i].equalsIgnoreCase("u")) {
			valeys=++valeys;
			if(valeys>=1) {
				++valeysHeight;
			}
			}
			
		else {
			valeys=--valeys;
		}
		
		}
		System.out.println("valse  "+ valeysHeight);
		
	
	
		//3
		int valeys3=0;
		int valeysHeight3=0;
		
		String s1="DDUUDDUDUUUD";  
		char[] ch=s1.toCharArray();    
		for(int i=0;i<ch.length;i++){    
			if(ch[i]=='u' || ch[i]=='U') {
				valeys3=++valeys3;
				if(valeys3>=1) {
					++valeysHeight3;
				}
				}
				
			else {
				valeys3=--valeys3;
			}
			
			}
			
		System.out.println("main 1 and 3.....  "+ valeysHeight3);
		
		//4
				
				//2 check this logic
				int altitude=0;
				int count=0;
				for(int i=0;i<=ar.length-1;i++) {
				//	System.out.println("ar  "+ ar[i]);
					if(ar[i].equalsIgnoreCase("u")) {
						if(altitude == -1) {
		                    count++;
		                }
		                altitude++;
					
				}
				else {
					altitude++;
				}
				
				}
				System.out.println("count 2nd......  "+ count);
				
 
	}
	
	
}
