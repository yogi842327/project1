package A0Check;

import java.util.ArrayList;
import java.util.List;

public class LL3JumpingClouds {
	public static void main(String args[]) {
		Integer[] itemsArray = { 0, 0, 1, 0, 0, 0, 0 };// for array comment lone 24 25

		int countJump = 0;
		for (int i = 0; i < itemsArray.length - 1;) {
			if (!itemsArray[i + 2].toString().equalsIgnoreCase("1")) {
				countJump = ++countJump;
				i = i + 2;
			}

			else {
				if (itemsArray[i].toString().equalsIgnoreCase("0")) {
					countJump = ++countJump;
					i = ++i;
				}

			}
		}

		System.out.println("main ....  " + countJump);

		List<Integer> c = new ArrayList<Integer>();
		// 0 0 0 1 0 0 >3
		// 0 0 1 0 0 1 0 >4
		c.add(0);
		c.add(0);
		c.add(0);
		c.add(1);
		c.add(0);
		c.add(0);

		/*
		 * Integer[] ar = new Integer[c.size()]; ar = c.toArray(ar);
		 */
		int countJump1 = 0;
		for (int i = 0; i < c.size() - 1;) {
			if (!c.get(i + 2).toString().equalsIgnoreCase("1")) {
				countJump1 = ++countJump1;
				i = i + 2;

			}

			else {
				if (itemsArray[i].toString().equalsIgnoreCase("0")) {
					countJump1 = ++countJump1;
					i = ++i;
				}

			}
		}

	}
}
