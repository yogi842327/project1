package A0Check;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class LL2CountingValleys {
	public static void main(String args[]) {
		
		 String s2="DDUUDDUDUUUD";   //2 answer 
		    String[] arr = new String[s2.length()];
		    for(int i = 0; i < s2.length(); i++)
		    {
		        arr[i] = String.valueOf(s2.charAt(i));
		    }
		    
			int valeys4=0;
			int valeysHeight4=0;
			
			for(int i=0;i<arr.length;i++){    
				if(arr[i].equalsIgnoreCase("U")) {
					valeys4=++valeys4;
					//if(valeys4>=1) {
					if(valeys4==0) {
						++valeysHeight4;
					}
					}
					
				else {
					valeys4=--valeys4;
				}
				
				}
				
			System.out.println("valleyes 1st ....  "+ valeysHeight4);
			
			//2nd
			int steps=5;
			 String path="UDDDUDUU";
			  
			int level = 0; // 0 is sea-level
			    int valleys = 0;

			    for (char c : path.toCharArray())
			    {
			        if (c == 'U') {
			            level++;
			            if (level == 0)
			            {
			                valleys++;
			            }
			        }
			        else {
			            level--;
			        }
			    }
			    System.out.println("valleys charecter 2nd ....  "+ valleys);
	}

}
