package A0Check;

public class L1CountValleys {
	
	public static void main(String args[]) {
		//String path="DUDDDUUDUU";//10 >2  DDUUDDUDUUUD>12 2  UDDDUDUU 8>1 
	String s2="DDUUDDUDUUUD";   //2 answer 
    String[] arr = new String[s2.length()];
    for(int i = 0; i < s2.length(); i++)
    {
        arr[i] = String.valueOf(s2.charAt(i));
    }
    
	int valeys4=0;
	int valeysHeight4=0;
	
	for(int i=0;i<arr.length;i++){    
		if(arr[i].equalsIgnoreCase("U")) {
			valeys4=++valeys4;
			//if(valeys4>=1) {
			if(valeys4==0) {
				++valeysHeight4;
			}
			}
			
		else {
			valeys4=--valeys4;
		}
		
		}
		
	System.out.println("main ....  "+ valeysHeight4);
	}

}
