package B1Inter2020tricky;

//https://www.geeksforgeeks.org/create-immutable-class-java/
public class K1ImmutableEx {
	// Driver class 
	 
	    public static void main(String args[]) 
	    { 
	    	Studentyr s = new Studentyr("ABC", 101); 
	        System.out.println(s.getName()); 
	        System.out.println(s.getRegNo()); 
	  
	        // Uncommenting below line causes error 
	        // s.regNo = 102; 
	    } 
	} 
//An immutable class 
 final class Studentyr
{ 
 final String name; 
 final int regNo; 

 public Studentyr(String name, int regNo) 
 { 
     this.name = name; 
     this.regNo = regNo; 
 } 
 public String getName() 
 { 
     return name; 
 } 
 public int getRegNo() 
 { 
     return regNo; 
 } 
}
