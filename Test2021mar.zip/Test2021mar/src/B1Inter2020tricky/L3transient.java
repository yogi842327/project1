package B1Inter2020tricky;

import java.util.Date;
//https://www.geeksforgeeks.org/transient-keyword-java/

public class L3transient {
	// A sample class that uses transient keyword to 
	// skip their serialization. 
	  /*// Making password transient for security 
	transient and static : Since static fields are not part of state of the object, there is no use/impact of using transient keyword with static variables
	    private transient String password; */
	  
	    // Making age transient as age is auto- 
	    // computable from DOB and current date. 
	    transient int age; 
	  
	    // serialize other fields 
	    private String username, email; 
	    Date dob; 
	  
	    // other code 
	} 

