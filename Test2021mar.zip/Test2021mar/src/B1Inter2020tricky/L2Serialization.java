package B1Inter2020tricky;
//https://www.mkyong.com/java-best-practices/understand-the-serialversionuid/
//https://stackoverflow.com/questions/285793/what-is-a-serialversionuid-and-why-should-i-use-it

public class L2Serialization {

}

/*The serialVersionUID is used as a version control in a Serializable class. If you do not explicitly declare a serialVersionUID, JVM will do it for you automatically, based on various aspects of your Serializable class, as described in the Java(TM) Object Serialization Specification.
During the deserialization to verify that sender and receiver are compatible with respect to serialization. If the receiver loaded the class with a different serialVersionID then deserialization will end with InvalidClassCastException.
A serializable class can declare its own serialVersionUID explicitly by declaring a field named serialVersionUID that must be static, final, and of type long.
*/