package B1Inter2020tricky;
//https://www.geeksforgeeks.org/exception-propagation-java/

// https://www.geeksforgeeks.org/exception-propagation-java/
	
	
public class E6ExceptionPropogation {

	// Java program to illustrate 
	// unchecked exception propagation 
	// without using throws keyword 

	    void m() 
	    { 
	        int data = 50 / 0; // unchecked exception occurred 
	        // exception propagated to n() 
	    } 
	  
	    void n() 
	    { 
	        m(); 
	        // exception propagated to p() 
	    } 
	  
	    void p() 
	    { 
	        try { 
	            n(); // exception handled 
	        } 
	        catch (Exception e) { 
	            System.out.println("Exception handled"); 
	        } 
	    } 
	  
	    public static void main(String args[]) 
	    { 
	    	E6ExceptionPropogation obj = new E6ExceptionPropogation(); 
	        obj.p(); 
	        System.out.println("Normal flow..."); 
	    } 
	} 