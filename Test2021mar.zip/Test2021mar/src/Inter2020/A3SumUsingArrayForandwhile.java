package Inter2020;


import java.util.Scanner;

public class A3SumUsingArrayForandwhile {

	public static void main(String args[]) {

		int sum = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter how many number you want to Sum");
		int number = sc.nextInt();

		int a[] = new int[number];

		System.out.println("Enter the number " + number + " for Sum");

		for (int i = 0; i < number; i++) {

			System.out.println("Enter the number " + (i + 1) + " for Sum");

			a[i] = sc.nextInt();

		}
		for (int i = 0; i < number; i++) {

			sum += a[i];
		}
		System.out.println(" For Total number sum is " + sum);
		 System.out.println("While Loop");
		int j=0;sum=0;
		 System.out.println("Enter how many numbers you want sum");
         int num=sc.nextInt();
         int arr[]=new int[num]; 
System.out.println("Enter the "+num+" numbers ");
  while(j<num) {       
  System.out.println("Enter  number  "+(j+1)+":");
  arr[j]=sc.nextInt();
             sum+=arr[j];
             j++;
 
           }

System.out.println("While Sum is " +sum);
	}
	
	
}
