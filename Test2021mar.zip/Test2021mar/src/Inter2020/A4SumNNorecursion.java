package Inter2020;


import java.util.Scanner;

public class A4SumNNorecursion {

	public static void main(String args[]) {
		System.out.println("Please enter the value");
		Scanner s = new Scanner(System.in);
		int num = s.nextInt();
		int sum = 0;
		// Without Recursion
		for (int i = 0; i <= num; i++) {
			sum = sum + i;
		}
		System.out.println("Sum is " + sum);
		System.out.println("Recursive Sum is  " + A4SumNNorecursion.recurssum(num));
		System.out.println("Recursive same easy Sum is  " + A4SumNNorecursion.recurssumsame(num));
		// System.out.println("Recursive same easy Odd Sum is " +
		// SumNNo2of2.printOdds(num));
//		System.out.println("Recursive same easy Even Sum is  " + SumNNo2of2.recurssumeven(num));

	}

	// Recursion
	public static int recurssum(int n) {

		if (n <= 0) {
			System.out.println("final call");
			return n;
		}
		// System.out.println("first call");
		return n + recurssum(n - 1);

	}

	// Recursion viceversa
	public static int recurssumsame(int n) {

		if (n != 0) {
			return n + recurssumsame(n - 1);
		}
		return n;

	}

}

/*
 * Output Please enter the value 5 Sum is 15 Recursive Sum is 15
 */