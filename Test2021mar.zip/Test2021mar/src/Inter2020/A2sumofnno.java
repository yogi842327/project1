package Inter2020;


				import java.util.Scanner;
				//	1 and 2nd sum of n number without recursion 
				 public class A2sumofnno
		    {
							
				public static void main(String args[])
				{
				
					int j=0;
					int sum=0;
				Scanner sc=new Scanner(System.in);
				
				System.out.println("Please enter the n no for Sum :");
				int num= sc.nextInt();
								
				// withot recursion 1st way
				for(int i=0;i<=num;i++)
				{
				//	System.out.println("Prints n no :"+i);
				sum=sum+i;
				}
				
				System.out.println("1st N value sum is  :"+sum);
				// withot recursion 2nd way 
				int nvalue=print_nsum(num,sum); // through call non static methods 
				System.out.println("2 N value sum is 2nd way :"+nvalue);
				sum=0;
				 while( j<=num)
				 {
					 sum=sum+j;
					 j++;
				 }
				 System.out.println("3rd while N value sum is  :"+sum);
				
				 }
				//2nd way without recursion
				static int print_nsum(int num,int sum)
				{
				//just check no use below code is fine double i j in for
				//2nd way
				sum=0;
				for(int i = 1 , j = 1 ; j <= i && i <= num ; i++, j++)  
				{
					
				sum=sum+j;
				}
				System.out.println(" 2nd N value for print_nsum sum is  :"+sum);	
				return sum;				
				}
				
			}	