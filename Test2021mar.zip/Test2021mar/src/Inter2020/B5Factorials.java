package Inter2020;

public class B5Factorials {
	public static void main (String[] args)
	{
		int num=5;
		int fact=1;
		
		//System.out.print(" "+n1+" "+n2);
		for(int i=1;i<=num;i++) {
			fact=fact*i;
			
		}
		System.out.print(" "+fact);
		
	}
}
