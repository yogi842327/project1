package Inter2020;

public class B2stars {
	public static void main(String args[]) {
		int p_height1 = 4;
		int p_space1 = p_height1;
		int star_print1 = 1;

		// 1
		for (int i = 0; i <= p_height1; i++) {
			for (int j = p_space1; j > i; j--) {
				System.out.print(" ");

			} // end of for
			for (int k = 0; k < star_print1; k++) {
				//System.out.print("*");
				// System.out.print((char)(k+65));
	      	System.out.print(k);

			} // end of for
			star_print1 += 2;
			System.out.println();

		}

		//2
		int star_print = 9;
		int p_space = star_print / 2;
		int p_height = star_print - p_space;

		for (int x = p_height; x >= 1; x--) { // 3,5,
			for (int y = p_space; y >= x; y--) { // 3>=3,
				// System.out.print(+j+" "+i);
				System.out.print(" ");
				// p_space+=2;

			} // end of for
			for (int z = 0; z < star_print; z++) {
			//	System.out.print("*");
				
				 System.out.print((char)(z+65));
				// System.out.print((char)(Math.abs(k - l)+65));

			} // end of for
			star_print -= 2;
			System.out.println();

		}
	
		
//4h
		System.out.println(" Another 4th   ");
		int size=3;
		for(int i=size;i>=-size;i--) {
			for(int j=1;j<=Math.abs(i);j++) {
				System.out.print(" ");
			//	System.out.print((char)(j+65));
				
				
			}
			for(int k=size;k>=Math.abs(i);k--) {
				System.out.print("*");
				   //System.out.print((char)(k+65));
		          
			       //   System.out.print((char)(Math.abs(k - l)+65));
			}
			System.out.println();
		}
		
	}
/*	//3rd mix of 1st 2nd
	
//	 Copy of the method parsing String input data into your integer array
	static int[] parseInformationFromTheFuture(String rawData){
		System.out.println(" Another 4th   ");
	String[] ss = rawData.split("\\,");
	int[] a = new int[ss.length];
	for(int i=0; i<ss.length; i++){
	a[i] = Integer.valueOf(ss[i]);
	}
	return a;
	}*/
}
