package Inter2020;

public class C2StringBufferBuilderExample {
/*	
String is immutable and threadsafe/synchronized ,StringBuffer is mutable and threadsafe/synchronized,  StringBuilder is mutable and not threadsafe/synchronized,
its not required mutable is threadsafe sb is examples*/
	public static void main(String args[]){  
		System.out.println("string Buffer Builder mutable ex1 ");
		
		String str=new String("Hello ");  
		str.concat("Java");//now original string is not changed  
		System.out.println("string ex "+str);//prints Hello  
		str=str.concat("Java");//now original string is changed 
		System.out.println("string ex "+str);//prints Hello Java
		
		StringBuffer sb=new StringBuffer("Hello ");  
		sb.append("Java");//now original string is changed  
		System.out.println(" buffer ex  "+sb);//prints Hello Java  
		
		StringBuilder builder=new StringBuilder("Hello");  
        builder.append("Java");  
        System.out.println("builder eex  "+builder);
        
    //    System.out.println("string Buffer Builder theread saf ");

}

}