package Inter2020;

import java.util.Scanner;

public class A6EvenOdd {

	public static void main(String args[]) {
		int n = 100;

		System.out.print("1 Odd Numbers from 1 to " + n + " are: ");
		for (int i = 1; i <= n; i++) {
			if (i % 2 != 0) {
				System.out.print(i + " ");
			}
		}
		System.out.println("  ");
		// 2nd
		int c;
		System.out.println("2 Input an integer Enter the integer value ");
		Scanner in = new Scanner(System.in);
		c = in.nextInt();

		if ((c / 2) * 2 == c)
			System.out.println("Even");
		else
			System.out.println("Odd");

		// 3rd Array
		int a[] = { 1, 2, 5, 6, 3, 2 };
		 System.out.println("3 Odd Numbers:");
		for (int j = 0; j < a.length; j++) {
			if (a[j] % 2 != 0) {
				System.out.println(a[j]);
			}
		}

	}
}
