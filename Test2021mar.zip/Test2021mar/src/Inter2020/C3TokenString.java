package Inter2020;
//StringTokenizer class is deprecated now. It is recommended to use split() method of String class or regex (Regular Expression).

import java.util.StringTokenizer;

public class C3TokenString {

public static void main(String args[]){  
	   StringTokenizer st = new StringTokenizer("my name is khan"," "); 
	  
	     while (st.hasMoreTokens()) {  
	         System.out.println(st.nextToken());  
	     }  
	     StringTokenizer st1 = new StringTokenizer("my,name,is,khan");
		   System.out.println("Next token is : " + st1.nextToken(","));  
	     
	   }  
	}  