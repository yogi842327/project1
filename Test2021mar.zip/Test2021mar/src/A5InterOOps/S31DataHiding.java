package A5InterOOps;

//https://www.guru99.com/java-oops-encapsulation.html
//https://stackoverflow.com/questions/12013448/encapsulation-vs-data-hiding-java
//https://stackoverflow.com/questions/12072980/encapsulation-vs-abstraction-real-world-example/34013389

public class S31DataHiding {
	/* File name : RunEncap.java */

	   public static void main(String args[]) {
	      EncapTest encap = new EncapTest();
	      encap.setName("James");
	      encap.setAge(20);
	      encap.setIdNum("12343ms");

	      System.out.print("Name : " + encap.getName() + " Age : " + encap.getAge());
	   }
	}

/* File name : EncapTest.java */
 class EncapTest {
   private String name;
   private String idNum;
   private int age;

   public int getAge() {
      return age;
   }

   public String getName() {
      return name;
   }

   public String getIdNum() {
      return idNum;
   }

   public void setAge( int newAge) {
      age = newAge;
   }

   public void setName(String newName) {
      name = newName;
   }

   public void setIdNum( String newId) {
      idNum = newId;
   }
}
 
/*
 Encapsulation means binding data members and method(behaviour) 
 in a single unit and providing as much information as much user 
 required easily you can say [encapsulation=data hiding+abstraction].

 Class is fully encapsulated element in java

 Data hiding means declaring data variables as private to secure it from unauthorized access but if you are giving some public setter and getter method for validation.*/
 /*
 Abstraction says that what needed to interact with object.

 Encapsulation means encapsulate object properties , state and behaviours into single logical unit called class.

 Data hiding says that hiding inner implementation of objects means private methods and properties, the object that use to maintain their state.*/