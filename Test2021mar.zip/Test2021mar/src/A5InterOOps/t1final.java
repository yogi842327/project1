package A5InterOOps;

//https://www.geeksforgeeks.org/final-keyword-java/
//https://techdifferences.com/difference-between-static-and-final-in-java.html

class Aj
{
    final void m1() 
    {
        System.out.println("This is a final method.");
    }
}

public class t1final extends Aj 
{
    void m1()
    { 
        // COMPILE-ERROR! Can't override.
        System.out.println("Illegal!");
    }
}