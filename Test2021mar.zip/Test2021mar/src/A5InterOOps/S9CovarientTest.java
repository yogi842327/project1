package A5InterOOps;

//Covariant return type refers to return type of an overriding method.
//https://www.tutorialspoint.com/Covariant-return-types-in-Java
//https://www.javatpoint.com/covariant-return-type
class SuperClassg {
	SuperClassg get() {
	      System.out.println("SuperClass");
	      return this;
	   }
	}
	public class S9CovarientTest extends SuperClassg {
		S9CovarientTest get() {
	      System.out.println("SubClass");
	      return this;
	   }
	   public static void main(String[] args) {
		   SuperClassg tester = new S9CovarientTest();
	      tester.get();
	   }
	}