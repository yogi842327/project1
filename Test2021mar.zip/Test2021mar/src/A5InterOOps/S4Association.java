package A5InterOOps;


//https://data-flair.training/blogs/association-in-java/

class Teacher
{
  private String name;
  Teacher(String name)
  {
    this.name = name;
  }
  public String getTeacherName()
  {
    return this.name;
  }
}
class Student
{
  private String name;
  Student(String name)
  {
    this.name = name;
  }
  public String getStudentName()
  {
    return this.name;
  }
}
class AssociationDemo
{
public static class S4Association {
	
	public static void main (String[] args)
	  {
	    Teacher teacherObj = new Teacher("Rahul Sir");
	    Student studentObj = new Student("Renuka");
	    System.out.println(studentObj.getStudentName() +
	        " is Student of " + teacherObj.getTeacherName());
	  }
	}
}

/*
#inheritence is-a
#aggregation # associationt	 
Association: Has-A relationship :Coposition Strong Association/ vs Aggregation /Weak Assoctation
Reuse thecode without extend keyword
Coposition: Conainer Object Destroye automatically destroy contained object
University have several department whenever you close university all department closed
Aggregation: container object destroyed there ae are no garuntee of destroyed contaned object
close department proffessor shifted to another departments
*/


