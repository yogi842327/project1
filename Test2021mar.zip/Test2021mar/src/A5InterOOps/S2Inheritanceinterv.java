package A5InterOOps;

///Inheritance Is-As in Java is a mechanism in which one object 
//acquires all the properties and behaviors of a parent object
//https://www.javatpoint.com/inheritance-in-java
class Ar{  
void msg(){System.out.println("Hello");}  
}  
class Br {//suppose if it were  {  
void msg(){System.out.println("Welcome");}  
}  

//public class S2Inheritanceinterv extends Ar,Br {
public class S2Inheritanceinterv{
	public static void main(String args[]){  
		S2Inheritanceinterv obj=new S2Inheritanceinterv();  
		//   obj.msg();//Now which msg() method would be invoked?  
		}
}
