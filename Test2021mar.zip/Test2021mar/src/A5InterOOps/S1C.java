package A5InterOOps;

class D {
	void m1(){
		System.out.println("Method m1 D");
		
	}
	void m2(){
		System.out.println("Method m2 D");
	}
	

}
class B extends D {
	void m1(){
		System.out.println("Method m1 Be B");
	}
	void m3(){
		System.out.println("Method m3 Be B");
	}
	
}

 class S1C {
	public static void main(String args[]) {
//	B b= new D();
	D b= new B();
	b.m1();
	b.m2();
	//	b.m3();
	
	}
}