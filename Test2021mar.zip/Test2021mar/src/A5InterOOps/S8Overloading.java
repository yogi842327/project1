package A5InterOOps;

//https://www.javatpoint.com/method-overloading-in-java
//https://www.geeksforgeeks.org/overloading-in-java/
//Polymorphism means more than one form, same object performing different operations according to the requirement.

public class S8Overloading {



void sum(int a,long b){System.out.println("a method invoked");}  
void sum(long a,int b){System.out.println("b method invoked");}  

public static void main(String args[]){  
	S8Overloading obj=new S8Overloading();  
// obj.sum(20,20);//now ambiguity  
}  
} 


/*
If a class has multiple methods having same name but different in parameters, it is known as Method Overloading.
y changing number of arguments,data type
1. Number of parameters.
2. Data type of parameters.
3. Sequence of Data type of parameters
Yes, by method overloading. You can have any number of main methods in a class by method overloading
No, you cannot override a static method 
*/

