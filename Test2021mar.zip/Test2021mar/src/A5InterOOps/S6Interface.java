package A5InterOOps;
//Java interface is a blueprint of a class and it is used to achieve fully abstraction and it is a collection of abstract methods.
//https://javaconceptoftheday.com/java-interview-questions-on-interfaces/
//	https://www.geeksforgeeks.org/interfaces-in-java/
//https://www.guru99.com/interface-vs-abstract-class-java.html


//Java program to demonstrate working of  
//interface. 
import java.io.*; 

//A simple interface 
interface In1 
{ 
 // public, static and final 
 final int a = 10; 

 // public and abstract  
 void display(); 
} 

//A class that implements the interface. 
public class S6Interface implements In1 
{ 
 // Implementing the capabilities of 
 // interface. 
 public void display() 
 { 
     System.out.println("Geek"); 
 } 

 // Driver Code 
 public static void main (String[] args) 
 { 
	 S6Interface t = new S6Interface(); 
     t.display(); 
     System.out.println(a); 
 } 
} 

//No. The fields of interfaces are static and final by default
//No. constructor,no object.no interface final should use public only,No static only abstract methods default
/*//interface JavaInterface{

int x, y; // compile time error: The blank final field y may not have been initialized
}*/
