package A5InterOOps;

//https://www.geeksforgeeks.org/generalization-and-specialization-in-java/
//https://www.tutorialspoint.com/object_oriented_analysis_design/ooad_object_oriented_model.htm


class Father { 
    public void work() 
    { 
        System.out.println("Earning Father"); 
    } 
} 
  
class Son extends Father { 
    public void play() 
    { 
        System.out.println("Enjoying son"); 
    } 
} 
  
public class S2Generalization {

    public static void main(String[] args) 
    { 
        // son is a subclass reference 
        Father father; 
  
        // new operator returns a subclass reference 
        // which is stored in the father variable 
        // father stores a Father class reference 
        // because of implicit casting 
        father = new Son(); 
  
        // father is narrowed 
        Son son = (Son)father; 
  
        son.work(); // works well 
        son.play(); // works well 
    } 
} 
/*
//Inheritance generalization ,specialization: Is_A Generalization : In a Inheritance hierarchy Casting SubClass type into SuperClass type is
 *  called Generalization, and also known as UP Casting or Widening.

Specialization : In a Inheritance hierarchy Casting SuperClass type into SubClass type is called Specialization , 
and also known as Down Casting or Narrowing.
Earning Father
So, in widening or Generalization, we can access all the superclass methods, but not the subclass method

narrowing/downcasting specialization: 
 Earning Father
Enjoying son
*
*/
