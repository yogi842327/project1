package A5InterOOps;

//https://javabypatel.blogspot.com/2017/07/real-time-example-of-abstract-class-and-interface-in-java.html
interface FlightOpeartions{
	 void getAllAvailableFlights();
	 void booking(BookingObject bookingObj);
	}
//	BookingObject.java
	class BookingObject{}
	//BritishAirways.java (Vendor 1)
	class BritishAirways implements FlightOpeartions{

	 public void getAllAvailableFlights(){
	           //get british airways flights in the way 
	           //they told us to fetch flight details.
	 }

	 public void booking(BookingObject flightDetails){  
	          //place booking order in a way British airways 
	          //told us to place order for seat.
	 }

	}
//	Emirates.java (Vendor 2)
	public class S7InterfaceReal implements FlightOpeartions{

	 public void getAllAvailableFlights(){
	         //get Emirates flights in the way 
	         //they told us to fetch flight details.
	 }

	 public void booking(BookingObject flightDetails){  
	         //place booking order in a way Emirates airways
	         //told us to place order for seat.
	 }
	}
	
	/*
	Interface: To conclude: We know contract.
	So we can say that we know the contract that irrespective of who the Flight vendor is, we need "getAllAvailableFlights()" and "booking()" method from them to run our aggregator service.
	
	Abstract Class: Methods we know is "sendSMS()", "checkForDND()", "checkForTelecomRules()".
	Methods we don't know is "eastablishConnectionWithYourTower()", "destroyConnectionWithYourTower()".
*/	
	
	
