package A5InterOOps;

//runtime polymorphism:If subclass (child class) has the same method as declared in the parent class, it is known as method overriding in Java.
//used to provide the specific implementation of a method which is already provided by its superclass.
//https://www.geeksforgeeks.org/overloading-in-java/
//https://www.javatpoint.com/exception-handling-with-method-overriding
//https://www.javatpoint.com/method-overloading-vs-method-overriding-in-java

import java.io.*;  
class Parentr{  
  void msg()throws Exception{System.out.println("parent");}  
}  
  
class S8Overriding extends Parentr{  
  void msg()throws Exception{System.out.println("child");}  
  
  public static void main(String args[]){  
   Parentr p=new S8Overriding();  
   try{  
   p.msg();  
   }catch(Exception e){}  
  }  
}  

/*Overriding and constructor : We can not override constructor as parent and child class can never have constructor with same name(Constructor name must always be same as Class name).
No, you cannot override a static method 
*/
