package A5InterOOps;

//https://www.geeksforgeeks.org/abstract-classes-in-java/
//http://www.codespaghetti.com/abstract-interview-questions/
//An abstract class with constructor 
//Abstraction is a process of hiding the implementation details and showing only functionality to the user.
abstract class Base {
	Base() {
		System.out.println("Base Constructor Called");
	}

	abstract void fun();
}

class Derived extends Base {
	Derived() {
		System.out.println("Derived Constructor Called");
	}

	void fun() {
		System.out.println("Derived fun() called");
	}
}

class S5AbstractConstructor {
	public static void main(String args[]) {
		Derived d = new Derived();
	}
}
/*
//
Abstraction is a process of hiding the implementation details and showing only functionality to the user: Abstract class (0 to 100%)
constructor yes,Implements interface Yes,Abstract class not be final,can not create instance of Abstract class,Abstract class can create final ,static main methods
or non abstract/concrete  methods... No private abstrcat class: inheritance
abstract methods can not be static,synchronized
https://javaconceptoftheday.com/java-interview-questions-on-abstract-class/
Yes, you can overload abstract methods
*/

