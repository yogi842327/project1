package A2Inter2020DS2;

import java.lang.reflect.Array;
import java.util.Arrays;

public class N1Arrayprograms1sortmax {
	public static void main(String[] args) {
		/*
		 * String[] array= { "g", "j", "y" }; String temp=null;
		 */
		
		int[] array = { 3, 16, 3, 11, 9, 2 };
		int temp = 0;
		
	
	//	array=Arrays.copyOf(array, array.length * 2);
		System.out.println("size is "+array.length);
		// Arrays.sort(array);
		for (int i = 0; i < array.length - 1; i++) {
			for (int j = 0; j < array.length - 1; j++) {
				// if (array[j] < array[j + 1]) { // Descending order
				if (array[j] > array[j + 1]) {
					temp = array[j + 1];
					array[j + 1] = array[j];
					array[j] = temp;
					// System.out.println(array);
				}

			}
		}

		for (int i = 0; i < array.length; i++) {
			System.out.println("array is g " + array[i]);

		}
		System.out.print(" Max value finding ");
		int[] array1 = { 7, 89, 33, 66, 19, 21 };
		// p2 find max value of array through sort
		// int maxval = Arrays.stream(array1).max().getAsInt();
		int max = array1[0];
		for (int i = 0; i < array1.length - 1; i++) {
			if (max < array1[i]) { // find les value: max > array1[i]
				max = array1[i];

			}

		}
		System.out.println(" " +max);
	//	System.out.print(" Copy of originalarr to arrayf ");
		// copy array in java
		int[] originalarr = { 8, 9, 3, 6, 9, 2 };
		int len = originalarr.length;
		int arr2[] = new int[originalarr.length];
		int copiedarray[] = new int[len];
		for (int k = 0; k < len; k++) {
			copiedarray[k]=originalarr[k];
		//	System.out.println("copiedarray "+copiedarray[k]);

		}
		String[] names = { "Java", "JavaScript", "Python", "C", "Ruby", "Java" };
		//array even or add position print'
		  //Here, i will start from 1 as first even positioned element is present at position 1.  
        for (int l = 1; l < arr2.length; l = l+2) {  
        //    System.out.println(arr2[l]);  
        }  
// find second largest number in array just sort and print index sorted array is array
        System.out.println(" fourthh sorted array then find fourth largest array "+array[3]);
        

	}

	// find duplicate in string same string logic
	String[] names = { "Java", "JavaScript", "Python", "C", "Ruby", "Java" };
	
	
}
