package A2Inter2020DS2;

public class O4 {

	public static void main(String[] args) {
		Object key = "Tcs";
		int h = 0;
		h = key.hashCode() ^ (h >>> 16);
		System.out.println(h);
	}

}
