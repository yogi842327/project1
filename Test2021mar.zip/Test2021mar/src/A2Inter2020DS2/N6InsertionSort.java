package A2Inter2020DS2;

import java.util.Arrays;
import java.util.LinkedList;

public class N6InsertionSort {

	public static void main(String[] args) {

		int arr[] = { 23, 5, 76, 87, 3, 44, 67 };
		//getSortedArray(arr);
		// { 5, 23, 76, 87, 3, 44, 67 }
		// { 5, 23, 76, 3, 87, 44, 67 };{ 5, 23, 3, 76, 87, 44, 67 }; { 5, 3, 23, 76, 87, 44, 67 } ; {3, 5, 23, 76, 87, 44, 67 }
		LinkedList<String> ll = new LinkedList<>();
		ll.add("Vikas");
		ll.add("Jogi");
		
		ll.get(0);

	}

	public static void getSortedArray(int unrosrtedArr[]) {

		int length = unrosrtedArr.length;
		int temp;

		for (int i = 1; i < length; i++) {

			for (int j = i; j > 0; j--) {
				if (unrosrtedArr[j] < unrosrtedArr[j - 1]) {
					temp = unrosrtedArr[j];
					unrosrtedArr[j] = unrosrtedArr[j - 1];
					unrosrtedArr[j - 1] = temp;
				}
			}
		}

		for (int i = 0; i < unrosrtedArr.length; i++) {
			System.out.println(unrosrtedArr[i]);
		}
	}
}
