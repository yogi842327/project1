package A2Inter2020DS2;

public class O2Entry {

	private final Object key;
	private Object value;
	private O2Entry next;

	public O2Entry(Object key, Object value) {
		super();
		this.key = key;
		this.value = value;
	}

	public O2Entry getNext() {
		return next;
	}

	public void setNext(O2Entry next) {
		this.next = next;
	}

	public Object getValue() {
		return value;
	}

	public void setValue(Object value) {
		this.value = value;
	}

	public Object getKey() {
		return key;
	}

	@Override
	public String toString() {
		return "Entry [" + (key != null ? "key=" + key + ", " : "") + (value != null ? "value=" + value + ", " : "")
				+ (next != null ? "next=" + next : "") + "]";
	}

}
