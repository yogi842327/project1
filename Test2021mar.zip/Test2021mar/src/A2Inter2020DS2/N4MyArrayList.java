package A2Inter2020DS2;

public class N4MyArrayList {

	// TODO: Need to set default array size while create object
	// TODO: element needs to be add

	private Object elements[];
	private int size;

	N4MyArrayList() {
		elements = new Object[10];
	}

	public void add(Object element) {
		elements[size++] = element;
	}

	public static void main(String[] args) {
		N4MyArrayList arrayList = new N4MyArrayList();
		arrayList.add(10);
		arrayList.add(20);
		arrayList.add(30);
		arrayList.add(40);

		for (Object obj : arrayList.elements) {
			if (obj != null) {
				System.out.println(obj);
			}

		}
		arrayList.add(50);
		System.out.println("=========");
		for (Object obj : arrayList.elements) {
			if (obj != null) {
				System.out.println(obj);
			}

		}
	}
}
