package A2Inter2020DS2;

public class O3MyHashMap {

	public static int INITIAL_CAPACITY = 10;
	private O2Entry bucket[];

	O3MyHashMap() {
		bucket = new O2Entry[INITIAL_CAPACITY];
	}

	public void put(Object key, Object value) {
		int hash = bucketIndexForKey(key);
		int index = bucket.length - 1 & hash;
		O2Entry entry = bucket[index];
		if (entry != null) {
			boolean isCompleted = false;
			while (!isCompleted) {
				if (key.equals(entry.getKey())) {
					entry.setValue(value);
					isCompleted = true;
				} else if (entry.getNext() == null) {
					entry.setNext(new O2Entry(key, value));
					isCompleted = true;
				}
			}

		} else {
			bucket[index] = new O2Entry(key, value);
		}
	}

	private int bucketIndexForKey(Object key) {
		int h;
		return (key == null) ? 0 : (h = key.hashCode()) ^ (h >>> 16);
		/*
		 * int bucketIndex = key.hashCode() % bucket.length; return bucketIndex;
		 */
	}

	public void print() {
		for (O2Entry entry : bucket) {
			if (entry != null) {
				System.out.println("Key=" + entry.getKey() + "; Value=" + entry.getValue());
				if (entry.getNext() != null) {
					System.out.println("Key=" + entry.getNext().getKey() + "; Value=" + entry.getNext().getValue());
				}
			}
		}
	}

	public static void main(String[] args) {
		O3MyHashMap hashMap = new O3MyHashMap();
		hashMap.put("Jogi", "Jhansi");
		hashMap.put("Vikas", "Blr");
		hashMap.put("Imran", "Pune");
		hashMap.put("Jogi", "Blr");
		hashMap.put("Prachi", "Del");
		hashMap.print();
	}
}
