package A2Inter2020DS2;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class N9MyStack {

	private int INITIAL_CAPACITY = 10;
	private int top;
	private Object stackArray[];

	public N9MyStack() {
		stackArray = new Object[INITIAL_CAPACITY];
	}

	public void push(Object value) {
		stackArray[top++] = value;
	}

	public Object pop() {
		int index = --top;
		List<Object> list = new LinkedList<Object>(Arrays.asList(stackArray));
		Object obj = list.remove(index);
		stackArray = list.toArray();
		return obj;
	}

	public void print() {
		Arrays.stream(stackArray).forEach(value -> {
			if (value != null) {
				System.out.println(value);
			}
		});
	}

	public static void main(String[] args) {
		N9MyStack myStack = new N9MyStack();
		myStack.push("SBI");
		myStack.push("CITI");
		myStack.push("HDFC");
		myStack.print();

		Object pop = myStack.pop();
		System.out.println("Pop up value: " + pop.toString());
		System.out.println("After pop up");
		myStack.print();
	}
}
