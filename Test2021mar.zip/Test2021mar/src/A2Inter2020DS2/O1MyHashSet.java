package A2Inter2020DS2;

import java.util.HashMap;
import java.util.Map;

public class O1MyHashSet {

	Map<Object, String> map;

	public static final String PRESENT = "PRESENT";

	public O1MyHashSet() {
		map = new HashMap<Object, String>();
	}

	public void add(Object data) {
		map.put(data, PRESENT);
		System.out.println(data.hashCode());
	}

	public void display() {
		// System.out.println(map);
		map.forEach((k, v) -> System.out.println(k));
	}

	public String delete(Object key) {
		if (map.remove(key) == PRESENT) {
			return "Key removed successfully";
		} else {
			return "Key not found";
		}
	}

	public static void main(String[] args) {
		O1MyHashSet hashSet = new O1MyHashSet();
		hashSet.add(1);
		hashSet.add(2);
		hashSet.add(3);
		hashSet.display();
		System.out.println(hashSet.delete(2));
		hashSet.display();
	}

}
