
package A2Inter2020DS2;

import java.util.LinkedList;

public class N8MyLinkedList2 {
	Node last;
	Node first;
	int listSize;

	public void add(int element) {
		Node prevNode = last;
		Node newNode = new Node(prevNode, element, null);

		if (prevNode == null) {
			first = newNode;

		} else {
			prevNode = newNode;
		}
		last = newNode;
		listSize++;
	}

	private class Node {

		int element;
		Node prev;
		Node next;

		public Node(Node prev, int element, Node next) {
			this.element = element;
			this.prev = prev;
			this.next = next;
		}
	}

	public Node get(int element) {
		return null;
	}

	public int size() {
		return listSize;
	}

	public void addWithIndex(int index, int element) {
		if (index == listSize) {
			// TODO: addLast()

		}

	}

	public static void main(String[] args) {
		N8MyLinkedList2 linkedList = new N8MyLinkedList2();
		linkedList.add(10);
		linkedList.add(20);
		linkedList.add(30);
		linkedList.add(40);
		linkedList.add(50);
		linkedList.add(60);
		linkedList.add(70);
		linkedList.add(80);
		linkedList.add(90);
		linkedList.add(100);
		linkedList.addWithIndex(10, 55);
		int length = linkedList.size();

		// System.out.println("Size of linkedlist: "+length);
		// TODO: Create a sep method with index

		LinkedList<Integer> ll = new LinkedList<Integer>();
		ll.add(10);
		ll.add(20);
		ll.add(30);
		ll.add(40);
		ll.add(40);
		ll.add(2, 55);
		System.out.println(8>>1);
	}

}
