package A2Inter2020DS2;

public class N5MyArraylist1Create {

   //TODO: Need to set default array size while create object
	// TODO: element needs to be add

	private Object elements1[];
	private int size;

	N5MyArraylist1Create() {
		elements1 = new Object[10];
	}

	public void add(Object element) {
		 if(elements1.length-size <= 5){
		
	}
		 else {
			 elements1[size] = element;
			 size++;
		 }
	}
	public static void main(String[] args) {
		N5MyArraylist1Create arrayList = new N5MyArraylist1Create();
		arrayList.add(50);
		arrayList.add(20);
		arrayList.add(30);
		arrayList.add(40);

		for (Object obj : arrayList.elements1) {
			if (obj != null) {
				System.out.println(obj);
			}

		}
		arrayList.add(50);
		System.out.println("=========");
		for (Object obj : arrayList.elements1) {
			if (obj != null) {
				System.out.println(obj);
			}

		}
	}
}
