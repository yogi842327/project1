package A6constructorsuperboxing;

class A1
{
public void message()
{
System.out.println("message from A");
}
}
public class K5typecasting extends A1
	{

	public void message()
	{
	System.out.println("message from B");
	}

	public static void main(String... ar)
	{
		K5typecasting b = new K5typecasting();
	A1 a = b;   //reference of a subclass(B) type is widened to the reference of superclass(A) type.
	a.message();
	//2
	A1 a1 =  new K5typecasting();	//object of subclass(B) is referenced by reference of superclass(A)
	K5typecasting b1 = (K5typecasting)a1;	//reference of a superclass(B) type is downcasted/narrowed to the reference of subclass(A) type.
	b1.message();
	
	}
	}
