package A6constructorsuperboxing;

//Widening, also known as upcasting 
//Narrowing a wider/bigger 
public class k4typecasting {

	public static void main(String... ar) {
		byte b = 10;

		short s = b; // byte value is widened to short
		int i = b; // byte value is widened to int
		long l = b; // byte value is widened to long
		float f = b; // byte value is widened to float
		double d = b; // byte value is widened to double

		System.out.println("short value : " + s);
		System.out.println("int value : " + i);
		System.out.println("long value : " + l);
		System.out.println("float value : " + f);
		System.out.println("double value : " + d);

		double d1 = 10.5;

		byte b1 = (byte) d1; // Narrowing double to byte
		short s1 = (short) d1; // Narrowing double to short
		int i1 = (int) d1; // Narrowing double to int
		long l1 = (long) d1; // Narrowing double to long
		float f1 = (float) d1; // Narrowing double to float

		System.out.println("Original double value : " + d1);
		System.out.println("Narrowing double value to short : " + s1);
		System.out.println("Narrowing double value to int : " + i1);
		System.out.println("Narrowing double value to long : " + l1);
		System.out.println("Narrowing double value to float : " + f1);
		System.out.println("Narrowing double value to byte : " + b1);
	}
}