package A6constructorsuperboxing;

// Java program to illustrate super() by default 
	// executed by compiler if not provided explicitly 
	  
	class Parentr { 
		Parentr() 
	    { 
	        System.out.println("Parent class's No " + 
	                          "argument constructor"); 
	    } 
		Parentr(int a) 
	    { 
	        System.out.println("Parent class's 1 argument" +  
	                                      " constructor"); 
	    } 
	  
	} 
	  
	class j7thissuper extends Parentr { 
		j7thissuper() 
	    { 
	        // By default compiler put super()  
	        // here and not super(int) 
	        System.out.println("Base class's No " +  
	                        "argument constructor"); 
	    } 
	    public static void main(String[] args) 
	    { 
	        new j7thissuper(); 
	        System.out.println("Inside Main"); 
	    } 
	} 
