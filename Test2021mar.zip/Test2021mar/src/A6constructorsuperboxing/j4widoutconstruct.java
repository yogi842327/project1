package A6constructorsuperboxing;

// copy value without constructor
public class j4widoutconstruct{  
	    int id;  
	    String name;  
	    j4widoutconstruct(int i,String n){  
	    id = i;  
	    name = n;  
	    }  
	    j4widoutconstruct(){}  
	    void display(){System.out.println(id+" "+name);}  
	   
	    public static void main(String args[]){  
	    	j4widoutconstruct s1 = new j4widoutconstruct(111,"Karan");  
	    	j4widoutconstruct s2 = new j4widoutconstruct();  
	    s2.id=s1.id;  
	    s2.name=s1.name;  
	    s1.display();  
	    s2.display();  
	   }  
	}  
