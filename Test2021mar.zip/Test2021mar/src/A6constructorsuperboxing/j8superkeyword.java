package A6constructorsuperboxing;

public class j8superkeyword {

}
