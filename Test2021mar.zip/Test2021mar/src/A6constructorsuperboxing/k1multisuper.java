package A6constructorsuperboxing;

// Java Program to illustrate using super 
	// many number of times 
	  
	class Parent { 
	    // instance variable 
	    int a = 36; 
	  
	    // static variable 
	    static float x = 12.2f; 
	} 
	  
	public class k1multisuper extends Parent { 
	    void GFG() 
	    { 
	        // referring super class(i.e, class Parent)  
	        // instance variable(i.e, a) 
	        super.a = 1; 
	        System.out.println(a); 
	        
	        x = this.x; 
		  	  
	        System.out.println(x);
	       
	        x = super.x; 
		  	  
	        System.out.println(x);
	  
	        // referring super class(i.e, class Parent)  
	        // static variable(i.e, x) 
	        super.x = 60.3f; 
	  
	        System.out.println(x); 
	      
	        
	    } 
	    public static void main(String[] args) 
	    { 
	        new k1multisuper().GFG(); 
	    } 
	} 