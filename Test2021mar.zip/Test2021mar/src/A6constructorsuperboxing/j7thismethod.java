package A6constructorsuperboxing;

public class j7thismethod {

	// Java code to illustrate usage of this() 
	  
	 
	j7thismethod() 
	    { 
	        this(10); //calling parametrized
	        System.out.println("Flow comes back from " +  
	                           "j7thismethod class's 1 arg const"); 
	    } 
	  
	j7thismethod(int a) 
	    { 
	        System.out.println("j7thismethod class's 1 arg const"); 
	    } 
	    public static void main(String[] args) 
	    { 
	        new j7thismethod(); 
	        System.out.println("Inside Main"); 
	    } 
	} 
