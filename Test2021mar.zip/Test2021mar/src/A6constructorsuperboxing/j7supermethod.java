package A6constructorsuperboxing;


	// super() is use to call Base class�s(Parent class�s) constructor.
	
	// Java code to illustrate usage of super() 
	  
	 class superm { 
		 superm() 
	    { 
	        System.out.println("Parent class's No " +  
	                              " arg constructor"); 
	    } 
	} 
	  
	public class j7supermethod  extends superm { 
		j7supermethod() 
	    { 
	        super(); 
	        System.out.println("Flow comes back from " +  
	                        "Parent class no arg const"); 
	    } 
		
		 // Uncommenting below line causes compilation 
        // error because super() should be first statement 
        // System.out.println("Compile Time Error"); 
		j7supermethod(int i) 
		    {
		super(); 
  
        System.out.println("super INT Flow comes back from " +  
                       "Parent class no arg const"); 
    } 
	    public static void main(String[] args) 
	    { 
	        new j7supermethod(); 
	        System.out.println("Inside Main"); 
	        
	      /*  new k4supermethod(3);  //TRY WITH UNCOMMENT
	        System.out.println("Inside main INT"); */ 
	    } 
	} 