package A6constructorsuperboxing;


//https://www.geeksforgeeks.org/constructors-in-java/
// https://www.javatpoint.com/java-constructor
//https://www.geeksforgeeks.org/constructor-chaining-java-examples/
	class Noarg 
	{ 
	    int num; 
	    String name; 
	  
	    // this would be invoked while an object 
	    // of that class is created. 
	    Noarg() 
	    { 
	        System.out.println("Constructor called"); 
	    } 
	} 
	  
	public class J1Constructornoarg { 
	    public static void main (String[] args) 
	    { 
	        // this would invoke default constructor. 
	    	Noarg geek1 = new Noarg(); 
	  
	        // Default constructor provides the default 
	        // values to the object like 0, null 
	        System.out.println(geek1.name); 
	        System.out.println(geek1.num); 
	    } 
	} 