package A6constructorsuperboxing;

import java.util.ArrayList;
import java.util.List;
//Unboxing: Converting an object of a wrapper type to its corresponding primitive value is called unboxing. For example conversion of Integer to int.
//https://www.geeksforgeeks.org/autoboxing-unboxing-java/

public class k7autoboxing {

	public static void main(String[] args) {
		// creating an Integer Object
		// with value 10.
		Integer iger = new Integer(10);

		// unboxing the Object
		int i1 = iger;

		System.out.println("Value of i: " + iger);
		System.out.println("Value of i1: " + i1);

		// Autoboxing of char
		Character gfg = 'a';

		// Auto-unboxing of Character
		char ch = gfg;
		System.out.println("Value of ch: " + ch);
		System.out.println("Value of gfg: " + gfg);

		// 2nd
		/*
		 * Here we are creating a list of elements of Integer type and adding the int
		 * primitives type values to the list
		 */
		List<Integer> list = new ArrayList<Integer>();
		for (int i = 0; i < 10; i++)
			list.add(i);

		// getting sum of all odd no. in the list.
		int sumOdd = sumOfOddNumber(list);
		System.out.println("Sum of odd numbers = " + sumOdd);
	}
	public static int sumOfOddNumber(List<Integer> list) 
    { 
        int sum = 0; 
        for (Integer i : list) 
        { 
            // unboxing of i automatically 
            if(i % 2 != 0) 
                sum += i; 
            /* unboxing of i is done automatically 
               using intvalue implicitly 
            if(i.intValue() % 2 != 0) 
                sum += i.intValue();*/
        } 
        return sum; 
    } 
	
}
