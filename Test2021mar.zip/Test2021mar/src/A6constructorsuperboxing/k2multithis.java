package A6constructorsuperboxing;

	// Java Program to illustrate using this 
	// many number of times 
	  
	public class k2multithis { 
	    // instance variable 
	    int a = 10; 
	  
	    // static variable 
	    static int b = 20; 
	  
	    void GFG() 
	    { 
	        // referring current class(i.e, class RR)  
	        // instance variable(i.e, a) 
	        this.a = 100; 
	  
	        System.out.println(a); 
	  
	        // referring current class(i.e, class RR)  
	        // static variable(i.e, b) 
	        this.b = 600; 
	  
	        System.out.println(b); 
	  
	        // referring current class(i.e, class RR)  
	        // instance variable(i.e, a) again 
	        this.a = 9000; 
	  
	        System.out.println(a); 
	    } 
	  
	    public static void main(String[] args) 
	    { 
	        new k2multithis().GFG(); 
	    } 
	}
