package A6constructorsuperboxing;
//http://how2examples.com/java/wrapper-classes


public class k6wrapperboxing {
	public static void main(String... ar)
	{
		//Converting a String to a wrapper.
	
		Boolean bool = Boolean.valueOf(true);
		Byte b = Byte.valueOf((byte) 127);
		Character c = Character.valueOf('a');
		Short s = Short.valueOf((short) -32768);
		Integer i = Integer.valueOf(2147483647);
		Long l = Long.valueOf(-9223372036854775808L);
		Float f = Float.valueOf(3.4028235E38F);
		Double d = Double.valueOf(1.33334533);
		System.out.println(bool+" "+b+" "+c+" "+s+" "+i+" "+l+" "+f+" "+d);
	
		Double w = 669.32;
		byte b1 = w.byteValue();
		short s1 = w.shortValue();
		
		float f1 = w.floatValue();
		double d1 = w.doubleValue();
		System.out.println(" WrapperToPrimitive.2nd  "+b1+" "+s1+" "+f1+" "+d1);
		
		boolean bool12 = Boolean.parseBoolean("true");
		byte b34 = Byte.parseByte("127");
		System.out.println("3rd String to a primitive. "+bool12+" "+b34);
		
		byte binary4 = Byte.parseByte("1101", 2);
		short octal4 = Short.parseShort("15", 8);
		int decimal4 = Integer.parseInt("13", 10);
		long hexadecimal4 = Long.parseLong("d", 16);
		System.out.println(" 5 String to a primitive "+binary4+" "+octal4+" "+decimal4+" "+hexadecimal4);
		
		
		String s12 = Integer.toString(998);
		System.out.println(" 6 primitive to a Strin "+s12);
		int i55 = 13;
		String binary = Integer.toString(i55, 2);
		System.out.println("7 primitive to a String. "+binary);
		
		String s322 = new Integer(-8735).toString();
		System.out.println("8 WrapperToString "+s322);
		
		try {
			   Byte.parseByte("128");
			} catch (NumberFormatException e) {
			   System.out.println("4th NumberFormatException "+e);
			}
	}

	

}
