package A6constructorsuperboxing;

public class K8Varargs {
	 // Takes string as a argument followed by varargs 
    static void fun2(String str, int ...a) 
    { 
        System.out.println("String: " + str); 
        System.out.println("Number of arguments is: "+ a.length); 
  
        // using for each loop to display contents of a 
        for (int i: a) 
            System.out.print(i + " "); 
  
        System.out.println(); 
    } 
  
    public static void main(String args[]) 
    { 
        // Calling fun2() with different parameter 
        fun2("GeeksforGeeks", 100, 200); 
        fun2("CSPortal", 1, 2, 3, 4, 5); 
        fun2("forGeeks"); 
    } 
}

//Varargs is a short name for variable arguments. In Java, an argument 
//of a method can accept arbitrary number of values. This argument that can accept variable number of values is called varargs.
//https://www.geeksforgeeks.org/variable-arguments-varargs-in-java/
//	https://www.geeksforgeeks.org/method-overloading-ambiguity-varargs-java/
	//	https://www.programiz.com/java-programming/varargs
