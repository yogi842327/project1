package A6constructorsuperboxing;


	 
	class parametrized 
	{ 
	    // data members of the class. 
	    String name; 
	    int id; 
	  
	    // constructor would initialize data members 
	    // with the values of passed arguments while 
	    // object of that class created. 
	    parametrized(String name, int id) 
	    { 
	        this.name = name; 
	        this.id = id; 
	    } 
	} 
	  
	public class J2Constructorwidarg {
 
	    public static void main (String[] args) 
	    { 
	        // this would invoke the parameterized constructor. 
	    	parametrized geek1 = new parametrized("adam", 1); 
	        System.out.println("GeekName :" + geek1.name + 
	                           " and GeekId :" + geek1.id); 
	    } 
	} 
