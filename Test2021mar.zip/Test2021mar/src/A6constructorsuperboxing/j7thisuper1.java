package A6constructorsuperboxing;



	// Java program to illustrate super() put by  
	// compiler always if not provided explicitly 
	  
	class Parentre { 
		Parentre() 
	    { 
	        System.out.println("Parent class's No " +  
	                           "argument constructor"); 
	    } 
		Parentre(int a) 
	    { 
	        System.out.println("Parent class's one " +  
	                           " argument constructor"); 
	    } 
	} 
	  
	public class j7thisuper1 extends Parentre { 
		j7thisuper1() 
	    { 
	        this(10); 
	        System.out.println("No arg const"); 
	    } 
		j7thisuper1(int a) 
	    { 
	        this(10, 20); 
	        System.out.println("1 arg const"); 
	    } 
		j7thisuper1(int k, int m) 
	    { 
	        // See here by default compiler put super(); 
	        System.out.println("2 arg const"); 
	    } 
	    public static void main(String[] args) 
	    { 
	        new j7thisuper1(); 
	        System.out.println("Inside Main"); 
	    } 
	}
