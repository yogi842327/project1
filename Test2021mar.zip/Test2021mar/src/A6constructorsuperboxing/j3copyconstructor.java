package A6constructorsuperboxing;

//There is no copy constructor in Java. However, we can copy the values from one object to another like copy constructo
//https://www.javatpoint.com/java-constructor
	//Java program to initialize the values from one object to another object.  
	public class j3copyconstructor{  
	    int id;  
	    String name;  
	    //constructor to initialize integer and string  
	    j3copyconstructor(int i,String n){  
	    id = i;  
	    name = n;  
	    }  
	    //constructor to initialize another object  
	    j3copyconstructor(j3copyconstructor s){  
	    id = s.id;  
	    name =s.name;  
	    }  
	    void display(){System.out.println(id+" "+name);}  
	   
	    public static void main(String args[]){  
	    	j3copyconstructor s1 = new j3copyconstructor(111,"Karan");  
	    	j3copyconstructor s2 = new j3copyconstructor(s1);  
	    s1.display();  
	    s2.display();  
	   }  
	}  
