package B4Java8NewFeatures;
//https://www.geeksforgeeks.org/functional-interfaces-java/
//https://www.tutorialspoint.com/java8/java8_functional_interfaces.htm

interface Interft {

	public void sum(int a, int b);
}

interface Interfs {
	public void sum1(int c, int d);
}

class Demow implements Interft {
	public void sum(int a, int b) {
		System.out.println("The sum " + (a + b));
	}
}

public class E6Interfacefunctional {
	public static void main(String[] args) {
		Interft i = new Demow();
		i.sum(20, 5);

		int c, d;
		Interfs ii = (a, b) -> System.out.println("The sum wid lambda " + (a + b));
		ii.sum1(5, 10);
	}
}