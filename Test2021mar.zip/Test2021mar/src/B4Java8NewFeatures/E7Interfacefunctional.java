package B4Java8NewFeatures;
//https://www.javatpoint.com/java-8-functional-interfaces
//Where ever Functional Interface concept is applicable there we can use Lambda Expressions

@FunctionalInterface  
interface sayable{  
    void say(String msg);   // abstract method  
    // It can contain any number of Object class methods.  
    int hashCode();  
    String toString();  
    boolean equals(Object obj);  
}  

public class E7Interfacefunctional {
	
	public void say(String msg){  
        System.out.println(msg);  
    }  
    public static void main(String[] args) {  
    	E7Interfacefunctional fie = new E7Interfacefunctional();  
        fie.say("Hello there");  
    }  
}  
/*
@FunctionalInterface annotation is used to ensure that the functional interface can�t have more
 than one abstract method. In case more than one abstract methods are present, the compiler flags an 
 �Unexpected @FunctionalInterface annotation� message. However, it is not mandatory to use this annotation.*/


