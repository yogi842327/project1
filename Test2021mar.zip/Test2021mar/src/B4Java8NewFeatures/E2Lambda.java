package B4Java8NewFeatures;

//https://www.javatpoint.com/java-lambda-expressions

interface Drawable{  
    public void draw();  
}  
public class E2Lambda {  
    public static void main(String[] args) {  
        int width=10;  
  
        //without lambda, Drawable implementation using anonymous class  
        Drawable d=new Drawable(){  
            public void draw(){System.out.println("Drawing widout "+width);}  
        };  
        
      //with lambda  
        Drawable d2=()->{  
            System.out.println("Drawing wid  "+width);  
        };  
        d.draw(); 
        d2.draw(); 
    }  
}  
