package B4Java8NewFeatures;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Y2ConvertArrayToList {

	public static List<Object> convertUsingJavaStream(Object arr[]) {

		List<Object> list = Arrays.stream(arr).collect(Collectors.toList());
		return list;
	}

	public static void main(String[] args) {
		System.out.println(convertUsingJavaStream(new String[] {"CITI","HSBC","SBI"}));
	}
}
