package B4Java8NewFeatures;

//https://www.javatpoint.com/java-default-methods
//Java provides a facility to create default methods inside the interface.

interface Interfuu {
	default void m1() {
		System.out.println("Default Method");
	}
}

public class E4Default implements Interfuu {
	public static void main(String[] args) {
		E4Default t = new E4Default();
		t.m1();
	}
}

/*
 * // Until 1.7 version onwards inside interface we can take only public
 * abstract methods and public static final variables (every method present
 * inside interface is always public and abstract whether we are declaring or
 * not). ☀ Every variable declared inside interface is always public static
 * final whether we are declaring or not. ☀ But from 1.8 version onwards in
 * addition to these, we can declare default concrete methods also inside
 * interface, which are also known as defender methods.
 */


/*Interface default methods are by-default available to all implementation classes. Based on
requirement implementation class can use these default methods directly or can override.
We can’t override object class methods as default methods inside interface otherwise we get
compile time error.
As interface static methods by default not available to the implementation class, overriding
concept is not applicable.*/

