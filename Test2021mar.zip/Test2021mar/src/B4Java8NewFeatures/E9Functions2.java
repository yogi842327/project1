package B4Java8NewFeatures;

import java.util.function.*;

/*//Functions are exactly same as predicates except that functions can return any type of result but
function should (can) return only one value and that value can be any type as per our
requirement one apply( methods)*/
public class E9Functions2 {
	public static void main(String[] args) {
		Function<String, Integer> f = s -> s.length();
		System.out.println(f.apply("Tested"));
		System.out.println(f.apply("Soft"));
	}
}
