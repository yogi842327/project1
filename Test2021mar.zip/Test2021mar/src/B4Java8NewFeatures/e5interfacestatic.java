
package B4Java8NewFeatures;

interface Interfd {
	public static void sum(int a, int b) {
		System.out.println("The Sum:" + (a + b));
	}
}

public class e5interfacestatic implements Interfd {
	public static void main(String[] args) {
		e5interfacestatic t = new e5interfacestatic();
		/*
		 * t.sum(10, 20); //CE Test.sum(10, 20); //CE
		 */ Interfd.sum(10, 20);
	}
}