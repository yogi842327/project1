package B4Java8NewFeatures;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class F3STream {
	public static void main(String[] args) {
		ArrayList<Integer> l1 = new ArrayList<Integer>();
		for (int i = 0; i <= 10; i++) {
			l1.add(i);
		}
		System.out.println(l1);
		ArrayList<Integer> l2 = new ArrayList<Integer>();
		for (Integer i : l1) {
			if (i % 2 == 0)
				l2.add(i);
		}
		System.out.println(l2);

		for (int i = 0; i <= 10; i++) {
			l1.add(i);
		}
		System.out.println(l1);
		List<Integer> l3 = l1.stream().filter(i -> i % 2 == 0).collect(Collectors.toList());
		System.out.println("stream n filter " + l3);

		// map and collect

		ArrayList<String> l = new ArrayList<String>();
		l.add("rvk");
		l.add("rk");
		l.add("rkv");
		l.add("rvki");
		l.add("rvkir");
		System.out.println(l);
		List<String> l4 = l.stream().map(s -> s.toUpperCase()).collect(Collectors.toList());
		System.out.println("map and collect 8 " + l4);

	}
}

/*
 * If we want to represent a group of individual objects as a single entity then
 * We should go for collection.  If we want to process a group of objects from
 * the collection then we should go for streams.  We can create a stream object
 * to the collection by using stream() method of Collection interface. stream()
 * method is a default method added to the Collection in 1.8 version. can
 * process 2 phases Configuration 2.Processing Configuration: Filtering: We can
 * configure a filter to filter elements from the collection based on some
 * boolean condition by using filter()method of Stream interface. public Stream
 * filter( configuration: Mapping: If we want to create a separate new object,
 * for every object present in the collection based on our requirement then we
 * should go for map() method of Stream interface. public Stream map (Function
 * f); 2) Processing processing by collect() method Processing by count()method
 * Processing by sorted()method Processing by min() and max() methods forEach()
 * method toArray() method Stream.of()method
 * 
 */
