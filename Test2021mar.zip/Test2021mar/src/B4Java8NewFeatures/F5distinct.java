package B4Java8NewFeatures;

import java.util.stream.Stream;

//https://www.java2novice.com/java-8/streams/distinct-method-example/

public class F5distinct {

	public static void main(String a[]) {

		Stream.of("bus", "car", "bycle", "bus", "car", "car", "bike").distinct().forEach(System.out::println);
	}

}
