package B4Java8NewFeatures;

import java.util.*;
public class Y3ForeachListJ8{
public static void main(String[] args) 
   { 

	// create an ArrayList which going to 
       // contains a list of Numbers 
       ArrayList<Integer> Numbers = new ArrayList<Integer>(); 
 
       // Add Number to list 
       Numbers.add(23); 
       Numbers.add(32); 
       Numbers.add(45); 
       Numbers.add(63); 
 for (Integer i : Numbers) {
   System.out.println(i);
 //  Numbers.add(66);
  // Numbers.remove(i); // throws exception
}   

 System.out.println("-----------------");
       // forEach method of ArrayList and 
       // print numbers 
      Numbers.forEach((n) -> System.out.println(n)); 
  
System.out.println("java 7 for each-----------------");
char[] vowels = {'a', 'e', 'i', 'o', 'u'};
// foreach loop
for (char item: vowels) {
   System.out.println(item);
}
}
}
