package B4Java8NewFeatures;

import java.util.*;
import java.util.List;
import java.util.stream.Collectors;
import java.util.function.Predicate; 
import java.util.function.Function;;

//A group of individual object as a single entity then we should go for collection.
//if we want to process objects from the collections. then go for stream

//predicate/test return only boolean value but function/apply should be return one ? value
//filter inside can use predicate and direct
//map use to change data touppercase , number-3
//Supplier : Conumer always consume/accept/displaydata the value but supplier/get always provide the value.:randomdata 
public class Y4Streamodd {
	public static void main(String[] args) {
	//	int i=0;
		//map: List<String> l2 = l.Stream().map(s ->s.toUpperCase()).collect(Collectors.toList());
		//map map(String::toUpperCase)  and map(number -> number * 3)
		 List<String> numbers = Arrays.asList("1", "2", "3", "4", "5", "6");
		    System.out.println("original list: " + numbers);
		    		    List<Integer> even = numbers.stream()
		                                .map(changevalue -> Integer.valueOf(changevalue))
		                                .filter(number -> number % 2 == 0)
		                                .collect(Collectors.toList());
		    System.out.println("processed list, only even numbers: " + even);	
//2nd
		  
		    ArrayList<Integer> l1 = new ArrayList<Integer>();
		    l1.add(1);
			l1.add(2);
		     for(int i=0; i<=10; i++) {
		     l1.add(i);
		     }
		     System.out.println(l1);
		     Predicate<Integer> checkeven = test -> test%2==0;
		     // its methods like: public boolean test(Integer I) {  and can use inside filters
		     List<Integer> l2 = l1.stream().filter(checkeven).collect(Collectors.toList());
		     System.out.println(l2);
		     Function<String, Integer> f = s ->s.length();
		      System.out.println("function ex "+f.apply("Durga"));

	}
	

}
