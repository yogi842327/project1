package B4Java8NewFeatures;

import java.util.Arrays;
import java.util.List;
import java.util.Spliterator;

//https://www.javatpoint.com/post/java-spliterator
//Spliterators interface can be used for traversing the elements of a source one by one. These sources could be an array, a Collection, an IO Channel or a generator function
//Splitting the source data ,Processing the source data

public class F1InterfaceSpliteratorExample3 {
	public static void main(String[] args) {
		List<String> progList = Arrays.asList("Java", "Android", "Python", "C++");
		Spliterator<String> splitr = progList.spliterator();
		Spliterator<String> st = splitr.trySplit();
		splitr.forEachRemaining(System.out::println);
		System.out.println("Traversing the next half of the spliterator-");
		st.forEachRemaining(System.out::println);
		
		//2
		List<String> fruitList = Arrays.asList("Mango", "Banana", "Apple");  
		Spliterator<String> splitrs = fruitList.spliterator();  
        System.out.println("List of Fruit name-");  
        while(splitrs.tryAdvance((num) -> System.out.println("" +num)));  
	}
}
