package B4Java8NewFeatures;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Y5StreamFilter {

	public static void main(String[] args) {

		// personFilter();
		Integer arr[] = { 4, 67, 5, 2, 4, 6, 9 };
		filterEvenNumbers(arr);

	}

	private static void personFilter() {
		List<Y5Person> personList = new ArrayList<Y5Person>();
		personList.add(new Y5Person("Vikas", 101, "Blr", "989898989"));
		personList.add(new Y5Person("Yogi", 201, "Pune", "889898989"));
		personList.add(new Y5Person("Raj", 301, "Blr", "789898989"));
		personList.add(new Y5Person("John", 401, "Del", "989898989"));
		// filter based on city
		Predicate<Y5Person> function = person -> person.getCity().equals("Blr");
		List<Y5Person> p = personList.stream().filter(function).collect(Collectors.toList());
		// TODO: filter based on number starting with 9
		Predicate<Y5Person> fun2 = person -> person.getMob().startsWith("9");
		List<Y5Person> p2 = personList.stream().filter(fun2).collect(Collectors.toList());

		System.out.println(p);
		System.out.println(p2 + "mob");
	}

	public static List<Integer> filterEvenNumbers(Integer arr[]) {
		List<Integer> evenList = Arrays.asList(arr);
		Predicate<Integer> evenPredicate = number -> number % 2 == 0;

		List<Integer> filteredList = evenList.stream().filter(evenPredicate).collect(Collectors.toList());
		System.out.println("Even number(s): "+filteredList);
		return filteredList;
	}
}
