package B4Java8NewFeatures;

//https://www.javatpoint.com/java-8-method-reference
//Reference to a static method,instancemethods ,constructor

interface Sayables {
	void say();
}

public class E6Methodreference {
	public static void saySomething() {
		System.out.println("Hello, this is static method.");
	}

	public static void main(String[] args) {
		// Referring static method
		Sayables sayable = E6Methodreference::saySomething;
		// Calling interface method
		sayable.say();
	}
}