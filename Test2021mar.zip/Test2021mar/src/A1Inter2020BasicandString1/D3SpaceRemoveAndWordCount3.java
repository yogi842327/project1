package A1Inter2020BasicandString1;

public class D3SpaceRemoveAndWordCount3 {

	static int i, c = 0, res;
	


	public static void main(String args[]) {
		//1
		System.out.println(" First  Original String is :    manchester united is also known as red devil    ");
		D3SpaceRemoveAndWordCount3.whitespaceremove("   manchester united is also known as red devil    ");

		
		
	//	System.out.println(" The original string is \n  manchester united is also known as red devil    ");
	//	System.out.println("Second  Original String is : \n ");
		res = D3SpaceRemoveAndWordCount3.wordcount("   manchester united is also known as red devil ");
	//	res = D3SpaceRemoveAndWordCount3.wordcount("m");
		// string is always passed in double quotes

		System.out.println("Second The number of words in the String are :  " + res);
		// System.out.println(" aster united is also known as red devil ");
		
		//can ignore third
		System.out.println("Third  Original String is : \n ");
		D3SpaceRemoveAndWordCount3.countwords("   manchester united is also known as red devil    ");
	}

	// Programs 1: whitespace remove space
	static void whitespaceremove(String s) {
		 String stringc = "";
		 char ch='0';
		for (i = 0; i < s.length(); i++) {
			 ch = s.charAt(i);
			if (ch != ' ')
				stringc=stringc+ch;
			//	System.out.println(ch);
			
		}
		System.out.println("First string remove space:  "+stringc);
	//	System.out.println("charecters : "+ch);
	}
	
	
	//program 2
		static int wordcount(String s) {
			char ch[] = new char[s.length()]; // in string especially we have to mention the () after length
			for (i = 0; i < s.length(); i++) {
				ch[i] = s.charAt(i);
				//|| ((ch[0] != ' ') && (i == 0)) : only for count single word 
				//count for all line: ((i > 0) && (ch[i] != ' ') && (ch[i - 1] == ' '))
				if (((i > 0) && (ch[i] != ' ') && (ch[i - 1] == ' ')) || ((ch[0] != ' ') && (i == 0)))
					c++;
			}
			return c;
		}

	// Program 3
//not important just use for first charecters of words inside array 
			static void countwords(String s) {
				int j = 0;
				char[] ch = new char[s.length()];
				int c = s.length();
				char[] temp = new char[c];

				for (i = 0; i < s.length(); i++) {

					ch[i] = s.charAt(i);

					if (((i > 0) && (ch[i] != ' ') && (ch[i - 1] == ' ')) || ((ch[0] != ' ') && (i == 0))) {
						do {
							temp[j] = ch[i];
							j++;
						} while (j > i);
					}
				}
				for (Character num : temp) {
				//	 System.out.println(num);

				}
				System.out.print("Third value is here " + j+" \n Finish  ");

			}

}