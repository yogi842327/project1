package A1Inter2020BasicandString1;

import java.util.Scanner;

public class B5Palindromennumber {
	// A function to check 
    // if n is palindrome 
    static int isPalindrome(int n) 
    { 
         
    	//logic 1
      /*  // Find reverse of n 
        int rev = 0;
        int sum = 0;
        int temp=n;
        while (n > 0) {
			rev = n % 10; // getting remainder
			sum = (sum * 10) + rev;
			n = n / 10;
		}
		if (temp == sum) {
			//System.out.println("is palindrome number "+temp);
			System.out.print(" "+temp);
		}else {
			//System.out.println(" First not palindrome");
		}*/
    	
        //logic2
    	int rev = 0;
    	for (int i = n; i > 0; i /= 10) 
            rev = rev * 10 + i % 10; 
              
        // If n and rev are same,  
        // then n is palindrome 
        return(n == rev) ? 1 : 0; 
    } 
      
    // prints palindrome between 
    // min and max 
    static void countPal(int min, int max) 
    { 
        for (int i = min; i <= max; i++) 
            if (isPalindrome(i)==1) 
                System.out.print(i + " "); 
    } 
      
    // Driver Code 
    public static void main(String args[]) 
    { 
    	int r, sum = 0, temp;
		int n = 454;// It is the number variable to be checked for palindrome

		temp = n;
		//1st number
		System.out.println("First normal number ");
		while (n > 0) {
			r = n % 10; // getting remainder
			sum = (sum * 10) + r;
			n = n / 10;
		}
		if (temp == sum) {
			System.out.println(sum+" palindrome number ");
		}else {
			System.out.println(" First not palindrome");
		}
    	//second
		System.out.println("second 0 to n ");
    	int min=100 ;
    	int max=1400;
    	System.out.println(" palindrome number between "+min+" to "+max);
        countPal(min, max); 
        
    } 
} 