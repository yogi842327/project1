package A1Inter2020BasicandString1;

public class E1Withoutlengthmethod4 {

	public static void main(String[] args) {
		   
		String blah = "HellO";
		System.out.println(blah.length()+ " Simple via length()");
		int count = 0;
		System.out.println(" Main Logic " );
		for (char c : blah.toCharArray()) {
		    count++;
		}
		
		System.out.println("blah's length: " + count);

		    String str = "12345";
		    int counter = str.length();
		    System.out.println(counter + " Total charecters  lenth()");
			char[]a=str.toCharArray();
				int c=a.length;
		System.out.println(c+ " Via array length function");
		System.out.println(" Another way");
		String str1="abcdef";
		// str2 = str1 + '\0';
		    
		

	//	System.out.println(count+ " Another wayd");

		int length1 = 0;
		while (!str1.equals("")) {
		    str1 = str1.substring(1);
		    ++length1;
		
		}
		System.out.println("Length is "+length1+ " Another ways");
		int count1 = 0;
		//  If you write '\0' to position n of a NUL-terminated string, 
			for (int i = 0; str1.charAt(i) != '\0'; i++) {
        count1++;
    }
		 	
		 }
		}
		//0 letters.

		   
