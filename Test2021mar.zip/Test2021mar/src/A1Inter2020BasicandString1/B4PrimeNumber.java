package A1Inter2020BasicandString1;

import java.util.Scanner;

public class B4PrimeNumber {
	public static void main(String args[]) {

		// approach 1st first
		System.out.println(" approach  1 ");
		int i, m = 0, flag = 0;
		int n = 3;// it is the number to be checked
		m = n / 2;
		if (n == 0 || n == 1) {
			System.out.println(n + " is not prime number");
		} else {
			for (i = 2; i <= m; i++) {
				if (n % i == 0) {
					System.out.println(n + " is not prime number");
					flag = 1;
					break;
				}
			}
			if (flag == 0) {
				System.out.println(n + " is prime number");
			}
		}// end of else

		// second approach between two numbers
		Scanner s = new Scanner(System.in);
		System.out.print("Enter the first number : ");
		int start = s.nextInt();
		System.out.print("Enter the second number : ");
		int end = s.nextInt();
		System.out.println("List of prime numbers between " + start + " and "
				+ end);
		//approach 2nd between two number without math
		for (int x = start; x <= end; x++) {
			if (isPrimetwonumbers(x)) {
				System.out.println(x);
			}
		}
		//approach 3 with math function
		for (int j = start; j <= end; j++) {
			if (isPrime(j)) {
				System.out.println(j);
			}
		}
	}
    //2nd
	public static boolean isPrimetwonumbers(int n) {
		System.out.println(" 2nd prime number between two numbers " );
		int m=n/2;
		int flag=0; 
		if (n == 0 || n == 1) {
			//System.out.println(n + " is not prime number");
			return false;
		} else {
			for (int i = 2; i <= m; i++) {
				if (n % i == 0) {
					
					return false;
				}
			}
			if (flag == 0) {
				return true;
				//System.out.println(n + " is prime number");
			}
		}	return true;
	}
	//3rd math
	public static boolean isPrime(int n) {
		System.out.println(" 3rd prime number between two numbers " );
		if (n <= 1) {
			return false;
		}
		for (int i = 2; i <= Math.sqrt(n); i++) {
			if (n % i == 0) {
				return false;
			}
		}
		return true;
	}
}
