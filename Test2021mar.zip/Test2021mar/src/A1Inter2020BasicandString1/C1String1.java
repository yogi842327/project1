package A1Inter2020BasicandString1;

public class C1String1 {

	public static void main(String[] args) {
		// p1

		char[] ch = { 'j', 'a', 'v', 'a', 't', 'p', 'o', 'i', 'n', 't' };
		String str1 = new String(ch);
		String str2 = "javatpoint"; // same as str1
		System.out.println(" Value of charstr2: " + ch.toString() + " string1: " + str1);// java rules
		String s1 = "java";
		s1.concat(" rules");
		//s1.append(" rules");// CE only wid sb and sbuilder
		// Yes, s1 still refers to "java"
		System.out.println("s1 refers to3: " + s1); // java
		// calll via string literals
		String s11q = "javahungry";
		int saq = 11;
		char charstr = 0;
		int charstrs = 0;
		charstrs = "javahungry".indexOf('u');//5
		charstr = "javahungry".charAt(0);//0
		saq = "javahungry".compareTo("javahungry"); //0
		System.out.println(" Value of charstr4: " + charstrs + charstr + saq);// java rules

		s1 = s1.concat(" rules");
		System.out.println("s1 refers to5: " + s1);// java rules
		s1 = "Change Value";
		System.out.println("s1 refers to7: " + s1);// change value of s1
		// p2

		String a = "abc"; 
		String b = "abc";// only one object created samere reference
		System.out.println(a == b); // true  //check reference

		String c = new String("abc"); 
		String d = new String("abc");// two object created
		System.out.println(c == d); // false

		System.out.println(a.equals(b) + "  and: " + c.equals(d));// true //check contenet

		// p9
		String ss = "Sachin";
		System.out.println(ss.charAt(0));// S
		System.out.println(ss.charAt(3));// h
		int a1 = 10;
		String s2 = String.valueOf(a1);
		System.out.println(s2 + 10); // op 1010
		System.out.println(ss.toUpperCase());// SACHIN
		System.out.println(ss.toLowerCase());// sachin
		System.out.println(ss);// Sachin(no change in original)

//p3

		System.out.println("Hello World:");
		String is1 = "Rakesh";
		String is2 = "Rakesh";
		String is3 = "Rakesh".intern();
		String is4 = new String("Rakesh");
		String is5 = new String("Rakesh").intern();

		if (is1 == is2) {
			System.out.println("s1 and s2 are same:"); // 1.
		}

		if (is1 == is3) {
			System.out.println("s1 and s3 are same:"); // 2.
		}

		if (is1 == is4) {
			System.out.println("s1 and s4 are same:"); // 3. //not same
		}

		if (is1 == is5) {
			System.out.println("s1 and s5 are same:"); // 4.
		}

//p4
		String strs = "Geeks for Geeks";
		String[] arrOfStr = strs.split(" ");

		for (String a2 : arrOfStr) {
			System.out.println(a2 + " arrray ");
		}

		// p5

		System.out.println(" P5 Hello World");
		// S1 refers to Object in the Heap Area
		String qs1 = new String("GFG"); // Line-1

		// S2 refers to Object in SCP Area
//		/String s1 = "java";
		String qs2 = s1.intern(); // Line-2

		// Comparing memory locations
		// s1 is in Heap
		// s2 is in SCP
		System.out.println(qs1 == qs2+"55 ");

		// Comparing only values
		System.out.println("66 "+qs1.equals(qs2));

		// S3 refers to Object in the SCP Area
		String qs3 = "GFG"; // Line-3

		System.out.println(qs2 == qs3 + " Value 8 ");

		// p6

		String s11 = "Sachin";
		String s21 = "Sachin";
		String s31 = "Ratan";
		System.out.println(s11.compareTo(s21)+" 99a ");// 0
		System.out.println(s11.compareTo(s31)+" 77ba ");// 1(because s1>s3)
		System.out.println(s31.compareTo(s11));// -1(because s3 < s1 )

		String s121 = 50 + 30 + " Sachin" + 40 + 40;
		System.out.println(s121 + " t55 concat+ not sum ");// 80Sachin4040

		// p7

		System.out.println(" StringBuffer ");
		StringBuffer sb3 = new StringBuffer("Geeksfor");
		sb3.append("Geeks");
		System.out.println(" sb y7 " + sb3);
		sb3.insert(1, "Java");
		System.out.println(" sb insert u8 " + sb3);
		StringBuilder sb4 = new StringBuilder("Geeksfor");
		// sb4.concat(" rules"); //CE only wid string
		// concat for and can not use with StringBuffer and Builder can use
		// append can use wid sb sb

		StringBuilder sbs = new StringBuilder("Hello ");
		sbs.insert(1, "Java");// now original string is changed
		System.out.println(sbs);// prints HJavaello
		sbs.replace(1, 3, "Java");
		System.out.println(sbs);// prints HJavalo
		sbs.reverse();
		System.out.println(sbs);// prints olleH

		// p8
		System.out.println(" p8 ");
		// object lable
		String sds = "ppppp";
		StringBuffer sbr = new StringBuffer("Hello");
		// sbr=new StringBuffer("rr"); // compile time error(cause final)
		// sbr="try";// compile time error
		sds = "tryf";// compile time error

		// variable label:
		int v = 10;
		v = 11;

		String strs1 = "abc";
		String strs2 = null;
		System.out.println(strs1.equals("abc") + "1"); // true
		System.out.println("abc".equals(strs1) + "2"); // true
		// System.out.println(strs1.equals("null")+"3"); //npe
		// System.out.println(strs2.equals("null")+"3"); //npe
		System.out.println("null".equals(strs2) + "4");
		System.out.println("null".equals(strs1) + "44");
		System.out.println((strs1 == strs2) + "5");
		System.out.println(("abc" == (strs1)) + "6");
		System.out.println((strs2 == ("null")) + "7");//f
		System.out.println(("null" == (strs2)) + "8");//f
		System.out.println((strs1 == ("null")) + " 9w");//f
		System.out.println(("null" == (strs1)) + " u7");//f

	}
}
