package A1Inter2020BasicandString1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

//https://www.javainterviewpoint.com/anagram-program-in-java/
//1st and 5th approch same
public class D2StringAnagram36ways {

	public static void main(String[] input) {
		//Subtring examples
		   String s="SachinTendulkar";  
		   System.out.println(s.substring(6));//Tendulkar  
		   System.out.println(s.substring(0,6));//Sachin  
		Scanner scanner = new Scanner(System.in);

		// Getting the input string from the user
		// 1st
		System.out.print("Enter the First String : ");
		String s1 = scanner.nextLine();

		System.out.print("Enter the second String : ");
		String s2 = scanner.nextLine();
		System.out.println("1st with Array.sort Anagrams");
		if (checkAnagram1(s1, s2))
			System.out.println(s1 + " and " + s2 + " are Anagrams");
		else
			System.out.println(s1 + " and " + s2 + " are NOT Anagrams");

		scanner.close();

		// 2nd with String removed string through sub string
		System.out.println("2nd with  Anagrams substring");
		if (checkAnagram2(s1, s2))
			System.out.println(s1 + " and " + s2 + " are Anagrams");
		else
			System.out.println(s1 + " and " + s2 + " are NOT Anagrams");

		scanner.close();

		// 3rd with String removed string direct
		System.out.println("3rd with string replace Anagrams");
		if (checkAnagram3(s1, s2))
			System.out.println(s1 + " and " + s2 + " are Anagrams");
		else
			System.out.println(s1 + " and " + s2 + " are NOT Anagrams");

		scanner.close();

		// 4th with char removed in hashmap
		System.out.println("4th with hashmap Anagrams");
		if (checkAnagram4hm(s1, s2))
			System.out.println(s1 + " and " + s2 + " are Anagrams");
		else
			System.out.println(s1 + " and " + s2 + " are NOT Anagrams");

		scanner.close();

		// 5th with String  arraylist
		System.out.println("5th with collection.sortt Anagrams");
		if (checkAnagram5al(s1, s2))
			System.out.println(s1 + " and " + s2 + " are Anagrams");
		else
			System.out.println(s1 + " and " + s2 + " are NOT Anagrams");

		scanner.close();
		
		// 6th with String  incremented not important
				System.out.println("6th with incremented Anagrams");
				if (checkAnagram6increment(s1, s2))
					System.out.println(s1 + " and " + s2 + " are Anagrams");
				else
					System.out.println(s1 + " and " + s2 + " are NOT Anagrams");

				scanner.close();
				
				// 7th with String  XOR not important
				System.out.println("7th with XOR Anagrams");
				if (checkAnagram7XOR(s1, s2))
					System.out.println(s1 + " and " + s2 + " are Anagrams");
				else
					System.out.println(s1 + " and " + s2 + " are NOT Anagrams");

				scanner.close();

	}

	public static boolean checkAnagram1(String s1, String s2) {
		// Remove all the white space
		s1 = s1.replaceAll("\\s", "");
		s2 = s2.replaceAll("\\s", "");

		// Check if both length matches
		if (s1.length() != s2.length())
			return false;
		else {
			// Convert both Strings into lower case and into Character Array
			char[] arr1 = s1.toLowerCase().toCharArray();
			char[] arr2 = s2.toLowerCase().toCharArray();

			// Sort both Character Array
			Arrays.sort(arr1);
			Arrays.sort(arr2);

			// Check if both arrays are equal
			return (Arrays.equals(arr1, arr2));
		}
	}

	public static boolean checkAnagram2(String s1, String s2) {
		// Remove all the white space and convert to lower case
		s1 = s1.replaceAll("\\s", "").toLowerCase();
		s2 = s2.replaceAll("\\s", "").toLowerCase();

		// Check length of both strings
		if (s1.length() != s2.length())
			return false;
		else {
			for (int i = 0; i < s1.length(); i++) {
				for (int j = 0; j < s2.length(); j++) {
					if (s1.charAt(i) == s2.charAt(j)) {
						//0 to j for between and removed j charecter
						//j+1 for removed and and from j index
						s2 = s2.substring(0, j) + s2.substring(j + 1);
						break;
					}
				}
			}

			if (s2.length() == 0) {
				return true;
			} else {
				return false;
			}
		}
	}

	public static boolean checkAnagram3(String s1, String s2) {
		// Remove all the white space and convert to lower case
		s1 = s1.replaceAll("\\s", "").toLowerCase();
		s2 = s2.replaceAll("\\s", "").toLowerCase();

		// Check length of both strings
		if (s1.length() != s2.length())
			return false;
		else {
			for (int i = 0; i < s1.length(); i++) {
				for (int j = 0; j < s2.length(); j++) {
					if (s1.charAt(i) == s2.charAt(j)) {
						s2 = s2.replaceFirst(Character.toString(s2.charAt(j)), "");
						//s2 = s2.replaceAll(s2.charAt(j), "");
						break;
					}
				}
			}

			if (s2.length() == 0) {
				return true;
			} else {
				return false;
			}
		}
	}

	public static boolean checkAnagram4hm(String s1, String s2)
    {
        if (s1.length() != s2.length())
            return false;
        HashMap<Character, Integer> map = new HashMap<Character, Integer>();
        for (int i = 0; i < s1.length(); i++)
        {
            char c = s1.charAt(i);
            if (map.containsKey(c))
                map.put(c, map.get(c) + 1);
            else
                map.put(c, 1);
        }
        for (int i = 0; i < s2.length(); i++)
        {
            char c = s2.charAt(i);
            if (map.containsKey(c))
            {
                if (map.get(c) == 1)
                    map.remove(c);//removed all charecters
                else
                    map.put(c, map.get(c) - 1);
            } else
                return false;
        }
        if (map.size() > 0)
            return false;
        return true;
    }
	
	public static boolean checkAnagram5al(String s1, String s2)
    {
        s1 = s1.replaceAll("\\s", "").toLowerCase();
        s2 = s2.replaceAll("\\s", "").toLowerCase();

        if (s1.length() != s2.length())
            return false;

        List<Character> list1 = new ArrayList<Character>();
        List<Character> list2 = new ArrayList<Character>();

        for (int i = 0; i < s1.length(); i++)
        {
            list1.add(s1.charAt(i));
        }
        for (int i = 0; i < s2.length(); i++)
        {
            list2.add(s2.charAt(i));
        }

        Collections.sort(list1);
        Collections.sort(list2);

        if (list1.equals(list2))
            return true;
        else
            return false;
    }
	
	
	public static boolean checkAnagram6increment(String s1, String s2)
	{
		// Remove all the white space, convert to lower case & character array
		char[] arr1 = s1.replaceAll("\\s", "").toLowerCase().toCharArray();
		char[] arr2 = s2.replaceAll("\\s", "").toLowerCase().toCharArray();

		if (arr1.length != arr2.length)
			return false;
		// int array to hold value for 26 alphabets
		int[] value = new int[26];
		for (int i = 0; i < arr1.length; i++)
		{
			// Increment the value at index i by 1
			value[arr1[i] - 97]++;
			// Decrement the value at index i by 1
			value[arr2[i] - 97]--;
		}
		// Value array will have only zeros, if strings are anagram
		for (int i = 0; i < 26; i++)
			if (value[i] != 0)
				return false;
		return true;
	}
	
	public static boolean checkAnagram7XOR(String s1, String s2)
	{
		// Remove all the white space, convert to lower case & character array
		char[] arr1 = s1.replaceAll("\\s", "").toLowerCase().toCharArray();
		char[] arr2 = s2.replaceAll("\\s", "").toLowerCase().toCharArray();
		if (arr1.length != arr2.length)
			return false;
		
		 int xor = 0;
		 
         for (int i = 0; i < arr1.length; i++)
         {
             xor ^= arr1[i] ^ arr2[i];
         }

         return xor == 0? true: false;
	}
	
}