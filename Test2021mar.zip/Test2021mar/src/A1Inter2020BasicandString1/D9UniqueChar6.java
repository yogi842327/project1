package A1Inter2020BasicandString1;

import java.util.HashSet;
import java.util.Iterator;

public class D9UniqueChar6 {

	//not important no mean
	 public static void main (String args[])
	    {
		 HashSet<String> set=new HashSet<String>();  
			boolean val=  set.add("Ravi");  
			val=  set.add("Vijay");  
			val=  set.add("Ravi");  
			val=   set.add("Ajay");  
			  //Traversing elements  
			  Iterator<String> itr=set.iterator();  
			  while(itr.hasNext()){  
			   System.out.println(itr.next());  
			  }  
			   
			  
	        boolean result=false;
	       // String inputstring="Alve owsom"; //false
	        String inputstring="Alve iwsom";  //true
	        System.out.println(inputstring);
	        HashSet < Character> uniquecharset= new HashSet();
	        for(int i=0;i < inputstring.length();i++)
	        {
	            result=uniquecharset.add(inputstring.charAt(i));
	            if (result == false)
	            break;
	        }
	    System.out.println(result); }
	}
