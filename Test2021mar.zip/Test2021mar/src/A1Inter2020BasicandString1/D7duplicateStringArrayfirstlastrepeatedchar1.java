package A1Inter2020BasicandString1;

import java.util.Arrays;

public class D7duplicateStringArrayfirstlastrepeatedchar1 {
	public static void main(String[] args) {

		String input = new String("abbc");
		String output = new String();
		String output1 = new String();
		System.out.println("Hi ");

		String stringWithDuplicates = "abtyabcf";
		char[] characters = stringWithDuplicates.toCharArray();
		int length = characters.length;
		boolean unique = false;
		int i = 0;
		int j = 0;
		System.out.println("String with duplicates : " + stringWithDuplicates);
		for (i = 0; i < length; i++) {
			for (j = i + 1; j < length; j++) {
				if (characters[i] == characters[j]) {
					int temp = j;// set duplicate element index

					// delete the duplicate element by shifting the elements to left
					for (int k = temp; k < length - 1; k++) {
						characters[k] = characters[k + 1];
						// output1=output1+characters[k];
					}
					j--;
					length--;// reduce char array length

				}
			}

		}
		//2
		String stringWithOutDuplicates = new String(characters);
		System.out.println(" a2 String after duplicates removed1 its showing garbage data too so use"
				+ "substring : " + stringWithOutDuplicates);
		stringWithOutDuplicates = stringWithOutDuplicates.substring(0, length);
		System.out.println("a3 String after duplicates removed : " + stringWithOutDuplicates);
		String testString = Arrays.toString(characters); //just for print array instring "[]"
		System.out.println("a4 Removed duplicates  " + testString);

		// 2nd approach
		for (i = 0; i < length; i++) {
			unique = false;
			// int val = 0;
			for (j = 0; j < length; j++) {
//				if (i != j && stringWithDuplicates.charAt(i) == stringWithDuplicates.charAt(j)) {
				if (i != j && stringWithDuplicates.charAt(i) == stringWithDuplicates.charAt(j)) {
					// output1 = output1 + stringWithDuplicates.charAt(i);
					unique = true;
					// System.out.println(s.charAt(i)+"val "+val++);
					break;
				}
			}
		}
		if (unique) {
			System.out.println("a5 First non repeated characted in String \"" + stringWithDuplicates + "\" is:"
					+ stringWithDuplicates.charAt(i));

		}

		// For finf first duplicate
		// 2nd approach

		char ch = 0;
		for (i = 0; i < stringWithDuplicates.length(); i++) {
			unique = true;
		//	int val = 0;
			if (ch != 0) {
				break;
			}
			for (j = 0; j < stringWithDuplicates.length(); j++) {
				if (i != j && stringWithDuplicates.charAt(i) == stringWithDuplicates.charAt(j)) {
					unique = false;
					ch = stringWithDuplicates.charAt(i);
					System.out.println("a6 first repeated  " + stringWithDuplicates.charAt(i));
					break;
				}

			}
		}
	}

}
