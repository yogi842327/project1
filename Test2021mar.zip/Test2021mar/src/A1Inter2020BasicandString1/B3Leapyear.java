package A1Inter2020BasicandString1;

public class B3Leapyear {
	public static void main(String args[]) {
		int num = 100;
		if ((num % 4 == 0) && (num % 100 != 0) || (num % 400 == 0) ){
			System.out.println("Number is leap year");
		} else {
			System.out.println("Number is not leap year");

		}

	}

}
