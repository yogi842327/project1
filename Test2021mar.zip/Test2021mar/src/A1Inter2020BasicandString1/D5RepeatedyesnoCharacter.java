package A1Inter2020BasicandString1;

import java.util.LinkedHashMap;
import java.util.Map;

class D5RepeatedyesnoCharacter {
	
	//Each Entry contains key and value. To get key and value from the entry you use accessor and modifier methods.

//If you want to get values with given key, use get() method and to insert value, use put() method.

	public static void main(String[] args) {
		String s = "ffeeddbbaacfflck";
		String output12 = null;
		Map<Character, Integer> map = new LinkedHashMap<Character, Integer>();
		char [] c = s.toCharArray();

		for (char ch : c) {
			if (map.containsKey(ch)) {
				int count = map.get(ch);
				map.put(ch, count + 1);
			} else {
				map.put(ch, 1);
			}

		}
		System.out.println("with mapData ffeeddbbaacfflck : "+map);
		//
		for (char ch : c) {
			
			if (map.get(ch) == 1) {
				System.out.println("Map 1st non repeated characted in String \"" + s + "\" is:" + ch);
				break;
			}

		}
		for (char ch1 : c) {
			if ((map.get(ch1)) >= 2) {
				System.out.println("Map First repeated characted in String \"" + s + "\" is:" + ch1);
				break;
			}
		}
		// 2nd approach First repeated
		int j = 0;
		char ch = 0;
		for (int i = 0; i < s.length(); i++) {
			int temps = i;
			boolean unique = true;
			int count = 0;
			if (ch != 0) { // just flag use
				break;
			}
			for (j = 0; j < s.length(); j++) {
				if (i != j && s.charAt(i) == s.charAt(j)) {
					unique = false;
					ch = s.charAt(i);
					count++;
					System.out.println("first repeated correct 2nd  " + s.charAt(i));
					break;
				}

			}
			// 3rd approach First non duplicate non repeated
			for (i = 0; i < s.length(); i++) {
				temps = 0;
				unique = true;
				for (j = 0; j < s.length(); j++) {
					if (i != j && s.charAt(i) == s.charAt(j)) {
						unique = false;
						break;
					}

				}

				// below code 3rd code
				if (unique) {
					System.out.println("non repeated characted in String \"" + s + "\" is:" + s.charAt(i));
					// output12=output12+s.charAt(i);
					// System.out.println(output12);
					break;
				}
			}
		}

	}
}