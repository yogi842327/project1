package A1Inter2020BasicandString1;


import java.util.Scanner;

public class A5SumRecursionArray {

	public static void main(String arg[]) {
		int n;
		int s = 0, a[];
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter how many numbers you want sum");
		n = sc.nextInt();
		a = new int[n];
		System.out.println("enter the " + n + " numbers ");
		for (int i = 0; i < n; i++) {
			System.out.println("enter  number  " + (i + 1) + ":");
			a[i] = sc.nextInt();
		}
		s = A5SumRecursionArray.sumofnum(a, n - 1, s);
		System.out.println("sum is =" + s);
		System.out.println(findSum(a, a.length)); 
	}

	static int sumofnum(int a[], int n, int s1) {
		if (n < 0) {
			return s1;
		}
		else {
			s1 += a[n];

			return A5SumRecursionArray.sumofnum(a, n - 1, s1);
		}
	}
	
	// Return sum of elements in A[0..N-1] 
	 // using recursion. 
	 static int findSum(int A[], int N) 
	 { 
	     if (N <= 0) {
	         return 0; 
	     }
	     return (findSum(A, N - 1) + A[N - 1]); 
	 } 

}

//https://www.geeksforgeeks.org/sum-array-elements-using-recursion/
