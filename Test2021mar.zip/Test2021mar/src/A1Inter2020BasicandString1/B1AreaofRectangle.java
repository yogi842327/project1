package A1Inter2020BasicandString1;

import java.util.Scanner;

public class B1AreaofRectangle {
	public static void main (String[] args)
	   {
		   Scanner scanner = new Scanner(System.in);
		   System.out.println("Enter the length of Rectangle:");
		   double length = scanner.nextDouble();
		   System.out.println("1 Enter the width of Rectangle:");
		   double width = scanner.nextDouble();
		   //Area = length*width;
		   double area = length*width;
		   System.out.println("Area of Rectangle is:"+area);
		   System.out.println("2 Enter Side of Square:");
		   double side = scanner.nextDouble();
	       //Area of Square = side*side
	       double areas = side*side; 
	       System.out.println("Area of Square is: "+areas);
	       System.out.println("3 Enter the width of the Triangle:");
	       double base = scanner.nextDouble();
	       System.out.println(" 3 Enter the height of the Triangle:");
	       double height = scanner.nextDouble();

	       //Area = (width*height)/2
	       double areat = (base* height)/2;
	       System.out.println("Area of Triangle is: " + area); 
	       
	      
	       
	        Scanner sc1 = new Scanner(System.in);
	        System.out.println("4 Enter the radius: ");
	       double radiusc = sc1.nextDouble();
	       //Area = PI*radius*radius
	       double areac = Math.PI * (radiusc * radiusc);
	       System.out.println("The area of circle is: " + areac);
	       //Circumference = 2*PI*radius
	       double circumference= Math.PI * 2*radiusc;
	       System.out.println( "The circumference of the circle is:"+circumference) ;
	   }
}
