package A1Inter2020BasicandString1;



import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.io.IOException;

class A1Readconsole {
	public static void main(String args[]) throws IOException {
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		/*
		 * InputStreamReader r=new InputStreamReader(System.in); BufferedReader br=new
		 * BufferedReader(r);
		 */
		System.out.println("Enter your name");
		String Input = br.readLine();
		System.out.println("Welcome " + Input);
		int size = Integer.parseInt(Input); // can not parse string name

		Scanner sc = new Scanner(System.in);
		System.out.println(" Please enter value for Integer ");
		int num = sc.nextInt();
		Scanner sc1 = new Scanner(System.in);
		System.out.println(" Please enter value for String ");
		
		String name = sc.next();
		System.out.println("string value " + name);
		System.out.println(" size " + size + " num " + num);

		int[] saraay = new int[size];
		int[] sarray2 = new int[num];
	// File Read
		FileReader fr=new FileReader("E:\\temp.txt");    
        BufferedReader br1=new BufferedReader(fr);    

        int i;    
        while((i=br1.read())!=-1){  
        System.out.print("File"+(char)i);  
        }  
        br.close();    
        fr.close();    
  }    
	}
