package A1Inter2020BasicandString1;

public class A8CheckPositiveNegative {

	 public static void main(String[] args) 
	    {
	        int number=109;
	        if(number > 0)
	        {
	            System.out.println(number+" is a positive number");
	        }
	        else if(number < 0)
	        {
	            System.out.println(number+" is a negative number");
	        }
	        else
	        {
	            System.out.println(number+" is neither positive nor negative");
	        }
	    }
}
