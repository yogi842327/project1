package A1Inter2020BasicandString1;

import java.util.Random;

public class A9GenerateRandomNumber {
	 public static void main(String[] args) {
	      int counter;
	      Random rnum = new Random();
	      /* Below code would generate 5 random numbers
	       * between 0 and 200.
	       */
	      int max=1900;
	      int min= 1100;
	   //  int val= rnum.nextInt((max-min)+1+min);
	   //   int val= rnum.nextInt();
	      int val= rnum.nextInt((max-min)+1)+min;
	      System.out.println("Random Number:"+val);
	      System.out.println("Random Numbers:");
	      System.out.println("***************");
	      for (counter = 1; counter <= 5; counter++) {
	         System.out.println(rnum.nextInt(200));
	      }
	   }
}
