package A1Inter2020BasicandString1;

public class B5FactorialwithRecursion {
	static int fact=1;
	//static int n1=0,n2=1,n3=2;
	public static void main (String[] args)
	{
		int num=5;
	//	System.out.print(" "+n1+" "+n2);
		 fact=B5FactorialwithRecursion.factorial(num);
		System.out.print("fact value is  "+fact);
	}

	static int factorial(int num) {
		
		if(num<=0) {
			return 1;
		}else {
			return fact=num*factorial(num-1);
		//	return fact=factorial(num-1)*num;
		
			}
		}
		
	}
	


