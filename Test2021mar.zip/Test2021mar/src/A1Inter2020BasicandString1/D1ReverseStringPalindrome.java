package A1Inter2020BasicandString1;

import java.util.*;
import java.io.*;

public class D1ReverseStringPalindrome {
	public static void main(String[] args) {

		System.out.println("First Palindrome reverse string other string work ");
		String reverse = "";
		String str = "saas";
		char[] ch = str.toCharArray();
		for (int i = ch.length-1; i >= 0; i--) {
			reverse = reverse+ (ch[i] + "");
		}
			System.out.println("Reverse String is: "+reverse);

			if(reverse.equals(str)) {
				System.out.println("First Is palindrome");
				
			}else {
				System.out.println("First Is not palindrome");
			}
			
			//2nd
			
		String strinput = "";
		char charinput = 0;
		try {
			System.out.println(" Second Enter value for reverse ");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			strinput = br.readLine();
			char[] stringarray = strinput.toCharArray();
			System.out.println(" Second ");
			for (int i = stringarray.length - 1; i >= 0; i--) {

				System.out.println("val s "+stringarray[i]);
			}
			//3rd
			StringBuilder sb = new StringBuilder();
			sb.append(strinput);
			sb.reverse();
			System.out.println("Third  ");
			System.out.println("sb reverse "+sb);
			//4th
			System.out.println(" Fourth Second sb to in string ");
			for (int i = 0; i <= sb.length() - 1; i++) {
				charinput = sb.charAt(i);
				System.out.println(" String Buffer " + sb.charAt(i));

			}

			System.out.println(" char " + charinput);
			//5th
			System.out.println(" fifth string to array ");
			char[] temparray = strinput.toCharArray();
			// String temparray1= strinput.toString();
			int left, right = 0;
			right = temparray.length - 1;
			//6th
			System.out.println(" Sixth Swap array value ");
			char temp = temparray[0];
			temparray[0] = temparray[right];
			temparray[right] = temp;
			/*for (left = 0; left < right; left++, right--) {
				// Swap values of left and right
				char temp = temparray[left];
				temparray[left] = temparray[right];
				temparray[right] = temp;
			}*/

			for (char c : temparray) {
				System.out.print(c);
				System.out.println();
			}
			
			//7th
			System.out.println(" Seven ");
			byte[] byteArray = strinput.getBytes();
			byte[] result = new byte[strinput.length()];
			for (int i = 0; i < strinput.length(); i++) {
				// result[i] = byteArray[byteArray.length-i-1];
				// result[i]=(byte) ((byteArray[i]));
				result[i] = ((byteArray[byteArray.length - i - 1]));
				// result[i]= ((byteArray[i]));

			}
			System.out.println(" seven "+new String(result)); //array to string direct
			System.out.println(" eight string to array array to list ");
			char[] charr = strinput.toCharArray();
			ArrayList<Character> chal = new ArrayList<Character>();
			for (char cvalue : charr) {
				chal.add(cvalue);

			}
			Collections.reverse(chal);
			Iterator itr = chal.iterator();
			while (itr.hasNext()) {
				System.out.println(" Iterator " + itr.next());
			}
			//9
			// https://www.youtube.com/watch?v=SrZvSWO2C5A
			System.out.println(" Nine Recursive ");
			String inputs = "WXYZ";
			// create Method and pass input string as parameter
			String reversed = reverseString(inputs); //reverseString  recursion
			System.out.println("The reversed string is: " + reversed);

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	// Method take string parameter and check string is empty or not
	public static String reverseString(String input) {
		if (input.isEmpty()) {
			return input;
		}
		// Calling Function Recursively
		return reverseString(input.substring(1)) + input.charAt(0);
	}

}
