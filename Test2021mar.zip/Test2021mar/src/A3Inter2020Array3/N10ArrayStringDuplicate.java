package A3Inter2020Array3;

import java.util.Arrays;

public class N10ArrayStringDuplicate {
	public static void main(String[] args) {

		String input = new String("abbc");
		String output = new String();
		String output1 = new String();
		System.out.println("Hi ");

		String stringWithDuplicates = "abtyabcf";
		char[] characters = stringWithDuplicates.toCharArray();
		int length = characters.length;
		boolean unique = false;
		int i = 0;
		int j = 0;
		System.out.println("String with duplicates : " + stringWithDuplicates);
		for (i = 0; i < length; i++) {
			for (j = i + 1; j < length; j++) {
				if (characters[i] == characters[j]) {
					int temp = j;// set duplicate element index

					// delete the duplicate element by shifting the elements to left
					for (int k = temp; k < length - 1; k++) {
						characters[k] = characters[k + 1];
						// output1=output1+characters[k];
					}
					j--;
					length--;// reduce char array length

				}
			}

		}
		
		String stringWithOutDuplicates = new String(characters);
		System.out.println("String after duplicates removed1 its showing garbage data too so use"
				+ "substring : " + stringWithOutDuplicates);
		stringWithOutDuplicates = stringWithOutDuplicates.substring(0, length);
		System.out.println("String after duplicates removed : " + stringWithOutDuplicates);
		String testString = Arrays.toString(characters);
		System.out.println("Removed duplicates with garbage  " + testString);

		
		//First non repeated
		for (i = 0; i < length; i++) {
			unique = false;
			// int val = 0;
			for (j = 0; j < length; j++) {
				if (i != j && stringWithDuplicates.charAt(i) == stringWithDuplicates.charAt(j)) {
					// output1 = output1 + stringWithDuplicates.charAt(i);
					unique = true;
					// System.out.println(s.charAt(i)+"val "+val++);
					break;
				}
			}
		}
		if (unique) {
			System.out.println("2nd First non repeated characted in String \"" + stringWithDuplicates + "\" is:"
					+ stringWithDuplicates.charAt(i));

		}

		// For find first duplicate
		// 2nd approach

		char ch = 0;
		unique = true;
		for (i = 0; i < stringWithDuplicates.length(); i++) {
					//	int val = 0;
			if (ch != 0) {
				break;
			}
			for (j = 0; j < stringWithDuplicates.length(); j++) {
				if (i != j && stringWithDuplicates.charAt(i) == stringWithDuplicates.charAt(j)) {
					unique = false;
					ch = stringWithDuplicates.charAt(i);
					System.out.println("first repeated  " + stringWithDuplicates.charAt(i));
					break;
				}

			}
		}
	}

}
