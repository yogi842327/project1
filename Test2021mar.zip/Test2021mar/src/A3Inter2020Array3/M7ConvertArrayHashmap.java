package A3Inter2020Array3;

/*https://www.programiz.com/java-programming/examples/convert-list-array
*/
import java.util.*;
import java.util.stream.Collectors;

public class M7ConvertArrayHashmap {

	public static void main(String[] args) {
		//java 8 array to list
		System.out.println("Last Java8 array to list"+convertUsingJavaStream(new String[] {"CITI","HSBC","SBI"}));

		String str = "Hellows";
		String[] array = { "a", "b", "c" };
		List<String> list = new ArrayList<String>();
		list.add("a");
		list.add("b");
		list.add("b");
		System.out.println("list is"+list);
		Set<String> set = new HashSet<>();
		set.add("a");
		set.add("b");
		
		HashMap<String, String> hMap = new HashMap<String, String>();
		hMap.put("1", "One");
		hMap.put("2", "Two");

		Hashtable<String, String> ht = new Hashtable<String, String>();
		ht.put("1", "REPLACED !!");
		ht.put("4", "Four");

		System.out.println("Convert Strint to Array char[] stringToCharArray = str.toCharArray();");
		char[] stringToCharArray = str.toCharArray();

		// str. charAt(i)
		for (char output : stringToCharArray) {
			System.out.println(output);
		}

		String output2 = String.valueOf(stringToCharArray);
		System.out.println("Convert Array to String a6 " + output2);

		System.out.println("Convert Array to list:Arrays.asList(array1) ");
		String[] array1 = { "a", "b" };

		list = Arrays.asList(array1);
		System.out.println(list);
		System.out.println("Convert List to Array: list.toArray(array1)");
		array1 = new String[list.size()];
		array1 = list.toArray(array1);
		System.out.println(Arrays.toString(array1));

		System.out.println("Convert Array to Set new HashSet<String>(list); : first array to list then list to set");
		// Creating a hash set using constructor
		set = new HashSet<String>(list);
		System.out.println(set);

		System.out.println("Convert Set to Array");
		array1 = new String[set.size()];
		array1 = set.toArray(array1);
		System.out.println(Arrays.toString(array1));

		System.out.println("Remove Dupl,icates from Arraylist Duplicate :");
		System.out.println("Convert ArrayList to Set new HashSet<String>(list) : first array to list then list to set:");
		// Creating a hash set using constructor
		set = new HashSet<String>(list);
		System.out.println(set);

		System.out.println("Convert Set to ArrayList: new ArrayList<String>(set) ");
		array1 = new String[set.size()];
		list = new ArrayList<String>(set);
		System.out.println(list);
		
		System.out.println("Convert hashmap to hashtable:ht.putAll(hMap) ");
		    // void putAll(Map m) copies Map entries to Hashtable replacing existing mapping of keys
		    ht.putAll(hMap);
		  		System.out.println(ht);

		System.out.println("Convert hashtable to Hashmap: hMap.putAll(ht)");
		hMap.putAll(ht);
		System.out.println(hMap);
		
		
		}
	//java 8
	
			public static List<Object> convertUsingJavaStream(Object arr[]) {

				List<Object> list12 = Arrays.stream(arr).collect(Collectors.toList());
				return list12;

	}

}
