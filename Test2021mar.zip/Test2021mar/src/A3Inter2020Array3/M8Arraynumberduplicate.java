package A3Inter2020Array3;

import java.util.Arrays;


public class M8Arraynumberduplicate {
	public static void main(String[] args) {
		int [] arr=new int[]{4,6,4,8,1,9};
		int len=arr.length;
		int temps=0;
	//	Arrays.sort(arr);
		for(int i=0;i<arr.length-1;i++) {
			for(int j=0;j<arr.length-1;j++) {
				if(arr[j] >arr[j+1]) {
					int temp=arr[j+1];
						arr[j+1]=arr[j];
						arr[j]=temp;
					}
					
				
			}
			
		}
		System.out.println("Sorted data : ");
		for(int k=0;k<arr.length;k++) {
			System.out.println(arr[k]);
			
		}
	
		//not imp 2nd p
			for(int j=0;j<arr.length-1;j++) {
				if(arr[j] ==arr[j+1]) {
					 temps =j;
					 for(int x=temps;x<arr.length-1;x++) {
							arr[temps]=arr[temps+1];
							System.out.println("temps "+arr[temps]+"arr[=1]"+arr[temps+1]);
						}
					 len--;
					}
					
				
				
			
		}
		System.out.println("remove dupli data : ");
		for(int k=0;k<arr.length;k++) {
			System.out.println(arr[k]);
			
		}
	}

}
