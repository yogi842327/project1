package A3Inter2020Array3;

import java.util.*;
//https://www.geeksforgeeks.org/array-declarations-java-single-multidimensional/

/**
 * An array is a sequential collection of elements of same data type and stores data elements
 *  in a continuous memory location. The elements of an
 *  array are accessed by using an index. The index of an array of size N can range from  to .
 * 
 * Created by IntelliJ IDEA. User: Yogesh_Bundela Date: Aug 17, 2018 Time:
 * 10:43:03 AM To change this template use File | Settings | File Templates.
 * Note: for invalid search 
 * #in Note :When we are declaring multiple variable of
 * same time at a time, we have to write variable first then declare that
 * variable except first variable declaration. There is no restriction for the
 * first variable.
 *
 */

//Declaration is not to declare "value" to a variable; it's to declare the type of the variable.
//Assignment is simply the storing of a value to a variable. Initialization is the assignment of a value to a 
//variable at the time of declaration.

public class M1Array1declare1 {

	public static void main(String args[]) {
		int[] a; // valid declaration
		int b[]; // valid declaration

//invalid declaration -- If we want to assign
		// size of array at the declaration time, it
		// gives compile time error. : error: illegal start of expression
		// int aa[5]; //invalid #in

		// 2nd part
		// valid declaration, both arrays are
		// one dimensional array.
		int aa1[], bb1[];

		// invalid declaration
		// int c1[], [] d1;

		// invalid declaration
		// int[] e, [] f;

		// part 3
		// Now, when we are creating array it is mandatory to pass the size of array;
		// otherwise we will get compile time error.: error: array dimension missing
		// valid, here creating 'b' array of size 5
		int[] b2 = new int[5];

		// valid
		int[] c2 = new int[0];

		// invalid, here size of array is not given : error: array dimension missing
		// int[] a11 = new int[]; ////invalid #in

		// gives runtime error : Exception in thread "main"
		// java.lang.NegativeArraySizeException
		// int[] d = new int[-1]; ////invalid #in

		// party 4
		// to create two dimensional array.
		int a13[][]; // valid
		int[][] b13; // valid
		int[][] c13; // valid
		int[] d13[]; // valid
		int[][] e13; // valid
		int[] ff[]; // valid
		// [][] int g13; // invalid #in
		// [] int[] h13; // invalid #in

		// part 5
		// all valid
		// Here, 'a' is two dimensional array, 'b'
		// is two dimensional array
		int[] aq[], bq[];

		// Here, 'c' is two dimensional array, 'd'
		// is two dimensional array
		int[] cw[], dw[];

		// Here, 'e' is two dimensional array, 'f'
		// is three dimensional array
		int[][] e, f[];

		// Here, 'g' is two dimensional array,
		// 'h' is one dimensional array
		int[] g[], h;

		// Part 6

		// both are valid declarations
		int intArray[];
		int[] intArray1;
		byte byteArray[];
		short shortsArray[];
		boolean booleanArray[];
		long longArray[];
		float floatArray[];
		double doubleArray[];
		char charArray[];
//an array of references to objects of the class MyClass (a class created by user)
		M1Array1declare1 myClassArray[]; // Array1declare myClassArray[];
		Object[] ao; // array of Object
		Collection[] ca; // array of Collection of unknown type

		System.out.println("Array program one for declarations ");
		System.out.println("Valid and invalid declarations ");
	}
}
