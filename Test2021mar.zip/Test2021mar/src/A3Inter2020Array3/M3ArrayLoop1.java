package A3Inter2020Array3;

import java.util.*;

// Direct Array not give ConcurrentModificationException and not support for iterator and Enumuration 
//support Advance/for eachloop/simple for,While for traverse array data through length
public class M3ArrayLoop1 {
	public static void main(String[] args) {

		int[] arr = { 1, 2, 3 };
		int count = 4;
		int sum = 0;
		double avg = 0;
		int len = 0;
		int[] array = new int[count];
		len = array.length;

		/* For Loop for iterating ARRAy ArrayList */
		System.out.println("For Loop");
		for (int j = 0; j < len; j++) {
			array[j] = j + 1;
			sum += array[j];

		}
		System.out.println("Sum and avg is " + sum + " " + avg);

		/* For Loop for iterating ArrayList */
		System.out.println("For Loop");
		for (int counter = 0; counter < arr.length; counter++) {
			System.out.println(arr[counter]);
			// arr[1] = 1; //no exceptions
		}

		/* While Loop for iterating ArrayList */
		System.out.println("While Loop");
		int counts = 0;
		// for (int counter = 0; counter < arr.length; counter++) {
		while (arr.length < len) {
			array[counts] = counts + 1;
			System.out.println(arr[counts]);
			counts++;
			arr[1] = 1; // no exceptions
		}
		// 1

		/* Advanced For Loop */
		System.out.println("Advanced For Loop");
		for (Integer num : arr) {
			System.out.println(num);
			arr[1] = 1; // no exceptions
		}
		// 2
		/* Looping Array List using Iterator */
		// array not support Enumeration,iterator,listiterator
		System.out
				.println("Iterator: array not support Enumeration,iterator,listiterator "
						+ "but array can put in vector and list for use this ");
		// Create Iterator
		/*
		 * Iterator iter = arr.length.iterator(); //arr.size support but
		 * iterator read lenth while (iter.hasNext()) {
		 * System.out.println(iter.next()); // arr.add(66);
		 * //java.util.ConcurrentModificationException }
		 * 
		 * //Create Enumeration Enumeration<Integer> en =
		 * Collections.enumeration(arr);
		 * System.out.println("The Enumeration List are: "); while
		 * (en.hasMoreElements()) { System.out.println(en.nextElement()); }
		 */
		// 3
		// Array to vector and enumuration
		String[] stringsarray = { "Here", "Are", "Some", "Strings" };
		Vector<String> vectorarray = new Vector<String>(
				Arrays.asList(stringsarray));
		// Enumeration<Integer> ena = Collections.enumeration(arraylist); //for
		// list
		Enumeration enva = vectorarray.elements();
		System.out.println("The Enumeration List are: ");
		while (enva.hasMoreElements()) {
			System.out.println(enva.nextElement());
		}

		// 4
		// Array to linkedlist and listiterator
		// char arrayforll[]= new char[] {'1','w','e',3};
		// String arrstr[] = new char[] { "a","b","c"};
		String[] stringsarray1 = { "fff", "hhh", "111", "444" };
		// convert array to LinkedList
		// LinkedList ll = new LinkedList(Arrays.asList(sa));
		LinkedList ll1 = new LinkedList(Arrays.asList(stringsarray1));
		// Displaying the linkedlist
		System.out.println("LinkedList:" + ll1);
		ListIterator lt = ll1.listIterator();
		while (lt.hasNext()) {
			System.out.println(lt.next() + " List array");
			// ll1.add(33); ////java.util.ConcurrentModificationException
		}

		// 5
		// Array to Set/Treeset
		Integer[] nums = { 7, 34, 45, 23, 38, 56, 21 };
		/*
		 * First we convert an Array to List using Arrays.asList(), then pass
		 * the list as an argument to the constructor of TreeSet
		 */
		List<Integer> list = Arrays.asList(nums);
		Set<Integer> set = new TreeSet<Integer>(list);
		System.out.println("The iterator treeset  values are: " + set);
		// Iterable itset=(Iterable) set.iterator();
		Iterator itset = set.iterator();
		while (itset.hasNext()) {
			System.out.println(" Tree set " + itset.next());
		}

		// 6
		// List to Array
		// String [] countries = list.toArray(new String[list.size()]);

		// Set to Array
		// Object[] objArray = treeSet.toArray();

		// Array to map
		// can work for hashset: new HashSet(Arrays.asList(array)) but
		// can not work for hashtable and hm cause key and value
		// can work via api: import org.apache.commons.lang3.ArrayUtils;
		// String[][] arrayItems = {{"key0", "Item0"},
		// Map mapItems = ArrayUtils.toMap(arrayItems);

		// 7
		// list iterator worked with vector arraylist ll but not with Array
		// Stack? cut paste line 34
		// Array to arraylist and listiterator
		// char arrayforll[]= new char[] {'1','w','e',3};
		// String arrstr[] = new char[] { "a","b","c"};
		String[] stringsarray1l = { "fff", "hhh", "111", "444" };
		// convert array to LinkedList
		// LinkedList ll = new LinkedList(Arrays.asList(sa));
		ArrayList ll1l = new ArrayList(Arrays.asList(stringsarray1l));
		// Displaying the linkedlist
		System.out.println("LinkedList:" + ll1l);
		ListIterator lt1 = ll1l.listIterator();
		while (lt1.hasNext()) {
			System.out.println(lt1.next()
					+ " List array arraylist in list iterator");
			// ll1.add(33); ////java.util.ConcurrentModificationException
		}

	}
}