package A3Inter2020Array3;

import java.util.Scanner;

//user input and nth no sum throug array
public class N12CreateUserInputArray5 {
	public static void main(String arg[]) {

		Scanner sc = new Scanner(System.in);
		
		System.out.println("Please Enter no of array");
		int noofarray = sc.nextInt();
		int sum=0;
		int sum1=0;
		int[] arr = new int[noofarray];
		
		// 0 to nth no of array
		System.out.println("0 to nth array input");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = i + 1;
			sum=sum+arr[i];

		}
		System.out.println("Sum is "+sum);
		// user input array
		//System.out.println("Sum is "+sum);
		System.out.println("No of inputs ");
		int userinput=sc.nextInt();
		int[] userinputarr = new int[userinput];
		for (int i = 0; i < userinput; i++) {
			System.out.println("please enter the values of "+(i+1));
			
			arr[i] = sc.nextInt();
					sum1=sum1+arr[i];

				}
		System.out.println("The sum of enter value "+sum1);
	}
}