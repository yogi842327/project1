package A3Inter2020Array3;

import java.util.Arrays;

/**
 * Created by IntelliJ IDEA. User: Yogesh_Bundela Date: Aug 17, 2018 Time:
 * 11:44:49 AM To change this template use File | Settings | File Templates.
 *
 * Note : When you create an object, you are creating an instance of a class,
 * therefore "instantiating" a class. The new operator requires a single,
 * postfix argument: a call to a constructor. The name of the constructor
 * provides the name of the class to instantiate Initializing an array in java �
 * object type
 */
public class M2Array2creatingobject2 {
	public static void main(String args[]) {
		// part 1

		// initialize Object one dimensional array
		String[] strArr1; // declaration

		strArr1 = new String[4]; // initialization

		// part 2

		// can create or intiate object two types
		// first via new
		int[] arr2 = new int[5];

		int arr1[] = new int[5];

		/*
		 * In following declarations, the size of array will be decided by the compiler
		 * and will be equal to the number of elements supplied for initialization of
		 * the array
		 */

		// � Second: Directly initializing the contents of that array
		int arr22[] = new int[] { 1, 2, 3, 4, 5 };
		char arrchar[] = new char[] { '1', '2', '3', 4, 5 };
		int[] arr33 = { 1, 2, 3, 4, 5 };

		int arr44[] = { 1, 2, 3, 4, 5 };
		System.out.println("Array program two 2 for object creations ");

// Simple String in array
		String[] fruitArray = { "Apple", "Banana", "Orange", "Grapes" };

		System.out.println(" String array"+fruitArray);
		// This will output null to the screen as the original String Array is lost and
		// replaced with a new array

		String[] myArray = new String[10];
		myArray[0] = "Hello";
		myArray = new String[20]; // again 10 to 20 may loose data
		System.out.println(myArray[0]);// may loose tha data : null
		
		
		// compare array
		 int arrs[] = {1, 2, 3}; 
	     int arrs2[] = {1, 2, 3}; 
	     if (Arrays.equals(arrs, arrs2)) 
	         System.out.println("Same"); 
	     else
	         System.out.println("Not same"); 
	 } 


	}
