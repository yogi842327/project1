package A3Inter2020Array3;

/*Array methods: toString for 1 dimension array copy
deepToString 2 dimenstion
(Arrays.asList(stringsarray)  : Arrayto others
		treeSet.toArray  : Others to Array
		ArrayUtils.toMap  : Array to  map but no method for map to array
		
		// Direct Array not give ConcurrentModificationException and not support for iterator and Enumuration 
//support Advance/for eachloop/simple for,While for traverse array data through length
*/
import java.util.Arrays;
public class M4ArrayLoop3{
public static void main(String[] args){
int count=4;
int sum=0;
double avg=0;
int len=0;
int[] array=new int[count];
len=array.length;
for (int j=0;j<len;j++){
  array[j]=j+1;
  sum+=array[j];
  
  }
  avg=(float)sum/len;
System.out.println(" Sum is "+sum+" Average is  "+avg);
// int[] array={1,2,3};
int[][] multiarray = {{1, 2}, {3, 4}, {5, 6, 7}};
 System.out.println("  a1st multi array: "+Arrays.deepToString(multiarray)+"  2nd array: ");
for(int copy: array)    {
  
System.out.println(" "+ copy);

    } 
      System.out.println("  a3rd array: "+Arrays.toString(array)+" 4th ");
      // System.out.println();
      for(int i=0;i<array.length;i++){
        
     System.out.println(array[i]);
  }
  
  

  }
  
  }
 