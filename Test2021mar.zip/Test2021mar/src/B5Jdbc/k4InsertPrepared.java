package B5Jdbc;

import java.sql.*;

public class k4InsertPrepared {

	public static void main(String args[]) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/testdb", "root", "PASSWORD");
			// 1insert
	
			PreparedStatement stmt = con.prepareStatement("insert into customers values(?,?,?,?,?,?) ");
			stmt.setString(1, "119");// 1 specifies the first parameter in the query
			stmt.setString(2, "Ratan");
			stmt.setString(3, "Gp road");
			stmt.setString(4, "Noida");
			stmt.setString(5, "UP");
			stmt.setString(6, "101201");

			int i = stmt.executeUpdate();
			System.out.println(i + " records inserted");

			// 2 Example of PreparedStatement interface that updates the record
			/*
			 * PreparedStatement stmt=con.
			 * prepareStatement("update customers set customer_name=? where customer_id=?");
			 * 
			 * stmt.setString(2,"111"); stmt.setString(1,"Sonoo"); //1 specifies the first
			 * parameter in the query i.e. name int i=stmt.executeUpdate();
			 * System.out.println(i+" records updated");
			 */
			// 2

			// 3 delete
			/*
			 * PreparedStatement
			 * stmt=con.prepareStatement("delete from customers where customer_id=?");
			 * stmt.setString(1,"111");
			 * 
			 * int i=stmt.executeUpdate(); System.out.println(i+" records deleted");
			 */
			//

			// 4 select
			/*
			 * PreparedStatement stmt=con.prepareStatement("select * from customers");
			 * ResultSet rs=stmt.executeQuery(); while(rs.next()){ rs.next(); String
			 * departmentId = rs.getString(3); String name = rs.getString(2);
			 * System.out.println("id : "+rs.getString(1)+" "+rs.getString(2)); }
			 */

			//

			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

	}
}
