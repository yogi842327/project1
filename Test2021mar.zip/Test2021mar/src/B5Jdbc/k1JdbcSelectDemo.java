package B5Jdbc;

import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



/**
 * A sample program that demonstrates how to execute SQL SELECT statement
 * using JDBC. 
 * @author www.codejava.net
 *
 */
public class k1JdbcSelectDemo {

	public static void main(String[] args) {
		String dbURL = "jdbc:mysql://localhost:3306/testdb";
		String username = "root";
		String password = "PASSWORD";
		Connection conn = null; // jre 7 connection remove and uncomment
	//	try (Connection conn = DriverManager.getConnection(dbURL, username, password))
		try
		{
			
			String sql = "INSERT INTO users (username, password, fullname, email) VALUES (?, ?, ?, ?)";
			
			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setString(1, "bill");
			statement.setString(2, "secretpass");
			statement.setString(3, "Bill Gates");
			statement.setString(4, "bill.gates@microsoft.com");
			
			int rowsInserted = statement.executeUpdate();
			if (rowsInserted > 0) {
				System.out.println("A new user was inserted successfully!");
			}

			
		} catch (SQLException ex) {
			ex.printStackTrace();
		}		
	}
}