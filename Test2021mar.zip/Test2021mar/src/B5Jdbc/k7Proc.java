package B5Jdbc;

import java.sql.*;

public class k7Proc {
	public static void main(String[] args) throws Exception {

		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/testdb", "root", "PASSWORD");

		CallableStatement stmt = con.prepareCall("{call insertR(?,?)}");
		stmt.setInt(1, 1011);
		stmt.setString(2, "Amit");
		stmt.execute();

		System.out.println("success");
	}
}