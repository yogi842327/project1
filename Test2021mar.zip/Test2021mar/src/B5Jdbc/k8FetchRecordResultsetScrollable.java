package B5Jdbc;

import java.sql.*;

public class k8FetchRecordResultsetScrollable {

	public static void main(String args[]) throws Exception {

		Class.forName("com.mysql.jdbc.Driver");
		// Connection con =
		// DriverManager.getConnection("jdbc:mysql://localhost:3306/testdb", "root",
		// "password");

		Connection con = null;

		if (con != null)
			return;

		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			throw new Exception("No database");
		}
		String connectionURL=	"jdbc:mysql://localhost:3306/testdb?autoReconnect=true&useSSL=false";
	//	String connectionURL = "jdbc:mysql://localhost:3306/testdb";

		con = DriverManager.getConnection(connectionURL, "root", "PASSWORD");
	//	Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("select * from employees");
		 rs.next();
		String departmentId = rs.getString(3);
		String name = rs.getString(2);
		// getting the record of 3rd row
		rs.absolute(3);
	//	System.out.println(rs.getString(1) + " " + rs.getString(2) + " " + rs.getString(3));
		System.out.println("Dep id : "+departmentId +"  name :"+ name+"      :Done");
		con.close();
	}
}
