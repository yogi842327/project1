package B5Jdbc;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.BufferUnderflowException;

/*
Driver Software:communicate with a particular Database
Driver: This Interface present in java.sql Package. 4 types thic and thin
DriverManager:establish connection between application and db present un java.sql*/

/*Connection: communicate with database:  DriverManager.getConnection(), always a new Connection object will be created
Connection Pool is a pool of already created Connection objects which are ready to use.
DataSource is responsible to manage connections in Connection Pool.of DataSourceObject.getConnection(), a new Connection object won't be created
*/
/*
Statment :Used to execute normal static SQL queries
Preparedstatement: Hence PreparedStatement represents pre compiled sql query save sql query cause MySQL did not cache results of prepared queries
use for same query multiple time and fast and prevent sql injections
callable statement : use for stored procedure */
/*Statemnt are 4 methods Execute: For both select and non-select queries and call procedures
ResultSet executeQuery(String sql): Select for traverse
int executeUpdate(String sql): (insert|delete|update)
int[] executeBatch()*/

/*trasaction : acid : con.setAutoCommit(false); con.commit(); con.rollback();
con.setAutoCommit(false); invoke once get con.commit
savepoint: group of operations wrt Savepoint can release with s.release().
*/
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import java.sql.CallableStatement;

import java.sql.PreparedStatement;
import java.sql.ResultSet;;

public class i1Insertfetch {
	public static void main(String args[]) throws Exception {
		// STEP 2: Register JDBC driver

		Class.forName("com.jdbc.mysql.Drive");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/testDb", "root", "PASSWORD");

		Statement stmt = con.createStatement();

		String sql = "Insert into Registration values(10,'qARA','singh',20)";
		stmt.executeUpdate(sql);
		int val = stmt.executeUpdate(sql);
		sql = "Insert into Users(id,username,password,fullname,email) values(?,?,?,?,?)";
		PreparedStatement pstmt = con.prepareStatement(sql);
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Please Enter the Username");
		String username = br.readLine();
		pstmt.setInt(1, 89);
		pstmt.setString(2, username);
		val = pstmt.executeUpdate(sql); // Insertpreparedspress.java
		CallableStatement cal = con.prepareCall("call insertuser11(?,?)");
		cal.setInt(1, 34);
		cal.setInt(2, 45);
		boolean b = cal.execute();

		String sql1 = "SELECT id, first, last, age FROM Registration";
		ResultSet rs = stmt.executeQuery(sql1);
		while (rs.next()) {
			// int id=rs.getInt(1)// can find through coulamn index to
			int id = rs.getInt("�d");
			String username1 = rs.getString("username");
			System.out.println("Id" + id);
			System.out.println("Name" + username);
		}
	}
}