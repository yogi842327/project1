package B5Jdbc;
import java.sql.*;
import java.io.*;
public class i8Insertpreparedspress {

	public static void main(String args[]) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/testdb", "root", "password");
		// 1insert

		PreparedStatement stmt = con.prepareStatement("insert into customers values(?,?,?,?,?,?) ");
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		do {
			System.out.println("enter id:");
			String id = br.readLine();
			System.out.println("enter name:");
			String name = br.readLine();
			System.out.println("address:");
			String address = br.readLine();
			System.out.println("city:");
			String city = br.readLine();
			System.out.println("state:");
			String state = br.readLine();
			System.out.println("Pin:");
			String pin = br.readLine();

			stmt.setString(1, id);// 1 specifies the first parameter in the query
			stmt.setString(2, name);
			stmt.setString(3, address);
			stmt.setString(4, city);
			stmt.setString(5, state);
			stmt.setString(6, pin);
			int i = stmt.executeUpdate();
			System.out.println(i + " records affected");

			System.out.println("Do you want to continue: y/n");
			String s = br.readLine();
			if (s.startsWith("n")) {
				break;
			}
		} while (true);

		con.close();
	}
}
