package B5Jdbc;

import java.io.*;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class k9RetrieveImage {
	public static void main(String[] args) throws Exception {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/testdb", "root", "PASSWORD");

			PreparedStatement ps = con.prepareStatement("insert into image values(?,?)");
			ResultSet rs = ps.executeQuery("select * from image");
		//	ResultSet rs = ps.executeUpdate();
			if (rs.next()) {// now on 1st row

				Blob b = rs.getBlob(2);// 2 means 2nd column data
				byte barr[] = b.getBytes(1, (int) b.length());// 1 means first image

				FileOutputStream fout = new FileOutputStream("D:\\22\\temp.txt");
				// FileInputStream fin = new FileInputStream("E:\\22\\Programs.7z");
				fout.write(barr);

				fout.close();
			} // end of if
			System.out.println("ok");

			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
