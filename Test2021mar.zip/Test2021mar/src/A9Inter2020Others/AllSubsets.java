package A9Inter2020Others;

import java.util.Arrays;

public class AllSubsets {  
    public static void main(String[] args) {  
  
        String str = "NIN";  
        int len = str.length();  
        int temp = 0;  
        //Total possible subsets for string of size n is n*(n+1)/2  
        String arr[] = new String[len*(len+1)/2];  
  
        //This loop maintains the starting character  
        for(int i = 0; i < len; i++) {  
            //This loop adds the next character every iteration for the subset to form and add it to the array  
            for(int j = i; j < len; j++) {  
                arr[temp] = str.substring(i, j+1);  
                temp++;  
            }  
        }  
        StringBuffer stringBuilder = new StringBuffer();
        StringBuffer stringBuilder1 = new StringBuffer();	
        //This loop prints all the subsets formed from the string.  
        System.out.println("All subsets for given string are: ");  
        for(int i = 0; i < arr.length; i++) {  
            System.out.println(arr[i]);
            Integer testString = Arrays.toString(arr[i]);
            stringBuilder.append(testString);
            stringBuilder1.append(testString);
         //   stringBuilder1.append(arr[i]);
            stringBuilder1.reverse();
            if(stringBuilder1==(stringBuilder)) {
            	System.out.println(stringBuilder1+" and "+stringBuilder+" �s anagram");
            	
            }else {
            	System.out.println(" no anagram");
            }
            
            
        }  
    }  
}  