package A9Inter2020Others;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.*;

import com.sun.tools.javac.util.List;

import java.util.Map.Entry;
import java.util.concurrent.*;

public class Iteratorsworkedfailsafe {
	public static void main(String[] args) {

		HashMap<String, String> hm = new HashMap<>();

		hm.put("Cricket", "Sachin");
		hm.put("Football", "Zidane");
		hm.put("Tennis", "Federer");

		Iterator<Map.Entry<String, String>> entrySet = hm.entrySet().iterator();

		while (entrySet.hasNext()) {
			Map.Entry<String, String> entry = entrySet.next();

			System.out.println("Key : " + entry.getKey() + "   Value : " + entry.getValue());
		}
		System.out.println("Hashtable ");
		Hashtable<Integer, Integer> ht = new Hashtable();
		ht.put(1, 1);
		ht.put(2, 22);
		ht.put(3, 33);
		ht.put(4, 44);

		Iterator it = ht.keySet().iterator();
		while (it.hasNext()) {
			int value = (int) it.next();
			if (value == 3) {
		//		ht.put(5, 555); // throws ConcurrentModificationException
			}

		}
		ArrayList<String> myList = new ArrayList<String>();

		myList.add("1");
		myList.add("2");
		myList.add("3");
		myList.add("4");
		myList.add("5");

		Iterator<String> it4 = myList.iterator();
		while (it.hasNext()) {
			String value = it4.next();
			System.out.println("List Value:" + value);
			if (value.equals("3"))
				myList.remove(value);
		}

		Map<String, String> myMap = new HashMap<String, String>();
		myMap.put("1", "1");
		myMap.put("2", "2");
		myMap.put("3", "3");

		Iterator<String> it1 = myMap.keySet().iterator();
		while (it1.hasNext()) {
			String key = it1.next();
			System.out.println("Map Value:" + myMap.get(key));
			if (key.equals("2")) {
				myMap.put("1", "4");
			//	 myMap.put("4", "4");
			}
		}
		System.out.println("Concurrent");
//concurrent
ArrayList<String> myListt = new ArrayList<String>();
//CopyOnWriteArrayList<String> myListt = new CopyOnWriteArrayList<String>();

myListt.add("1");
myListt.add("2");
myListt.add("3");
myListt.add("4");
myListt.add("5");

Iterator<String> ittt = myListt.iterator();
while (ittt.hasNext()) {
	String value = ittt.next();
	System.out.println("List Value:" + value);
	if (value.equals("3")) {
		myListt.remove("4"); //java.util.ConcurrentModificationException with al
		myListt.add("6");//java.util.ConcurrentModificationException with al
		myListt.add("7");//java.util.ConcurrentModificationException with al
	}
}
System.out.println("List Size:" + myList.size());
Map<String, String> myMap1 = new HashMap<String, String>();
//Map<String, String> myMap1 = new ConcurrentHashMap<String, String>();
myMap1.put("1", "1"); 
myMap1.put("2", "2");
myMap1.put("3", "3");

Iterator<String> itw = myMap1.keySet().iterator();
while (itw.hasNext()) {
	String key = itw.next();
	System.out.println("Map Value:" + myMap1.get(key));
	if (key.equals("1")) {
		myMap1.remove("3"); // java.util.ConcurrentModificationException with HM
		myMap1.put("4", "4");//// java.util.ConcurrentModificationException with HM
		myMap1.put("5", "5");// java.util.ConcurrentModificationException with HM
	}
}

System.out.println("Map Size:" + myMap.size());

	}
}
