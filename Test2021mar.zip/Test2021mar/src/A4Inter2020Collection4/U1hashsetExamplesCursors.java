package A4Inter2020Collection4;

import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

public class U1hashsetExamplesCursors {

	public static void main(String[] args) {

//		CopyOnWriteArrayList<String> list = new CopyOnWriteArrayList<String>();// Creating arraylist
//ArrayList<String> list=new ArrayList<String>();//Creating arraylist  
HashSet<String> list=new HashSet<String>();  //cfreating hashset
		list.add("Ravi"); // Adding object in arraylist
		list.add("Vijay");
		list.add("Ravi");
		list.add("Ajay");

		System.out.println("Traversing list through List Iterator:");
//Here, element iterates in reverse order  
	/*	ListIterator<String> list1 = list.listIterator(list.size());
		while (list1.hasPrevious()) {
			String str = list1.previous();
			System.out.println(str);
			list.remove("Ravi"); //java.util.ConcurrentModificationException with al
			list.add("6");//java.util.ConcurrentModificationException with al
		}
		System.out.println("Traversing list through for loop:");
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i));
		}*/
//Traversing list through for-each loop
		System.out.println("Traversing list through for each loop:");
		for (String alstr : list) {
			System.out.println(alstr);
		}

		System.out.println("Traversing list through while for loop:");
//Traversing list through Iterator  
		Iterator itrs = list.iterator();
		while (itrs.hasNext()) {
			System.out.println(itrs.next());
		}

		System.out.println("Traversing list through java 8 forEach() method:");
//The forEach() method is a new feature, introduced in Java 8.  
		list.forEach(a -> { // Here, we are using lambda expression
			System.out.println(a);
		});

		System.out.println("Traversing list through forEachRemaining() method:");
		Iterator<String> itr = list.iterator();
		itr.forEachRemaining(a -> // Here, we are using lambda expression
		{
			System.out.println(a);
		});
	}
}