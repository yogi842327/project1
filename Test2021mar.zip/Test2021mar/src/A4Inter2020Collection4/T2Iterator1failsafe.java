package A4Inter2020Collection4;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
public class T2Iterator1failsafe {


public static void main(String[] args) {
	CopyOnWriteArrayList<String> aList = new CopyOnWriteArrayList<String>();//
	
	//ArrayList<String> aList = new CopyOnWriteArrayList<String>();
    aList.add("Apple");
    aList.add("Mango");
    aList.add("Guava");
    aList.add("Orange");
    aList.add("Peach");
    System.out.println("The ArrayList elements are: ");
    for (String s: aList) {
       System.out.println(s);
       aList.remove(0);
       aList.add("added");
    }
    Iterator i = aList.iterator();
    String str = "";
    while (i.hasNext()) {
       str = (String) i.next();
       if (str.equals("Orange")) {
          i.remove();
          aList.remove(1);
          aList.add("added");
          System.out.println("\nThe element Orange is removed");
          break;
       }
    }
    System.out.println("\nThe ArrayList elements are: ");
    for (String s: aList) {
       System.out.println(s); 
    }
 }
}
