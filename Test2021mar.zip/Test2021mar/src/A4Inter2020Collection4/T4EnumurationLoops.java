package A4Inter2020Collection4;

// Legacy classes: cursor:enumuration and DictionaryHashTable,Properties,Stack,Vector

import java.util.*;
import java.util.Map.Entry;

public class T4EnumurationLoops{
	
	 public static void main(String[] args) {   

		 System.out.print(" Enumuration is fail safe ");
					//vector 
			System.out.print(" Vectors ");
           List<String> Vec = new Vector<String>();         
            Vec.add("JAVA");  
            Vec.add("JSP");  
            Vec.add("SERVLET");  
            
            //Create Enumeration  
            Enumeration<String> en = Collections.enumeration(Vec);  
            System.out.println("The Enumeration List are: ");  
            while(en.hasMoreElements()){  
                 System.out.println(en.nextElement());  
            } 
            
            System.out.print(" Stack ");
            
	             //stack with enumuration
		      	Stack stc = new Stack();
		      	stc.push(11);
		      	stc.push(22);

					Enumeration e1 = stc.elements();

					while(e1.hasMoreElements())
					System.out.print(e1.nextElement()+" ");

					stc.pop();
					stc.pop();

					System.out.println("\nAfter popping out two elements");

					Enumeration e2 = stc.elements();

					while(e2.hasMoreElements()){
					System.out.print(e2.nextElement()+" ");

					}
					 /* System.out.println(" Hashmap Enumuration not worked ");
				        HashMap< String,Integer> hm1 = new HashMap< String,Integer>();
						  hm1.put("a",new Integer(100));
						  hm1.put("b",new Integer(200));
						  Enumeration<String> keys1 = (Enumeration<String>) hm1.keySet();
					        while(keys1.hasMoreElements()){
					            String key = keys1.nextElement();
					            System.out.println("Value of "+key+" is: "+hm1.get(key));
					        }*/
					 System.out.println(" Hashtable Enumuration ");
					  Hashtable<String, String> ht1 = new Hashtable<String, String>();
				        //add key-value pair to Hashtable
				        ht1.put("first", "FIRST INSERTED");
				        ht1.put("second", "SECOND INSERTED");
				        ht1.put("third","THIRD INSERTED");
				        Enumeration<String> keys = ht1.keys();
				        while(keys.hasMoreElements()){
				            String key = keys.nextElement();
				            System.out.println("Value of "+key+" is: "+ht1.get(key));
				        }
				      
					        
					 System.out.println(" Iterator Hashmap not legace not worked with enumurations ");
					 HashMap< String,Integer> hm = new HashMap< String,Integer>();
					  hm.put("a",new Integer(100));
					  hm.put("b",new Integer(200));
					 
					   System.out.println(" Hashtable ");
					
					 Hashtable< String,Integer> ht = new Hashtable< String,Integer>();
					  ht.put("a",new Integer(100));
					  ht.put("b",new Integer(200));
					  ht.put("c",new Integer(300));
					  ht.put("d",new Integer(400));

					   Set st = ht.entrySet();
				//	  Set st = hm.entrySet();
					  Iterator itr=st.iterator();
					  while(itr.hasNext())
					  {
					   Map.Entry m=(Map.Entry)itr.next();
					   System.out.println(((Entry) itr).getKey()+" "+((Entry) itr).getValue());
					  }
					  		
						}       

					}