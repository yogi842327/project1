

	package A4Inter2020Collection4;

	import java.security.KeyStore.Entry;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

	public class U1HashMapExamplesCursors {

		public static void main(String[] args) {
			Map<String,String> gfg = new HashMap<String,String>(); 
		      
	        // enter name/url pair 
	        gfg.put("GFG", "geeksforgeeks.org"); 
	        gfg.put("Practice", "practice.geeksforgeeks.org"); 
	        gfg.put("Code", "code.geeksforgeeks.org"); 
	        gfg.put("Quiz", "quiz.geeksforgeeks.org"); 
	          
	        // using for-each loop for iteration over Map.entrySet() 
	        for (Map.Entry<String,String> entry : gfg.entrySet())  {
	            System.out.println("Key = " + entry.getKey() + 
	                             ", Value = " + entry.getValue());
	        if(entry.getKey().equals("1")){
	        	gfg.remove("3");} //concurrent m exc
	        
		}
	    //2nd
	        // using keySet() for iteration over keys 
	        for (String name : gfg.keySet())  
	            System.out.println("key: " + name); 
	          
	        // using values() for iteration over keys 
	        for (String url : gfg.values())  
	            System.out.println("value: " + url); 
	        
	        //3rd
	     // using iterators 
	        Iterator<Map.Entry<String, String>> itr = gfg.entrySet().iterator(); 
	          
	        while(itr.hasNext()) 
	        { 
	             Map.Entry<String, String> entry = itr.next(); 
	             System.out.println("Key = " + entry.getKey() +  
	                                 ", Value = " + entry.getValue()); 
	        } 
	        
	        //4th
	        
	     // forEach(action) method to iterate map 
	        gfg.forEach((k,v) -> System.out.println("Key = "
	                + k + ", Value = " + v)); 
	        
	        //5th
	     // looping over keys 
	        for (String name : gfg.keySet())  
	        { 
	            // search  for value 
	            String url = gfg.get(name); 
	            System.out.println("Key = " + name + ", Value = " + url); 
	            
	        }
	        
	        //6th enumuration
	        final Enumeration<String> e = Collections.enumeration(gfg.keySet());
	        while(e.hasMoreElements())
	         {      String key=e.nextElement();
	                String value = gfg.get( key );
	                System.out.println("key: " + key + ", value: " + value);
	         }
	        
	      //concurrent modification exception
	       //1
	        // using for-each loop for iteration over Map.entrySet() 
	      /*  for (Map.Entry<String,String> entry : gfg.entrySet())  {
	            System.out.println("Key = " + entry.getKey() + 
	                             ", Value = " + entry.getValue());
	        if(entry.getKey().equals("1")){
	        	gfg.remove("3");} //concurrent m exc
	        
		}*/
	        
	        
	        //2
	        System.out.println("Exception concurrent");
	        Iterator it = gfg.entrySet().iterator();
	        while (it.hasNext())
	        {
	        	 Object items = it.next();
	        	 gfg.remove(((java.util.Map.Entry<String, String>) items).getKey());
	        	
	        	//   Entry item = (Entry) it.next();
	         //  it.remove();
	        }
	        
	      
	        
		}
	}