package B9Threadsafeandimmutable;

/*
 * Demonstrate StringBuffer is thread safe
 */

public class StringBufferwiththreadsafe {

	StringBuilder strBuffer;
	    static volatile float sum = 0;
	 
	    public StringBufferwiththreadsafe() {
	        strBuffer = new StringBuilder();
	    }
	 
	//    @Override
	    public void run() {
	 
	        for (int i = 0; i < 50000; i++) {
	            addChar();
	        }
	    }
	 
	    public void addChar() {
	        /*
	         * Here appended 6 A and removed 5 A at each call to this method. Total
	         * 1 A at each call Expected Accurate Total StringBuffer length = loops
	         * in run method * 1 i.e. 50000 * 1 for one thread Here we have 2
	         * threads so = 100000
	         */
	        try {
	            strBuffer.append("A");
	            strBuffer.append("A");
	            strBuffer.append("A");
	            strBuffer.deleteCharAt(0);
	            strBuffer.append("A");
	            strBuffer.append("A");
	            strBuffer.append("A");
	            for (int i = 0; i < 4; i++) {
	                strBuffer.deleteCharAt(0);
	            }
	        } catch (ArrayIndexOutOfBoundsException e) {
	            System.out.println("A wasn't at index 0 " + e.getMessage());
	        }
	    }
	 
	    public static void main(String[] args) {
	 
	    	StringBufferwiththreadsafe strBuffrWthThrdDmobj1 = new StringBufferwiththreadsafe();
	 
	        Thread threadOne = new Thread( "Thread One");
	        Thread threadTwo = new Thread( "Thread Two");
	        threadOne.start();
	        threadTwo.start();
	 
	        try {
	            threadOne.join();
	            threadTwo.join();
	        } catch (InterruptedException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }
	        System.out.println("Final StringBuffer Length: " + strBuffrWthThrdDmobj1.strBuffer.length());
	    }
	}
