package B9Threadsafeandimmutable;

public class Mutablegettersetterex {


	private String name;

	Mutablegettersetterex(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	// this setter can modify the name
	public void setName(String name) {
		this.name = name;
	}

	public static void main(String[] args) {

		Mutablegettersetterex obj = new Mutablegettersetterex("mkyong");
		System.out.println(obj.getName());

		// update the name, this object is mutable
		obj.setName("new mkyong");
		System.out.println(obj.getName());

	}
}
