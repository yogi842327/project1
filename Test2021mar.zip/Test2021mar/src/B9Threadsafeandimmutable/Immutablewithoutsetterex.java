package B9Threadsafeandimmutable;

public class Immutablewithoutsetterex {

	private String name;

	Immutablewithoutsetterex (String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	//no setter
	
	public static void main(String[] args) {

		Immutablewithoutsetterex obj = new Immutablewithoutsetterex("mkyong");
		System.out.println(obj.getName());

		// there is no way to update the name after the object is created.
		// obj.setName("new mkyong");
		// System.out.println(obj.getName());

	}
}
