package A7ObjectStaticjava;

public class W2Final {

}
class At 
{
    final void m1() 
    {
        System.out.println("This is a final method.");
    }
}

class Bt extends At 
{
    void m1()
    { 
        // COMPILE-ERROR! Can't override.
        System.out.println("Illegal!");
    }
}