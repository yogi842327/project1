package A7ObjectStaticjava;

//https://www.geeksforgeeks.org/object-tostring-method-in-java/

import java.util.*; 
class V3tostring { 
    String name; 
    int age; 
    String college; 
    String course; 
    String address; 
    V3tostring 
    (String name, int age, String college, String course, String address) 
    { 
        this.name = name; 
        this.age = age; 
        this.college = college; 
        this.course = course; 
        this.address = address; 
    } 
   /* public String toString() 
    { 
        return name + " " + age + " " ; 
    }*/
public static void main(String[] args) 
    { 
	V3tostring b =  
        new V3tostring("Gulpreet Kaur", 21, "BIT MESRA", "M.TECH", "Kiriburu"); 
        System.out.println(b); 
        System.out.println(b.toString()); 
        String s = new String("Gulpreet Kaur 3"); 
        System.out.println(s); 
        String str = new String("Uncomment code"); 
        System.out.println(str); 
        Integer i = new Integer(21); 
        System.out.println(i); 
        ArrayList l = new ArrayList(); 
        l.add("BIT"); 
        l.add("M.TECH"); 
        System.out.println(l); 
    } 
} 
