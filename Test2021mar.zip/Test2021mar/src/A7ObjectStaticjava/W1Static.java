package A7ObjectStaticjava;

//https://www.javatpoint.com/static-keyword-in-java
//https://www.geeksforgeeks.org/static-keyword-java/
//Java Program to demonstrate the use of static variable  
//https://www.geeksforgeeks.org/static-methods-vs-instance-methods-java/
class Studenrt {
	int rollno;// instance variable
	String name;
	static String college = "ITS";// static variable
	// constructor

	Studenrt(int r, String n) {
		rollno = r;
		name = n;
	}

	// method to display the values
	void display() {
		System.out.println(rollno + " " + name + " " + college);
	}
}

//Test class to show the values of objects  
public class W1Static {
	public static void main(String args[]) {
		Studenrt s1 = new Studenrt(111, "Karan");
		Studenrt s2 = new Studenrt(222, "Aryan");
//we can change the college of all objects by the single line of code  
//Student.college="BBDIT";  
		s1.display();
		s2.display();
//	}
	}

}

/*
 * 
 * static is a non-access modifier in Java which is applicable for the
 * following:
 * 
 * blocks variables methods nested classes static keyword in Java is used for
 * memory management mainly. We can apply java static keyword with variables,
 * methods, blocks and nested class order: variable block methods
 * 
 * // It is because the object is not required to call a static method. If it
 * were a non-static method, JVM creates an object first then call main() method
 * that will lead the problem of extra memory allocation.
 * 
 * One of the popular java interview questions for freshers, and very easy one.
 * 
 * public is an access modifier. We use it to specify the access to this method.
 * Here modifier is �public�, so any Class has the access to this method.
 * 
 * static. This Java keyword means that we use this method without creating a
 * new Object of a Class.
 * 
 * Void is the return type of the method. It means that the method doesn�t
 * return any value.
 * 
 * main is the name of the method. JVM �knows� it as an entry point to an
 * application (it should have a particular signature). Main is a method where
 * the main execution occurs.
 * 
 * String args[]. This is the parameter passed to the main method. Here we have
 * the arguments of String type that your Java application accepts when you run
 * it. You can type them on the terminal. No, you cannot override a static
 * method no sense for a constructor to be static no abstract method clAss
 * interface
 * 
 * Instance method can access the instance methods and instance variables
 * directly. Instance method can access static variables and static methods
 * directly. Static methods can access the static variables and static methods
 * directly. Static methods can�t access instance methods and instance variables
 * directly. They must use reference to object. And static method can�t use this
 * keyword as there is no instance for �this� to refer to.
 * 
 * 
 */
*/