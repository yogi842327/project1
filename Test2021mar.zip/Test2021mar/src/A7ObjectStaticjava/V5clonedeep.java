package A7ObjectStaticjava;

import java.util.Arrays;

//A deep copy means actually creating a new array and copying over the values.
//deep copy
class deep {
	private int[] data;

	// altered to make a deep copy of values
	public deep(int[] values) {
		data = new int[values.length];
		for (int i = 0; i < data.length; i++) {
			data[i] = values[i];
		}
	}

	public void showData() {
		System.out.println(Arrays.toString(data));
	}
}

public class V5clonedeep {

	public static void main(String[] args) {
		int[] vals = { 3, 7, 9 };
		deep e = new deep(vals);
		e.showData(); // prints out [3, 7, 9]
		vals[0] = 13;
		e.showData(); // prints out [3, 7, 9]

		// changes in array values will not be
		// shown in data values.
	}
}