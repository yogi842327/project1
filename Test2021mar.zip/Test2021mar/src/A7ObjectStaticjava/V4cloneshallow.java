package A7ObjectStaticjava;

import java.util.Arrays;
//Cloning as �create a copy of object� Shallow, deep and lazy copy is related to cloning process
//shallow copy :This can lead to unpleasant side effects if the elements of values are changed via some other reference.

 class test {
	 private int[] data; 
	  
	    // makes a shallow copy of values 
	    public  test(int[] values) { 
	        data = values; 
	    } 
	  
	    public void showData() { 
	        System.out.println( Arrays.toString(data) ); 
	    } 
	} 

public class V4cloneshallow{ 
	  
    public static void main(String[] args) { 
        int[] vals = {3, 7, 9}; 
        test e = new test(vals); 
        e.showData(); // prints out [3, 7, 9] 
        vals[0] = 13; 
        e.showData(); // prints out [13, 7, 9] 
  
        // Very confusing, because we didn't 
        // intentionally change anything about  
        // the object e refers to. 
    } 
} 