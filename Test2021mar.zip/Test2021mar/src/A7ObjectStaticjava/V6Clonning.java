package A7ObjectStaticjava;

//package A7Object;
//Object cloning means to create an exact copy of the original object.
//https://www.geeksforgeeks.org/cloning-in-java/

//Java code for cloning an object 

class cloneTest implements Cloneable 
{ 
 int a; 
 int b; 

 // Parameterized constructor 
 cloneTest(int a, int b) 
 { 
     this.a = a; 
     this.b = b; 
 } 

 // Method that calls clone() 
 cloneTest cloning() 
 { 
     try
     { 
         return (cloneTest) super.clone(); 
     } 
     catch(CloneNotSupportedException e) 
     { 
         System.out.println("CloneNotSupportedException is caught"); 
         return this; 
     } 
 } 
} 

public class V6Clonning {
	 public static void main(String args[]) 
	    { 
		 cloneTest obj1 = new cloneTest(1, 2); 
		  cloneTest obj2 = obj1.cloning(); 
	        obj1.a = 3; 
	        obj1.b = 4; 
	        System.out.println("Object2 is a clone of object1"); 
	        System.out.println("obj1.a = " + obj1.a + " obj1.b = " + obj1.b); 
	        System.out.println("obj2.a = " + obj2.a + " obj2.b = " + obj2.b); 
	    } 
	} 

